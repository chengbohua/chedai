﻿import os
import pandas as pd
import numpy as np
import csv
import warnings
from sklearn.externals import joblib
import datetime
import gc
warnings.filterwarnings("ignore")
from sklearn.metrics  import roc_curve


## 修改路径到数据存储的文件夹
os.chdir(r'D:\llm\车贷新增模型二期\数据')

##加载模型
clf=joblib.load('newcar2_xgb_model.pkl')


'''
模型变量
'''
## 所需的变量列表
model_para1=['vehicle_minput_chargetimes','vehicle_minput_transfertimes','yx_otherorgan_times',
	          'yx_org_inqry_tms','jxl_n2unntinwd_tellen',	'jxl_num_intrchclls_rt','jxl_crdtcd_clllen',
	          'jxl_loan_aftr_tms','jxl_oprtrs_cllout_tms',	'jxl_m6_mx_clltms',
	          'jxl_m6_mx_shrtm_bill','jxl_m6_mx_call_bill',	'jxl_mblslnc_hr24','jxl_black_interme_score',	'jxl_avr_mssg_strved',
	          'jxl_tel_length',	'jxl_black_dir_cont_num','vehicle_illegal_num',	'vehicle_illegal_penaltypoints',
	          'jxl_m6_mx_itrct_tms','jxl_id_comb_othertel_num','jxl_m6_oth_avgitrt_tms',
	          'vehicle_minput_obtaindate','vehicle_minput_firstregistdate',	'vehicle_minput_lastreleasedate',
	          'apt_facetrial_housetype',	'vehicle_minput_lastmortgagerinfo',	'vehicle_minput_registcertflag','app_applydate','app_siteprovince','apt_age', 'apt_gender']

columns = ['vehicle_minput_chargetimes','vehicle_minput_transfertimes','yx_otherorgan_times',
	          'yx_org_inqry_tms','jxl_n2unntinwd_tellen',	'jxl_num_intrchclls_rt','jxl_crdtcd_clllen',
	          'jxl_loan_aftr_tms','jxl_oprtrs_cllout_tms',	'jxl_m6_mx_clltms',
	          'jxl_m6_mx_shrtm_bill','jxl_m6_mx_call_bill',	'jxl_mblslnc_hr24','jxl_black_interme_score',	'jxl_avr_mssg_strved',
	          'jxl_tel_length',	'jxl_black_dir_cont_num','vehicle_illegal_num',	'vehicle_illegal_penaltypoints',
	          'jxl_m6_mx_itrct_tms','jxl_id_comb_othertel_num','jxl_m6_oth_avgitrt_tms',
	          'age_and_gender',	'vehicle_minput_obtaindate','vehicle_minput_firstregistdate',	'vehicle_minput_lastreleasedate',
	          'apt_facetrial_housetype_1n2',	'vehicle_minput_lastmortgagerinfo_null',	'vehicle_minput_registcertflag_1',
	         'province_consume']
columns_rename=['vehicle_minput_chargetimes','vehicle_minput_transfertimes','yx_otherorgan_times',	'times_by_current_org',
	            'call_time_rank2',	'contact_each_other_rate',	'contact_credit_card_call_len','contact_loan_contact_afternoon',
	            'contact_operator_call_out_len',	'max_call_in_time_l6m',	'max_sms_cnt_l6m','max_total_amount_l6m',	'check_sjjm_pass',
	           'phone_gray_score',	'coll_contact_avg_sms_cnt',	'jxl_tel_length',	'jxl_black_dir_cont_num','vehicle_illegal_num',
	           'vehicle_illegal_penaltypoints','operator_max_interact_cnt_l6m',	'jxl_id_comb_othertel_num',	'other_avg_interact_cnt_l6m',
	           'age_and_gender','vehicle_minput_obtaindate','vehicle_minput_firstregistdate',	'vehicle_minput_lastreleasedate',
	           'apt_facetrial_housetype_1n2',	'vehicle_minput_lastmortgagerinfo_null','vehicle_minput_registcertflag_1',
	          'province_consume']

dates_columns=['vehicle_minput_obtaindate','vehicle_minput_firstregistdate','vehicle_minput_lastreleasedate']
model_para=['app_applycode']+model_para1


'''
##导入模型调用记录表
'''

mdata0 = pd.read_table('newcar2_xgb_testdata_v1.txt', delimiter='\u0001', dtype={'applycode': str}) #读取决策引擎入参数据，从tbd中提取
mdata0=mdata0.replace('\\N',np.nan)
mdata0=mdata0[mdata0['eventtype'].isin(['approval'])]
mdata0=mdata0[mdata0.applycode.notnull()]


'''
线下计算反欺诈分
'''

## 提取制定日期或贷款期限内的押证客户的决策引擎入参数据
start_date='2019-08-14 00:00:00'
end_date='2019-08-16 23:59:59'
m11_data = mdata0[(mdata0.app_applydate>=start_date)&(mdata0.app_applydate<=end_date) ]

## 提取所用到的模型入参数据
model_data=m11_data[model_para1].copy()

## 将变量的默认值设为缺失值np.nan,并将部分数值的字符型变量转成数值型变量
de_dict_var = pd.read_excel('DE_Var_Select_0.xlsx')  # 处理默认值为np.nan
for i, _ in de_dict_var.iterrows():
    name = de_dict_var.loc[i, 'var_name']
    default = de_dict_var.loc[i, 'default']
    if default != '""' and name in set(model_data.columns):
        try:
            model_data[name] = model_data[name].astype('float64')
            if (model_data[name] == float(default)).sum() > 0:
                model_data.loc[model_data[name] == float(default), name] = np.nan
        except:
            pass

    elif default == '""' and name in set(model_data.columns):
        try:
            model_data[name] = model_data[name].astype('float64')
            if (model_data[name] == float(-99)).sum() > 0:
                model_data.loc[model_data[name] == float(-99), name] = np.nan
            if (model_data[name] == '-99').sum() > 0:
                model_data.loc[model_data[name] == '-99', name] = np.nan
        except:
            pass

##　异常值处理
m11_data.ix[m11_data.vehicle_minput_obtaindate>='2030-10-01','vehicle_minput_obtaindate']=np.nan  #将异常的车辆获得时间设为缺失值np.nan
numeric_cols=['vehicle_minput_chargetimes','vehicle_minput_transfertimes','yx_otherorgan_times',
	          'yx_org_inqry_tms','jxl_n2unntinwd_tellen',	'jxl_num_intrchclls_rt','jxl_crdtcd_clllen',
	          'jxl_loan_aftr_tms','jxl_oprtrs_cllout_tms',	'jxl_m6_mx_clltms',
	          'jxl_m6_mx_shrtm_bill','jxl_m6_mx_call_bill',	'jxl_mblslnc_hr24','jxl_black_interme_score',	'jxl_avr_mssg_strved',
	          'jxl_tel_length',	'jxl_black_dir_cont_num','vehicle_illegal_num',	'vehicle_illegal_penaltypoints',
	          'jxl_m6_mx_itrct_tms','jxl_id_comb_othertel_num','jxl_m6_oth_avgitrt_tms']

for col in numeric_cols:
    try:
        model_data[col]=model_data[col].astype('float64')
        if model_data.loc[model_data[col] < 0, col].shape[0] > 0:
            print(col + ':', model_data.loc[model_data[col] < 0, col].unique(),
                  model_data.loc[model_data[col] < 0, col].shape[0]/model_data.shape[0])
            model_data.loc[model_data[col] < 0, col] = np.nan
    except:
        pass


for col in dates_columns:  #去除异常的时间
       try:
           model_data.ix[model_data[col]>='2030-01-01',col]=np.nan
       except:
           pass

##  处理日期型变量
def date_cal(x, app_applydate):
    days_dt = pd.to_datetime(app_applydate) - pd.to_datetime(x)
    return days_dt.dt.days

for col in dates_columns:
    if  col!='vehicle_minput_drivinglicensevaliditydate':
      model_data[col] = date_cal(model_data[col], model_data['app_applydate'])
    else:
        model_data[col] = date_cal( model_data['app_applydate'],model_data[col])

model_data=model_data.drop('app_applydate',axis=1) #去除申请日期这个变量


## 变量衍生逻辑
model_data['apt_facetrial_housetype_1n2'] = model_data.loc[:, 'apt_facetrial_housetype'].isin([1,2]).astype('float64')
model_data['vehicle_minput_lastmortgagerinfo_null'] = ((model_data.loc[:, 'vehicle_minput_lastmortgagerinfo'].isin([3])) | (model_data.loc[:, 'vehicle_minput_lastmortgagerinfo'].isnull())).astype('float64')
model_data['vehicle_minput_registcertflag_1'] = model_data.loc[:, 'vehicle_minput_registcertflag'].isin([1]).astype('float64')
model_data['age_and_gender']=1
model_data.loc[(model_data.apt_age>=39) & (model_data.apt_gender.isin(['男'])),'age_and_gender']=0  ##年龄与性别组合
model_data.loc[(model_data.apt_gender.isin(['女'])),'age_and_gender']=0
consume_province=pd.read_excel('统计局数据_省级.xlsx',sheetname='各省平均工资（元）')
model_data=pd.merge(model_data,consume_province[['地区','2017年']],left_on='app_siteprovince',right_on='地区',how='left')
model_data=model_data.rename(columns={'2017年':'province_consume'})

## 提取最终模型入参数据
final_data=model_data[columns].copy()

## 将缺失值np.nan设为-998
for cn in final_data:
    if final_data[cn].isnull().sum()>0:
        final_data.ix[final_data[cn].isnull(),cn]=-998

##改变量名
rename_list={}
for key,value in zip(columns,columns_rename):
        rename_list[key]=value
final_data=final_data.rename(columns=rename_list)
final_data=final_data[columns_rename]

## 计算反欺诈分
p = clf.predict_proba(final_data)[:, 1]
m11_data['scores3']=p*100

