﻿from sklearn.externals import joblib
import datetime
import os
from pandas import DataFrame

model_path = os.path.dirname(os.path.abspath(__file__))

#添加模型文件路径
clf = joblib.load(os.path.join(model_path, 'newcar2_xgb_model.pkl'))
#clf = joblib.load( 'E:/新增二期模型部署文件/newcar3_xgb_model.pkl')


class model():
    def gbdt(self,data_json):

       # 函数输出变量
       status='0'
       msg=''
       res='-1'

       # 设置报错机制，若传入的为非json格式则报错
       if type(data_json)!=dict:
          status='1'
          msg='error：输入的参数不是json串格式！'
          return res,status,msg

       try:                   #统一将变量名修改为小写
            data_json1={}
            for cn in data_json.keys():
               data_json1[cn.lower()]=data_json[cn]
       except Exception as e:
               status = '1'
               msg = str(repr(e))
               return res, status, msg

       #对部分因为新老三方接口更换导致的变量差异处理或者默认值就是为0的特殊变量处理
       try:
           if data_json1['jxl_id_comb_othertel_num']==0:
               data_json1['jxl_id_comb_othertel_num']=-99
           if data_json1['vehicle_illegal_num']==0:
               data_json1['vehicle_illegal_num']=-99
           if data_json1['vehicle_illegal_penaltypoints']==0:
               data_json1['vehicle_illegal_penaltypoints']=-99
       except:
          pass


       # 数值型变量
       x1 = ['vehicle_minput_chargetimes',
	         'vehicle_minput_transfertimes',
	         'yx_otherorgan_times',
	         'yx_org_inqry_tms',
	         'jxl_n2unntinwd_tellen',
	         'jxl_num_intrchclls_rt',
	         'jxl_crdtcd_clllen',
	         'jxl_loan_aftr_tms',
	         'jxl_oprtrs_cllout_tms',
	         'jxl_m6_mx_clltms',
	         'jxl_m6_mx_shrtm_bill',
	         'jxl_m6_mx_call_bill',
	         'jxl_mblslnc_hr24',
	         'jxl_black_interme_score',
	         'jxl_avr_mssg_strved',
             'jxl_tel_length',
	         'jxl_black_dir_cont_num',
	         'vehicle_illegal_num',
	         'vehicle_illegal_penaltypoints',
	         'jxl_m6_mx_itrct_tms',
	         'jxl_id_comb_othertel_num',
	         'jxl_m6_oth_avgitrt_tms','apt_age'	]

       # 字符型变量
       x2 = [	'apt_facetrial_housetype',
	          'vehicle_minput_lastmortgagerinfo',
	           'vehicle_minput_registcertflag']

       #加工变量province_consume
       x3=['app_siteprovince']


       # 日期型变量
       dates = [	'vehicle_minput_obtaindate',
	             'vehicle_minput_firstregistdate',
	             'vehicle_minput_lastreleasedate']

       # 数值型变量默认值处理函数
       def fun(x):
           if x == '' or x == ' ' or float(x) == -1 or float(x) == -99 :
               return -998
           else:
               return float(x)

       # 字符型变量处理函数，统一处理成整型字符串形如'1'这种字符格式
       def str_fun(x):
            try:
                x=str(int(x))
            except:
                x=str(x)
            return x

       def fun_date(x, app_applydate):
            if str(x)=='9999-12-31 00:00:00' or str(app_applydate)=='9999-12-31 00:00:00':
                return -998
            x = x.replace('/', '-')
            try:
                x = datetime.datetime.strptime(x, '%Y-%m-%d %H:%M:%S')
            except:
                return -998
            app_applydate = app_applydate.replace('/', '-')
            try:
                 now_time = datetime.datetime.strptime(app_applydate, '%Y-%m-%d %H:%M:%S')
            except:
                return -998
            x = (now_time - x).days
            return x

       # 调用各种处理函数来处理变量
       try:
            x1 = [fun(data_json1[i]) for i in x1]
            x2=  [str_fun(data_json1[i]) for i in x2]
            dates = [fun_date(data_json1[i], data_json1['app_applydate']) for i in dates]
       except  Exception as e:
            status = '1'
            msg = str(repr(e)) + '，json串中缺少该变量'
            return res, status, msg

       #加工变量：age_and_gender、province_consume

       if (x1[len(x1)-1]>=39 and data_json1['apt_gender']=='男') or (data_json1['apt_gender']=='女'):
            x1[len(x1)-1]=0 #加工变量age_and_gender
       else:
            x1[len(x1)-1]=1

       province_consume_dist={}
       keys=['北京','天津','河北','山西','内蒙古','辽宁','吉林','黑龙江','上海','江苏','浙江','安徽','福建','江西','山东',
      '河南','湖北','湖南','广东','广西','海南','重庆','四川','贵州','云南','西藏','陕西','甘肃','青海','宁夏','新疆']
       values=[134994,96965,65266,61547,67688,62545,62908,59995,130765,79741,82642,67927,69029,63069,69305,
              55997,67736,65994,80020,66456,69062,73272,71631,75109,73515,115549,67433,65726,76535,72779,68641]
       for key,value in zip(keys,values):
          province_consume_dist[key]=value  #加工变量province_consume
       if data_json1['app_siteprovince'] not in keys:
          x3[0]=-998
       else:
          x3[0]=province_consume_dist[data_json1['app_siteprovince']]


        #哑变量加工
       if x2[0]== '1' or x2[0]=='2':
           x2[0] = 1
       else:
           x2[0] = 0

       if x2[1]=='' or x2[1]==' ' or x2[1]=='3' or x2[1]=='-99':
           x2[1] = 1
       else:
           x2[1] = 0

       if x2[2] == '1':
           x2[2] = 1
       else:
           x2[2] = 0


      # 全部入模变量
       columns=['vehicle_minput_chargetimes','vehicle_minput_transfertimes','yx_otherorgan_times',
	          'yx_org_inqry_tms','jxl_n2unntinwd_tellen',	'jxl_num_intrchclls_rt','jxl_crdtcd_clllen',
	          'jxl_loan_aftr_tms','jxl_oprtrs_cllout_tms',	'jxl_m6_mx_clltms',
	          'jxl_m6_mx_shrtm_bill','jxl_m6_mx_call_bill',	'jxl_mblslnc_hr24','jxl_black_interme_score',	'jxl_avr_mssg_strved',
	          'jxl_tel_length',	'jxl_black_dir_cont_num','vehicle_illegal_num',	'vehicle_illegal_penaltypoints',
	          'jxl_m6_mx_itrct_tms','jxl_id_comb_othertel_num','jxl_m6_oth_avgitrt_tms',
	          'age_and_gender',	'vehicle_minput_obtaindate','vehicle_minput_firstregistdate',	'vehicle_minput_lastreleasedate',
	          'apt_facetrial_housetype_1n2',	'vehicle_minput_lastmortgagerinfo_null',	'vehicle_minput_registcertflag_1',
	         'province_consume']
       columns1=['vehicle_minput_chargetimes','vehicle_minput_transfertimes','yx_otherorgan_times',	'times_by_current_org',
	            'call_time_rank2',	'contact_each_other_rate',	'contact_credit_card_call_len','contact_loan_contact_afternoon',
	            'contact_operator_call_out_len',	'max_call_in_time_l6m',	'max_sms_cnt_l6m','max_total_amount_l6m',	'check_sjjm_pass',
	           'phone_gray_score',	'coll_contact_avg_sms_cnt',	'jxl_tel_length',	'jxl_black_dir_cont_num','vehicle_illegal_num',
	           'vehicle_illegal_penaltypoints','operator_max_interact_cnt_l6m',	'jxl_id_comb_othertel_num',	'other_avg_interact_cnt_l6m',
	           'age_and_gender','vehicle_minput_obtaindate','vehicle_minput_firstregistdate',	'vehicle_minput_lastreleasedate',
	           'apt_facetrial_housetype_1n2',	'vehicle_minput_lastmortgagerinfo_null','vehicle_minput_registcertflag_1',
	          'province_consume']
       rename_list={}
       for key,value in zip(columns,columns1):
           rename_list[key]=value


      # 调用模型，输出分数
       x = x1 + dates+x2+x3
       try:
          res = float(clf.predict_proba(DataFrame(x,index=columns).T.rename(columns=rename_list))[:, 1]) * 100.0
       except Exception as e:
          status='1'
          msg=str(repr(e))
          return res,status,msg

       return '%.3f' % res,status,msg


# '''
# 实例
# '''

# data_json={'app_applydate': '2017-05-16 00:00:00',
# 'app_siteprovince': '广东',
# 'apt_age': 35,
# 'apt_facetrial_housetype': 5,
# 'apt_gender': '男',
# 'jxl_n2unntinwd_tellen': -99,
# 'jxl_mblslnc_hr24': -99,
# 'jxl_avr_mssg_strved': -99,
# 'jxl_crdtcd_clllen': -99,
# 'jxl_num_intrchclls_rt':-99,
# 'jxl_loan_aftr_tms': -99,
# 'jxl_oprtrs_cllout_tms': -99,
# 'jxl_black_dir_cont_num': 64,
# 'jxl_id_comb_othertel_num':-99,
# 'jxl_tel_length': 49,
# 'jxl_m6_mx_clltms': -99,
# 'jxl_m6_mx_shrtm_bill': -99,
# 'jxl_m6_mx_call_bill': -99,
# 'jxl_m6_mx_itrct_tms': -99,
# 'jxl_m6_oth_avgitrt_tms': -99,
# 'jxl_black_interme_score':-99,
# 'yx_org_inqry_tms': 1,
# 'vehicle_illegal_num': 11,
# 'vehicle_illegal_penaltypoints': 6,
# 'vehicle_minput_chargetimes': 0,
# 'vehicle_minput_firstregistdate': '2015-02-04 00:00:00',
# 'vehicle_minput_lastmortgagerinfo': -99,
# 'vehicle_minput_lastreleasedate': '9999-12-31 00:00:00',
# 'vehicle_minput_obtaindate': '2017-05-10 00:00:00',
# 'vehicle_minput_registcertflag': 2,
# 'vehicle_minput_transfertimes': 0,
# 'yx_otherorgan_times': 0}
#
# print(model().gbdt(data_json))