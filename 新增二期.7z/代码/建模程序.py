# -*- coding: utf-8 -*-
"""
Created on Tue Apr 30 11:02:54 2019

@author: wj56740
#针对客户：所有新增客户
#观察期时间窗：2017.07.01-2018.09.28
#表现期：2019年4月15日
## 坏客户定义：
#      1)  曾经逾期16+
## 好客户的定义： 
#      1） 已结清且未发生逾期   
#      2） 已还至少6期且未发生逾期

"""
import os
import pandas as pd
import numpy as np
from scipy import stats
from sklearn.metrics import roc_curve, roc_auc_score
from sklearn.ensemble import GradientBoostingClassifier,RandomForestClassifier
from sklearn.model_selection import train_test_split
import warnings
import matplotlib.pyplot as plt
from matplotlib import rcParams
import datetime
from xgboost.sklearn import XGBClassifier
from sklearn.externals import joblib
import pickle

warnings.filterwarnings("ignore")
rcParams['font.sans-serif'] = ['Microsoft YaHei']

## 修改路径到数据存储的文件夹
os.chdir('E:/liaoliming/重要文档/车贷数据/新增二期模型开发_20190411/数据/')


## 定义一些函数用于模型评估，计算KS
def r_p(y_test, answer_p, idx, low=0, high=150):
    a = answer_p
    b = y_test

    idx = idx[low:high]
    recall = (b.iloc[idx] == 1).sum() / (b == 1).sum()
    precision = (b.iloc[idx] == 1).sum() / (high - low)
    return (recall, precision)


def r_p_chart(y_test, answer_p, part=20):
    print('分段  平均分 最小分 最大分 客户数 逾期数 逾期数/客户数 KS值 GAIN_INDEX 累计召回率')
    a = answer_p
    b = y_test

    idx = sorted(range(len(a)), key=lambda k: a[k], reverse=True)

    total_label_RATE = (y_test == 1).sum() / len(y_test)

    ths = []
    cum = 0
    if len(np.unique(a)) < part:
        for unq_a in np.unique(a)[::-1]:
            ths.append(cum)
            cum = cum + (a == unq_a).sum()
        ths.append(cum)

    else:
        for i in np.arange(0, len(a), (len(a) / part)):
            ths.append(int(round(i)))
        ths.append(len(a))

    min_scores = []
    for idx_ths, _ in enumerate(ths):
        if idx_ths == 0:
            continue
        # idx_ths = 1
        low = ths[idx_ths - 1]
        high = ths[idx_ths]

        r, p = r_p(y_test, answer_p, idx, low, high)
        cum_r, cum_p = r_p(y_test, answer_p, idx, 0, high)

        max_score = answer_p[idx[low]]
        min_score = answer_p[idx[high - 1]]
        min_scores.append(min_score)
        mean_score = (max_score + min_score) / 2
        len_ = high - low
        idx_tmp = idx[low:high]
        bad_num = (b.iloc[idx_tmp] == 1).sum()
        INTERVAL_label_RATE = bad_num / len_
        idx_tmp = idx[0:high]

        tpr = (b.iloc[idx_tmp] == 1).sum() / (b == 1).sum()
        fpr = (b.iloc[idx_tmp] == 0).sum() / (b == 0).sum()
        ks = tpr - fpr
        gain_index = INTERVAL_label_RATE / total_label_RATE

        print('%d %10.3f %10.3f %10.3f %7d %7d %10.2f %10.2f %10.2f %10.2f'
              % (idx_ths, mean_score * 100, min_score * 100, max_score * 100, len_, bad_num, INTERVAL_label_RATE * 100,
                 ks * 100, gain_index, cum_r * 100))

    return min_scores


def r_p_chart2(y_test, answer_p, min_scores, part=20):
    print('分段  平均分 最小分 最大分 客户数 逾期数 逾期数/客户数 KS值 GAIN_INDEX 累计召回率')
    a = answer_p
    b = y_test

    idx = sorted(range(len(a)), key=lambda k: a[k], reverse=True)

    ths = []
    ths.append(0)
    min_scores_idx = 0
    for num, i in enumerate(idx):
        # print(a[i])
        if a[i] < min_scores[min_scores_idx]:
            ths.append(num)
            min_scores_idx = min_scores_idx + 1
    ths.append(len(idx))

    total_label_RATE = (y_test == 1).sum() / len(y_test)

    min_scores = []
    for idx_ths, _ in enumerate(ths):
        if idx_ths == 0:
            continue
        low = ths[idx_ths - 1]
        high = ths[idx_ths]

        r, p = r_p(y_test, answer_p, idx, low, high)
        cum_r, cum_p = r_p(y_test, answer_p, idx, 0, high)

        max_score = answer_p[idx[low]]
        min_score = answer_p[idx[high - 1]]

        min_scores.append(min_score)
        mean_score = (max_score + min_score) / 2
        len_ = high - low
        idx_tmp = idx[low:high]
        bad_num = (b.iloc[idx_tmp] == 1).sum()
        INTERVAL_label_RATE = bad_num / len_
        idx_tmp = idx[0:high]
        tpr = (b.iloc[idx_tmp] == 1).sum() / (b == 1).sum()
        fpr = (b.iloc[idx_tmp] == 0).sum() / (b == 0).sum()
        ks = tpr - fpr
        gain_index = INTERVAL_label_RATE / total_label_RATE

        print('%d %10.3f %10.3f %10.3f %7d %7d %10.2f %10.2f %10.2f %10.2f'
              % (idx_ths, mean_score * 100, min_score * 100, max_score * 100, len_, bad_num, INTERVAL_label_RATE * 100,
                 ks * 100, gain_index, cum_r * 100))
        
        
'''
导入还款表、进度逾期表并加工处理,由于数据计算比较大，优先计算
'''
paymentdata = pd.read_table('payment_20190416.txt', delimiter='\u0001')
paymentdata= paymentdata.replace('\\N', np.nan)

paymentdata=paymentdata.ix[paymentdata.shouldpaydate < '2019-04-16 00:00:00',['contractno','paydate','shouldpaydate','shouldcapital', 'shouldgpsf', 'shouldint', 'shouldmanage','update_time','totalphases','payphases','phases']]
paymentdata.loc[(paymentdata.paydate >= '2019-04-16 00:00:00'), 'paydate'] = '2019-04-15 23:59:59'  ## 将表现窗口设为截止到2019-01-06

paymentdata=paymentdata[paymentdata.paydate>='1970-12-03 00:00:00'].copy() #异常值处理
paymentdata['overdue_days'] = (pd.to_datetime(paymentdata.paydate) - pd.to_datetime(paymentdata.shouldpaydate)).dt.days
paymentdata.loc[(paymentdata[['shouldcapital', 'shouldgpsf', 'shouldint', 'shouldmanage']] == 0).all(axis=1), 'overdue_days'] = 0  ##计算历史最大逾期天数
paymentdata.loc[paymentdata['overdue_days'] < 0, 'overdue_days'] = 0
paymentdata_maxdue = paymentdata.groupby(['contractno']).overdue_days.max().reset_index().rename(columns={'overdue_days': 'maxoverduedays'})

paymentdata[['totalphases', 'payphases', 'phases']] = paymentdata[['totalphases', 'payphases', 'phases']].astype('int64')  # 将一些字段转成整型数据

paymentdata_totalphases = paymentdata.groupby(['contractno']).totalphases.max().reset_index()  # 计算贷款总期限,不包括展期
paymentdata_realtotalphases = paymentdata[paymentdata.update_time< '2019-04-16 00:00:00'].groupby(['contractno']).payphases.max().reset_index().rename(columns={'payphases': 'max_payphases'})  # 包括是否展期
paymentdata_totalphases = pd.merge(paymentdata_totalphases, paymentdata_realtotalphases, on='contractno', how='inner')
paymentdata_totalphases['realtotalphases'] = paymentdata_totalphases[['totalphases', 'max_payphases']].max(axis=1)  # 在实际贷款期限与是否展期合并获得总贷款期限

paymentdata_returnphases = paymentdata.groupby(['contractno']).payphases.max().reset_index().rename(columns={'payphases': 'returnphases'})  # 计算已还期数
paymentdata_phases_counts = pd.merge(paymentdata_returnphases, paymentdata_totalphases, on='contractno',how='inner')  # 合并贷款期限与已还期数
paymentdata_phases_counts = pd.merge(paymentdata_phases_counts, paymentdata_maxdue, on='contractno',how='inner')  # 合并最大逾期与贷款期限
del paymentdata,paymentdata_totalphases,paymentdata_returnphases,paymentdata_maxdue

findata0 = pd.read_table('fnsche_over20190416.txt', encoding='gbk', dtype={'contractno': str})  # 导入进度逾期表
findata0 = findata0[findata0['loantype'].isin(['车信易贷'])==False]
findata0 = findata0.loc[findata0['loandate'].notnull(), ['loandate', 'contractno', 'returnstatus','loantype','totalphases','hkfs','dkfs','loantype1']].copy().rename(columns={'totalphases':'fin_totalphases',
                                                                        'hkfs':'fin_hkfs','dkfs':'fin_dkfs'})
findata0['loandate'] = findata0['loandate'].map(lambda x: datetime.datetime.strptime(str(x), "%d%b%Y")).copy()  # pd.to_datetime(findata0['loandate']).astype('str')
findata0= findata0.sort_values(['contractno','loandate']).drop_duplicates('contractno',keep='last')
paymentdata_phases_counts_1=pd.merge(paymentdata_phases_counts,findata0,on='contractno',how='inner')
del findata0,paymentdata_phases_counts
paymentdata_phases_counts_1.to_csv('paymentdata_phases_counts_20190418v1.csv',index=False)




'''
##1.1 导入相关表获取建模数据
'''

mdata_0 = pd.read_table('./data_20180702.txt', delimiter='\u0001', dtype={'app_applycode': str}) #读取决策引擎入参数据，从tbd中提取
mdata_0=mdata_0.replace('\\N',np.nan)
mdata_0=mdata_0[mdata_0.app_applycode.notnull()]
mdata_0 = mdata_0.sort_values(['app_applycode', 'last_update_date']).drop_duplicates('app_applycode', keep='last')

mdata_1 = pd.read_table('data_20180701-20190314.txt', delimiter='\u0001', dtype={'app_applycode': str}) #读取决策引擎入参数据，从tbd中提取
mdata_1=mdata_1.replace('\\N',np.nan)
mdata_1=mdata_1[mdata_1.app_applycode.notnull()]
mdata_1 = mdata_1.sort_values(['app_applycode', 'last_update_date']).drop_duplicates('app_applycode', keep='last')

mdata_2=pd.concat([mdata_0,mdata_1])
del mdata_0,mdata_1
mdata_2 = mdata_2.sort_values(['app_applycode', 'last_update_date']).drop_duplicates('app_applycode', keep='last')


start_date = '2017-07-01 00:00:00'
end_date = '2018-09-28 23:59:59'
mdata_2 = mdata_2[(mdata_2.app_applydate >= start_date) & (mdata_2.app_applydate <= end_date)]
mdata_2 = mdata_2.sort_values(['app_applycode', 'last_update_date']).drop_duplicates('app_applycode', keep='last')

consume_province=pd.read_excel('统计局数据_省级.xlsx',sheetname='各省平均工资（元）')  ##衍生一个收入变量
mdata_2=pd.merge(mdata_2,consume_province[['地区','2017年']],left_on='app_siteprovince',right_on='地区',how='left')
mdata_2=mdata_2.rename(columns={'2017年':'province_consume'})
del consume_province


apply_contract_report = pd.read_table('applycode_20190416.txt',sep='\u0001',dtype={'applycode':str})  #车贷申请表
apply_contract_report=apply_contract_report.replace('\\N',np.nan)
apply_contract_report = apply_contract_report[(apply_contract_report.applycode.isnull() == False)].sort_values(['applycode','applydate']).drop_duplicates('applycode',keep='last')
mdata_3 = pd.merge(mdata_2, apply_contract_report, left_on='app_applycode', right_on='applycode', how='inner')
del apply_contract_report,mdata_2
mdata_3 = mdata_3.sort_values(['app_applycode', 'last_update_date']).drop_duplicates('app_applycode', keep='last')
mdata_3['applymonth'] = mdata_3.app_applydate.str.slice(0, 7)  # 生成申请月份
mdata_3['loantime_m']=mdata_3['loan_time'].copy()
mdata_3.loc[mdata_3.loantime_m.isin([1, 3, 6,12, 24, 36]) == False, 'loantime_m'] = 998  ##其余期限改为998

paymentdata_phases_counts_1=pd.read_csv('./paymentdata_phases_counts_20190418v1.csv',encoding='utf-8') #坏客户标签
mdata_4= pd.merge(mdata_3, paymentdata_phases_counts_1, on='contractno', how='left')
del paymentdata_phases_counts_1,mdata_3
mdata_4=mdata_4.sort_values(['app_applycode', 'last_update_date']).drop_duplicates('app_applycode', keep='last')
mdata_4=mdata_4.drop('applycode',axis=1)

newloan_label=pd.read_excel('./2019年3月7日之前的新增贷款客户申请编号.xlsx',converters={'applycode':str}) # 选择新增客户
mdata_4=pd.merge(mdata_4,newloan_label,left_on='app_applycode',right_on='applycode',how='inner')
del  newloan_label
mdata_4['fin_phases']=mdata_4[['fin_totalphases','realtotalphases']].max(axis=1)
mdata_4['TotalPhases_m'] = mdata_4['fin_phases'].copy() ##实际贷款期限，与申请期限略有差别
mdata_4.loc[mdata_4.TotalPhases_m.isin([1, 3, 6,12, 24, 36]) == False, 'TotalPhases_m'] = 998  ##其余期限改为998

## 相关统计
temp1=mdata_4[['hkfs','loantime_m']].copy()
print('所有申请样本',pd.crosstab(temp1.hkfs,temp1.loantime_m,margins=True))
del temp1
temp2=mdata_4.loc[mdata_4.dkfs.isin(['押证']),['hkfs','loantime_m']].copy()
print('押证申请',pd.crosstab(temp2.hkfs,temp2.loantime_m,margins=True))
del temp2
temp3=mdata_4.loc[mdata_4.loandate.notnull(),['fin_hkfs','TotalPhases_m']].copy()
print('所有放款',pd.crosstab(temp3.fin_hkfs,temp3.TotalPhases_m,margins=True))
del temp3
temp4=mdata_4.loc[(mdata_4.loandate.notnull()) & (mdata_4.fin_dkfs.isin(['押证'])),['fin_hkfs','TotalPhases_m']].copy()
print('押证放款',pd.crosstab(temp4.fin_hkfs,temp4.TotalPhases_m,margins=True))
del temp4
temp_5 = mdata_4.loc[(mdata_4.loandate.notnull()) & (((mdata_4.hkfs.isin(['1'])) & (mdata_4.loantime_m.isin([12])))==False),
                ['applymonth', 'TotalPhases_m','app_applycode','fin_hkfs','fin_dkfs']].copy()
temp_5=temp_5.loc[(temp_5.fin_hkfs.isin(['等额本息','等本等息'])),:]
count_stat_fin_m = temp_5.groupby(['applymonth', 'TotalPhases_m']).app_applycode.agg('count').reset_index().rename(columns={'app_applycode': 'fin_count'})
print(count_stat_fin_m)

temp_6=temp_5[(temp_5.fin_dkfs.isin(['押证'])) ]
del temp_5
count_stat_yz_fin_m = temp_6.groupby(['applymonth', 'TotalPhases_m']).app_applycode.agg('count').reset_index().rename(columns={'app_applycode': 'fin_count'})
print(count_stat_yz_fin_m)
count_sample_m = pd.merge(count_stat_fin_m, count_stat_yz_fin_m, on=['applymonth', 'TotalPhases_m'], how='left')
del temp_6


'''
##1.2 确定好坏客户的定义（vintage分析）
'''
#可以用计算逾期发生率vintage_按笔数统计.py进行统计，这里省略
maxoverduedays_counts=mdata_4.maxoverduedays.value_counts()
maxoverduedays_counts=maxoverduedays_counts/mdata_4.shape[0]
maxoverduedays_counts=maxoverduedays_counts.reset_index().rename(columns={'index':'maxoverduedays','maxoverduedays':'maxoverdueday_percents'})
maxoverduedays_counts['maxoverdueday_csum']=maxoverduedays_counts.maxoverduedays.map(lambda x: (fin_mdata.maxoverduedays>=x).sum()/fin_mdata.shape[0])

maxoverduedays_counts.maxoverdueday_percents.plot(kind='bar', color='k', alpha=0.7, title='maxoverdueday_percents')
for a,b in zip(maxoverduedays_counts['maxoverduedays'],maxoverduedays_counts['maxoverdueday_percents']):
    plt.text(a, b+0.001, '{:.0%}'.format(b), ha='center', va= 'bottom',fontsize=9)
plt.show()


fin_mdata1 = mdata_4[(mdata_4.loandate.notnull()) & (mdata_4.fin_phases>=6)].copy()
fin_mdata = fin_mdata1[(fin_mdata1.fin_dkfs.isin(['押证'])) ]
del fin_mdata1
paymentdata_phases_counts_2=pd.read_csv('./paymentdata_maxdue_20190424.csv',encoding='gbk') #坏客户标签
temp5=pd.merge(fin_mdata[['contractno','loandate','app_applydate']],paymentdata_phases_counts_2,on='contractno',how='inner')
temp5=temp5.loc[(temp5.loandate>='2018-09-01') & (temp5.loandate<='2018-09-28 23:59:59'),['contractno','maxoverduedays_2019-01-16 ','maxoverduedays_2019-04-16 ']]
temp5=temp5.loc[temp5['maxoverduedays_2019-01-16 ']<=15,:]
temp5.loc[temp5['maxoverduedays_2019-04-16 ']>=16,'maxoverduedays_2019-04-16 ']=16
crosstab_num=pd.crosstab(temp5['maxoverduedays_2019-01-16 '],temp5['maxoverduedays_2019-04-16 '],margins=True)
crosstab_num.reset_index().to_excel('D:/llm/车贷新增模型二期/结果/2018年9月新增等本等息放款的客户表现期从2019年1月16日过渡到2019年4月16日的逾期变化统计—数量.xlsx',index=False)
crosstab_num.div(crosstab_num['All'],axis=0).reset_index().to_excel('D:/llm/车贷新增模型二期/结果/2018年9月等本等息放款的客户表现期从2019年1月16日过渡到2019年4月16日的逾期变化统计—占比.xlsx',index=False)
del temp5,fin_mdata


'''
----------------------------
## 1.2 定义好坏客户

## 坏客户定义：
#      1)  曾经逾期16+
## 好客户的定义： 
#      1） 已结清且曾经逾期不超过一天，   
#      2） 已还至少6期且曾经逾期不超过一天

----------------------------
'''

my_data = mdata_4.loc[(mdata_4.loandate.notnull()) & (((mdata_4.hkfs.isin(['1'])) & (mdata_4.loantime_m.isin([12])))==False),:]
my_data=my_data.loc[(my_data.fin_hkfs.isin(['等额本息','等本等息'])),:]
my_data=my_data[my_data.TotalPhases_m.isin([12,24,36])]
my_data=my_data[(my_data.fin_dkfs.isin(['押证'])) ]
del mdata_4
my_data['overdue_flag'] = (my_data.maxoverduedays >= 16)
my_data['bad'] = (my_data.overdue_flag == True)  # 占比约为4.6%
my_data['chargeoff_flag'] = (my_data.maxoverduedays==0) & (my_data.returnstatus.isin(['已结清']))  # 结清里面大概有75%没有逾期
my_data['r6_good_flag'] = (my_data.returnphases >= 6) & (my_data.maxoverduedays==0)
my_data['good'] = my_data.chargeoff_flag | my_data.r6_good_flag
my_data['y'] = np.nan
my_data.loc[(my_data.bad == True) & (my_data.good == False), 'y'] = 1
my_data.loc[(my_data.bad == False) & (my_data.good == True), 'y'] = 0

count_sample_m2 = pd.merge(count_sample_m, my_data[my_data.y.notnull()].groupby(['applymonth', 'TotalPhases_m']).agg({'y': ['count', 'sum', 'mean'], 'chargeoff_flag': ['sum']}).reset_index(),
                           on=['applymonth', 'TotalPhases_m'], how='left')
#count_sample_m2.to_excel(r'D:\llm\车贷新增模型二期\结果\客户分布情况_20190513.xlsx',index=False)

print(count_sample_m2)

print(sum(my_data.bad))
# 9845
print(sum(my_data.good))
# 21376

##针对最大逾期期数介于0和15天的，剔除24704
print(sum((my_data.maxoverduedays >=1) & (my_data.maxoverduedays < 16) & (my_data.y.isnull())))

##针对最大逾期期数介于0和15天的，剔除3
print(sum((my_data.maxoverduedays==1) & (my_data.returnphases<6) & (my_data.y.isnull()) & (my_data.returnstatus.isin(['未结清']))))


## 剔除灰客户以及1、3期的客户
my_data=my_data[(my_data.y.notnull())]
my_data=my_data.drop('applycode',axis=1)
#my_data.to_excel('建模样本集—车贷决策引擎变量_20190507.xlsx',index=False)

'''
----------------------------
## 1.3  获取其他三方数据，主要是原始衍生变量数据，在这里合并主要是因为数据太大
----------------------------
'''

carinfo_final_data = pd.read_table('llm_carinfo_final_data_20190422.txt', delimiter='\u0001', dtype={'applycode': str}) #读取决策引擎入参数据，从tbd中提取
carinfo_final_data=carinfo_final_data.replace('\\N',np.nan)
carinfo_final_data=carinfo_final_data[carinfo_final_data.applycode.notnull()]
final_data=pd.merge(my_data,carinfo_final_data,left_on='app_applycode',right_on='applycode',how='inner')
del carinfo_final_data,my_data
final_data = final_data.sort_values(['app_applycode', 'last_update_date']).drop_duplicates('app_applycode', keep='last')
final_data = final_data.drop(['applycode'],axis=1)

llm_xiangye_data=pd.read_table('llm_yixin_info_20190425.txt', delimiter='\u0001', dtype={'applycode': str}) #读取决策引擎入参数据，从tbd中提取
llm_xiangye_data=llm_xiangye_data.replace('\\N',np.nan)
llm_xiangye_data=llm_xiangye_data[llm_xiangye_data.applycode.notnull()]
llm_xiangye_data=llm_xiangye_data.drop('contractno',axis=1)
final_data=pd.merge(final_data,llm_xiangye_data,left_on='app_applycode',right_on='applycode',how='inner')
del llm_xiangye_data
final_data = final_data.drop('applycode',axis=1)


xiangye_jxl_report=pd.read_table('llm_jxl_report_20190506.txt', delimiter='\u0001', dtype={'apply_no': str}) #读取决策引擎入参数据，从tbd中提
xiangye_jxl_report=xiangye_jxl_report.sort_values(['apply_no','query_time']).drop_duplicates('apply_no',keep='last')
xiangye_jxl_report=xiangye_jxl_report.replace('\\N',np.nan)
jxl_report_dict=pd.read_excel('聚信立报告字典.xlsx')
xiangye_jxl_report=xiangye_jxl_report[jxl_report_dict['字段名'].values.tolist()]
del jxl_report_dict
final_data=pd.merge(final_data,xiangye_jxl_report,left_on='app_applycode',right_on='apply_no',how='left')
del xiangye_jxl_report
final_data = final_data.sort_values(['app_applycode', 'last_update_date']).drop_duplicates('app_applycode', keep='last')
#final_data.to_excel('所有建模样本数据_20190513.xlsx',index=False)



'''
##2.1 读入字典
'''
tn_dict_1 = pd.read_excel('TouNa_DA-OAPPLIDT_20180814.xlsx')  ## 申请信息
tn_dict_2 = pd.read_excel('TouNa_DA-OBUREADT_20180814.xlsx')  ## 三方数据
tn_dict_1 = tn_dict_1[tn_dict_1.var_name.notnull()]
tn_dict_2 = tn_dict_2[tn_dict_2.var_name.notnull()]

tn_dict_3=pd.read_excel('三方数据整合表字典.xlsx',sheet_name='字典')
tn_dict_3=tn_dict_3[['字段名','取值类型','字段注释']].rename(columns={'字段名':'var_name','取值类型':'var_type','字段注释':'var_desc'})
tn_dict_3['length']=np.nan
tn_dict_3['var_code_comment']=np.nan
tn_dict_3['default']=np.nan
tn_dict_3.loc[tn_dict_3.var_type.isin(['varchar(200)']),'var_type']='字符型'
tn_dict_3.loc[tn_dict_3.var_type.isin(['int','decimal(15,2)']),'var_type']='数据型'
tn_dict_3.loc[tn_dict_3.var_type.isin(['字符型']),'default']=""
tn_dict_3.loc[tn_dict_3.var_type.isin(['数据型']),'default']=-99
tn_dict_3=tn_dict_3[['var_desc','var_type','length','var_name','var_code_comment','default']].drop_duplicates()


tn_dict_4=pd.read_excel('聚信立报告_宜信字典_整合祥业和利明的工作.xlsx')
tn_dict_4=tn_dict_4[['字段名','类型','中文名','逻辑说明']].rename(columns={'字段名':'var_name','类型':'var_type','中文名':'var_desc','逻辑说明':'var_code_comment'})
tn_dict_4['length']=np.nan
tn_dict_4['default']=np.nan
tn_dict_4.loc[tn_dict_4.var_type.isin(['varchar(100)','string','varchar(500)']),'var_type']='字符型'
tn_dict_4.loc[tn_dict_4.var_type.isin(['int','double']),'var_type']='数据型'
tn_dict_4.loc[tn_dict_4.var_type.isin(['timestamp']),'var_type']='日期型'
tn_dict_4.loc[tn_dict_4.var_type.isin(['字符型']),'default']=""
tn_dict_4.loc[tn_dict_4.var_type.isin(['数据型']),'default']=-99
tn_dict_4.loc[tn_dict_4.var_type.isin(['日期型']),'default']=99991231
tn_dict_4=tn_dict_4[['var_desc','var_type','length','var_name','var_code_comment','default']].drop_duplicates()

tn_dict = tn_dict_1.append(tn_dict_2).append(tn_dict_3).append(tn_dict_4)
tn_dict = tn_dict.drop_duplicates('var_name')

tn_dict['var_name'] = tn_dict.var_name.str.lower()
de_dict = pd.merge(tn_dict, pd.DataFrame(final_data.columns.tolist()), left_on='var_name', right_on=0, how='inner').drop(0,axis=1)
del tn_dict_1,tn_dict_2,tn_dict_3,tn_dict_4,tn_dict
#de_dict.to_excel('DE_Var_Select_20190507.xlsx',index=False)


'''
## 2.2 变量预处理---对变量进行质量评估，手动进行数据清洗，包括剔除缺失率非常高的变量、单一值变量以及其他明显无法使用的变量
'''

de_dict_var = de_dict.copy()
for i, _ in de_dict.iterrows():
    name = de_dict_var.loc[i, 'var_name']
    default = de_dict_var.loc[i, 'default']
    if default != '""' and name in set(final_data.columns) and name!='app_applycode':
        try:
            final_data[name] = final_data[name].astype('float64')
            if (final_data[name] == float(default)).sum() > 0:
                final_data.loc[final_data[name] == float(default), name] = np.nan
        except:
            pass

    elif default == '""' and name in set(final_data.columns) and name!='app_applycode':
        try:
            final_data[name] = final_data[name].astype('float64')
            if (final_data[name] == float(-99)).sum() > 0:
                final_data.loc[final_data[name] == float(-99), name] = np.nan
            if (final_data[name] == '-99').sum() > 0:
                final_data.loc[final_data[name] == '-99', name] = np.nan
        except:
            pass

## 统计各变量的质量情况,包括变量的总体缺失率、取不同值个数、按月统计变量的缺失率等

#de_dict_var['null_percents'] = de_dict_var.var_name.map(lambda x: final_data[x].isnull().sum() / final_data.shape[0])  ##变量的总体缺失率
#de_dict_var['different_values'] = de_dict_var.var_name.map(lambda x: len(final_data[x].unique()))  # 计算变量取值个数，包括缺失值
#de_dict_var['whether_null'] = (de_dict_var['null_percents'] > 0).astype('int64')  # 变量是否缺失
#de_dict_var['different_values'] = de_dict_var['different_values'] - de_dict_var['whether_null']  # 计算除了缺失值后的变量取值个数
#
#applymonth = final_data.app_applydate.str.slice(0, 7)  # 取申请时间的月份
#whether_null_matrix = final_data.isnull().astype('float64').groupby(applymonth)[final_data.columns.tolist()].mean()  # 按月统计变量的缺失率
#whether_null_matrix = whether_null_matrix.T
#whether_null_matrix['mean_null_percents'] = whether_null_matrix.mean(axis=1)  # 按月平均缺失率
#whether_null_matrix['null_percents_std/mean'] = whether_null_matrix.std(axis=1) / whether_null_matrix.mean(axis=1)  # 按月缺失率标准差与均值的比值
#whether_null_matrix = whether_null_matrix.reset_index().rename(columns={'index': 'var_name'})
#
#de_dict_vars = pd.merge(de_dict_var, whether_null_matrix, on='var_name', how='inner')  # 变量评估，后台根据变量的质量指标进行手动清洗变量
#del  whether_null_matrix,applymonth
#
#de_dict_vars['是否选用']='是'
#de_dict_vars['不选用的原因']=np.nan
#de_dict_vars.loc[de_dict_vars['null_percents']>=1,'是否选用']='否'
#de_dict_vars.loc[de_dict_vars['null_percents']>=1,'不选用的原因']='完全缺失'
#de_dict_vars.loc[(de_dict_vars['null_percents']>=0.95) & (de_dict_vars['null_percents']<1),'是否选用']='否'
#de_dict_vars.loc[(de_dict_vars['null_percents']>=0.95) & (de_dict_vars['null_percents']<1),'不选用的原因']='缺失非常严重'
#de_dict_vars.loc[de_dict_vars['different_values'].isin([1]) ,'是否选用']='否'
#de_dict_vars.loc[de_dict_vars['different_values'].isin([1]),'不选用的原因']='单一值变量'
#de_dict_vars1=pd.read_excel('de_dict_vars_20190425v1.xlsx')
#de_dict_vars=pd.merge(de_dict_vars.drop(['是否选用','不选用的原因'],axis=1),de_dict_vars1[['var_name','数据源','是否选用','不选用的原因']],on='var_name',how='left')
##de_dict_vars.to_excel('de_dict_vars_20190507v1.xlsx',index=False)
#del de_dict_vars1,de_dict_vars



'''
##2.3 变量预处理--针对不同的数据类型进行预处理
'''

vars_count_table=pd.read_excel('de_dict_vars_20190507v1.xlsx')
choose_columns_table = vars_count_table[vars_count_table['是否选用'].isin(['是'])]
numeric_columns = choose_columns_table.loc[choose_columns_table.var_type.isin(['\ufeff数据型','数据型', 'bigint']), 'var_name'].values.tolist()
str_columns = choose_columns_table.loc[choose_columns_table.var_type.isin(['字符型', '\ufeff字符型','字符型 ' ]), 'var_name'].values.tolist()
date_columns = choose_columns_table.loc[choose_columns_table.var_type.isin(['\ufeff日期型','日期型']), 'var_name'].values.tolist()
final_data = final_data.replace('\\N',np.nan)
#final_data.to_excel('经过初筛后的放款数据_20190507.xlsx',index=False)


'''
##  处理数据型变量，包括异常值处理等
'''

# 列出数据型变量异常值并对异常值进行处理 ，有l6m_avg_net_flow、l6m_avg_total_amount、net_flow、total_amount、jxl_call_num_aver_6months中出现负值
for col in numeric_columns: 
    try:
        final_data[col]=final_data[col].astype('float64')
        if final_data.loc[final_data[col] < 0, col].shape[0] > 0:
            print(col + ':', final_data.loc[final_data[col] < 0, col].unique(),
                  final_data.loc[final_data[col] < 0, col].shape[0]/final_data.shape[0])
            final_data.loc[final_data[col] < 0, col] = np.nan
    except: 
        pass

   
'''
##  处理日期型变量，将日期变量转为距离申请日期的天数
'''
for col in date_columns:  # 去除异常的时间
    try:
        final_data.loc[final_data[col] >= '2030-01-01', col] = np.nan
    except:
        pass


def date_cal(x, app_applydate):  # 计算申请日期距离其他日期的天数
    days_dt = pd.to_datetime(app_applydate) - pd.to_datetime(x)
    return days_dt.dt.days


for col in date_columns:
    if col != 'app_applydate':
        try:
            if col not in ['vehicle_minput_drivinglicensevaliditydate']:
                final_data[col] = date_cal(final_data[col], final_data['app_applydate'])
                final_data.loc[final_data[col] < 0, col] = np.nan
            else:
                final_data[col] = date_cal(final_data['app_applydate'], final_data[col])  # 计算行驶证有效期限距离申请日期的天数
        except:
            pass


'''
##  处理字符型变量，将一些不统计的取值统一
'''

for col in str_columns:  # 列出字符变量的不同取值
    print(col + ':', final_data[col].unique())

abnorm_str_columns = [ 'apt_facetrial_marry','jxl_110_record','jxl_120_record','jxl_macau_phone_record','jxl_court_phone_record',
                      'jxl_law_phone_record','jxl_id_operator','jxl_name_operator','apt_education','tx_cardid']

final_data.loc[final_data.apt_facetrial_marry.isin(['已婚']), 'apt_facetrial_marry'] = 2
final_data.loc[final_data.apt_facetrial_marry.isin(['未婚']), 'apt_facetrial_marry'] = 3
final_data.loc[final_data.apt_facetrial_marry.isin(['离异']), 'apt_facetrial_marry'] = 4  # 处理变量apt_facetrial_marry
final_data.loc[final_data.apt_facetrial_marry.isin(['丧偶']), 'apt_facetrial_marry'] = 5
final_data.loc[final_data.apt_facetrial_marry.isin(['其他']), 'apt_facetrial_marry'] = 6
final_data.apt_facetrial_marry = final_data.apt_facetrial_marry.astype('float64')

final_data.loc[final_data.jxl_110_record.isin(['偶尔通话(3次以内，包括3次)','多次通话(3次以上)']),'jxl_110_record']='有'
final_data.loc[final_data.jxl_110_record.isin(['无通话记录']),'jxl_110_record']='无'
final_data.loc[final_data.jxl_110_record.isin(['无数据']),'jxl_110_record']=np.nan

final_data.loc[final_data.jxl_120_record.isin(['偶尔通话(3次以内，包括3次)','多次通话(3次以上)']),'jxl_120_record']='有'
final_data.loc[final_data.jxl_120_record.isin(['无通话记录']),'jxl_120_record']='无'
final_data.loc[final_data.jxl_120_record.isin(['无数据']),'jxl_120_record']=np.nan

final_data.loc[final_data.jxl_macau_phone_record.isin(['偶尔通话(3次以内，包括3次)','多次通话(3次以上)']),'jxl_macau_phone_record']='有'
final_data.loc[final_data.jxl_macau_phone_record.isin(['无通话记录']),'jxl_macau_phone_record']='无'
final_data.loc[final_data.jxl_macau_phone_record.isin(['无数据']),'jxl_macau_phone_record']=np.nan

final_data.loc[final_data.jxl_court_phone_record.isin(['偶尔通话(3次以内，包括3次)','多次通话(3次以上)']),'jxl_court_phone_record']='有'
final_data.loc[final_data.jxl_court_phone_record.isin(['无通话记录']),'jxl_court_phone_record']='无'
final_data.loc[final_data.jxl_court_phone_record.isin(['无数据']),'jxl_court_phone_record']=np.nan

final_data.loc[final_data.jxl_id_operator.isin(['运营商未提供身份证号码']),'jxl_id_operator']='运营商未提供身份证号'
final_data.loc[final_data.jxl_id_operator.isin(['匹配']),'jxl_id_operator']='成功'
final_data.loc[final_data.jxl_id_operator.isin(['不匹配']),'jxl_id_operator']='失败'

final_data.loc[final_data.jxl_name_operator.isin(['匹配']),'jxl_name_operator']='成功'
final_data.loc[final_data.jxl_name_operator.isin(['不匹配']),'jxl_name_operator']='失败'


final_data.loc[final_data.apt_education.isin(['本科或以上']), 'apt_education'] = 1
final_data.loc[final_data.apt_education.isin(['本科']), 'apt_education'] = 2
final_data.loc[final_data.apt_education.isin(['大专']), 'apt_education'] = 3  # 处理变量apt_facetrial_marry
final_data.loc[final_data.apt_education.isin(['高中及高中以下']), 'apt_education'] = 4
final_data.apt_education = final_data.apt_education.astype('float64')

final_data.loc[final_data.tx_cardid.isin(['NO_DATA']),'tx_cardid']='NO_DA'
final_data.loc[final_data.tx_cardid.isin(['DIFFERENT']),'tx_cardid']='DIFFE'



'''
##2.4 变量衍生,衍生了4个变量
'''

## 数值型变量衍生

final_data['vehicle_illegal_avgpenaltypoints']=final_data['vehicle_illegal_penaltypoints']/final_data['vehicle_illegal_num'] #车辆信息.违章信息.违章总扣分/次数
final_data.loc[final_data['vehicle_illegal_avgpenaltypoints']==np.inf,'vehicle_illegal_avgpenaltypoints']=np.nan
final_data.loc[(final_data['vehicle_illegal_penaltypoints']==0) & (final_data['vehicle_illegal_num']==0),'vehicle_illegal_avgpenaltypoints']=0


final_data['vehicle_insurance_claimsavgamount']=final_data['vehicle_insurance_claimstotalamount']/final_data['vehicle_insurance_claimsnum'] #车辆信息.保险信息.理赔总金额/次数
final_data.loc[final_data['vehicle_insurance_claimsavgamount']==np.inf,'vehicle_insurance_claimsavgamount']=np.nan
final_data.loc[(final_data['vehicle_insurance_claimstotalamount']==0) & (final_data['vehicle_insurance_claimsnum']==0),'vehicle_insurance_claimsavgamount']=0


final_data['apply_segment']=1
final_data.loc[final_data.app_applydate.str.slice(11,13).astype('int')<12,'apply_segment']=0  ##申请日期衍生，前半段为1，后半段为0

final_data['age_and_gender']=1
final_data.loc[(final_data.apt_age>=39) & (final_data.apt_gender.isin(['男'])),'age_and_gender']=0  ##年龄与性别组合
final_data.loc[(final_data.apt_gender.isin(['女'])),'age_and_gender']=0

#pd.crosstab(index=pd.qcut(my_data['apt_comp_experienceyears'],10),columns=my_data['apt_gender'],values=my_data['y'],aggfunc='mean',margins=True)


'''
## 3.4 将样本拆分成训练集、测试集以及验证集，利用逾期情况对字符型变量或者其他变量分箱操作
'''

model_data=final_data.loc[(pd.to_datetime(final_data.app_applydate)<pd.to_datetime('2018-08-01 00:00:00'))  & 
                          (pd.to_datetime(final_data.app_applydate)>=pd.to_datetime('2017-07-01 00:00:00')),:]
outoftime_data=final_data.loc[(pd.to_datetime(final_data.app_applydate)>=pd.to_datetime('2018-08-01 00:00:00')),:]

y = model_data['y']
x = model_data.drop('y',axis=1)
x_train,x_test,y_train,y_test=train_test_split(x, y, test_size=0.3,stratify = y ,random_state=0)


## 根据训练集上的单变量分析，绘制变量的逾期分布图，确定将字符变量转成什么样的哑变量
def single_analyze(x, y, var_name):
    var_data = x[var_name].copy()
    try:
        var_data = var_data.astype('float64')
        var_data[var_data.isnull()] = -99
    except:
        var_data[var_data.isnull()] = '-99'

    var_name_overdue_analyze1 = pd.crosstab(var_data, y, margins=True).rename(columns={0.0: 'good_num', 1.0: 'bad_num', 'All': 'total_num'}).reset_index()
    var_name_overdue_analyze2 = var_name_overdue_analyze1[['good_num', 'bad_num', 'total_num']].div(var_name_overdue_analyze1['total_num'], axis=0).rename(columns={'good_num': 'good_percents', 'bad_num': 'bad_percents', 'total_num': 'total_percents'})
    var_name_overdue_analyze2[var_name] = var_name_overdue_analyze1[var_name].copy()
    var_name_overdue_analyze = pd.merge(var_name_overdue_analyze1, var_name_overdue_analyze2, on=var_name, how='inner')

    plt.cla()
    var_name_overdue_analyze3 = pd.crosstab(var_data, y, margins=True).rename(columns={0.0: 'good_num', 1.0: 'bad_num', 'All': 'total_num'})
    var_name_overdue_analyze3 = var_name_overdue_analyze3.div(var_name_overdue_analyze3['total_num'], axis=0).drop('All', axis=0)
    var_name_overdue_analyze3.bad_num.plot(kind='bar', color='k', alpha=0.7, title='overdue_percents')
    plt.savefig('D:/llm/车贷新增模型二期/结果/字符变量分布情况以及逾期情况/single_figure/' + var_name + '.png')

    var_name_overdue_analyze.to_excel('D:/llm/车贷新增模型二期/结果/字符变量分布情况以及逾期情况/single_analyze/' + var_name + '.xlsx',index=False)

    return var_name_overdue_analyze


for var_name in str_columns:
    var_name_overdue_analyze = single_analyze(x_train[choose_columns_table['var_name'].values.tolist()],y_train, var_name)
    


## 哑变量衍生
model_data['apt_education_4'] = model_data.loc[:, 'apt_education'].isin([4]).astype('float64')
model_data['apt_facetrial_householdregister_2n3'] = model_data.loc[:, 'apt_facetrial_householdregister'].isin([2,3]).astype('float64')
model_data['apt_facetrial_housetype_1n2'] = model_data.loc[:, 'apt_facetrial_housetype'].isin([1,2]).astype('float64')
model_data['apt_facetrial_marry_1n2'] = model_data.loc[:, 'apt_facetrial_marry'].isin([1,2]).astype('float64')
model_data['apt_facetrial_residertogether_1n3n4'] = model_data.loc[:, 'apt_facetrial_residertogether'].isin([1,3,4]).astype('float64')  ##独居或和朋友同住
model_data['apt_gender_0'] = model_data.loc[:, 'apt_gender'].isin(['女']).astype('float64')
model_data['id_fin_black_arised_1'] = model_data.loc[:, 'id_fin_black_arised'].isin([1]).astype('float64')
model_data['vehicle_buymode_2'] = model_data.loc[:, 'vehicle_buymode'].isin([2]).astype('float64')
model_data['vehicle_minput_lastmortgagerinfo_null'] = ((model_data.loc[:, 'vehicle_minput_lastmortgagerinfo'].isin([3])) | (model_data.loc[:, 'vehicle_minput_lastmortgagerinfo'].isnull())).astype('float64')
model_data['vehicle_minput_registcertflag_1'] = model_data.loc[:, 'vehicle_minput_registcertflag'].isin([1]).astype('float64')


dummy_columns = [ 'apt_education_4', 'apt_facetrial_householdregister_2n3', 'apt_facetrial_housetype_1n2',
                 'apt_facetrial_marry_1n2', 'apt_facetrial_residertogether_1n3n4','apt_gender_0', 'id_fin_black_arised_1',
                 'vehicle_buymode_2','vehicle_minput_lastmortgagerinfo_null','vehicle_minput_registcertflag_1']


# 衍生后的变量间的相关性分析
 
columns_corrcoef = model_data.drop(str_columns, axis=1).corr()

for col in model_data:
    if model_data[col].isnull().sum() > 0 and col!='y':
        model_data.loc[model_data[col].isnull(), col] = -998


 #选择入模前的最终变量

date_columns.remove('app_applydate')  # 去掉申请日期后的日期变量集合
date_columns.remove('query_time')
numeric_columns.append('vehicle_illegal_avgpenaltypoints')
numeric_columns.append('vehicle_insurance_claimsavgamount')
numeric_columns.append('apply_segment')
numeric_columns.append('age_and_gender')
numeric_columns.append('province_consume')

print(len(numeric_columns))  # 689
print(len(date_columns))  # 9
print(len(dummy_columns))  # 10


'''
## 汇集好坏样本，单变量分析 (用 R作图)
'''

full_data = model_data.copy()
sample_data=full_data[full_data.y.notnull()].copy()
sample_data.to_csv('所有新增建模集数据_20190514.csv',index=False)



'''
## 4. 模型训练
'''

## 拆分训练集和验证集
ori_columns = numeric_columns + date_columns + dummy_columns
y = model_data['y']
x = model_data[ori_columns]
x_train,x_test,y_train,y_test=train_test_split(x, y, test_size=0.3,stratify = y ,random_state=0)


## 依据模型按重要性将相关性较低的变量去除

columns = numeric_columns + date_columns + dummy_columns
clf=XGBClassifier(learning_rate=0.05,
                  min_child_weight=0.8,
                  max_depth=5,
                  gamma=20,
                  n_estimators=300,
                   random_state=0,objective='binary:logistic')

### 去除相关性比较强的变量
clf.fit(x_train[columns], y_train)
pred_p = clf.predict_proba(x_train[columns])[:, 1]
a0 = clf.feature_importances_.tolist()
feature_importance = pd.DataFrame({'var_name': columns, 'importance': a0}).sort_values('importance', ascending=False)
importances=pd.DataFrame(np.array(a0), index=columns,columns=['importance'])
del_columns=[]
del_desc={}
for onecol in ori_columns:
    meet_columns=columns_corrcoef.loc[columns_corrcoef[onecol].abs()>=0.50,:].index
    meet_importances=importances.loc[meet_columns,:]
    del_columns1=meet_importances.loc[meet_importances['importance']<meet_importances['importance'].max(),:].index.tolist()
    del_columns2=meet_importances.loc[meet_importances['importance']>=meet_importances['importance'].max(),:].index.tolist()
    del_desc2={}
    for cn in meet_importances.index:
        del_desc2[cn]=meet_importances.loc[cn,'importance']
    if len(del_columns1)!=0 and len(del_columns2)!=0:
        del_desc[del_columns2[0]]=del_desc2
    del_columns.extend(del_columns1)
final_columns=[col for col in columns if col not in del_columns]
print(len(final_columns))



##  选取在模型中重要性不小于给定阈值的变量

a=range(len(final_columns)+1)
tol=0.03

while (len(a)>len(final_columns)):    
    ## 训练模型并估计参数    
    clf.fit(x_train[final_columns], y_train)     
    pred_p = clf.predict_proba(x_train[final_columns])[:,1]
    fpr, tpr, th = roc_curve(y_train, pred_p)
    ks = tpr - fpr
    pred_p2 = clf.predict_proba(x_test[final_columns])[:,1]
    fpr, tpr, th = roc_curve(y_test, pred_p2)
    ks2 = tpr - fpr
    a = clf.feature_importances_.tolist()
    print(final_columns)
    print('len(final_columns)= ', len(final_columns))
    print('minimum feature importance = ', min(a))
    print('train ks: ' + str(max(ks)))
    print('test ks:  ' + str(max(ks2)))

    if( min(a) < tol ):
        b = (clf.feature_importances_ == min(a))
        final_columns = [final_columns[i] for i in range(len(final_columns)) if b[i]==False]

## 取30个变量





'''
# 最终模型
'''

columns=['vehicle_minput_chargetimes',
	'vehicle_minput_transfertimes',
	'yx_otherorgan_times',
	'times_by_current_org',
	'call_time_rank2',
	'contact_each_other_rate',
	'contact_credit_card_call_len',
	'contact_loan_contact_afternoon',
	'contact_operator_call_out_len',
	'max_call_in_time_l6m',
	'max_sms_cnt_l6m',
	'max_total_amount_l6m',
	'check_sjjm_pass',
	'phone_gray_score',
	'coll_contact_avg_sms_cnt',
	'jxl_tel_length',
	'jxl_black_dir_cont_num',
	'vehicle_illegal_num',
	'vehicle_illegal_penaltypoints',
	'operator_max_interact_cnt_l6m',
	'jxl_id_comb_othertel_num',
	'other_avg_interact_cnt_l6m',
	'age_and_gender',
	'vehicle_minput_obtaindate',
	'vehicle_minput_firstregistdate',
	'vehicle_minput_lastreleasedate',
	'apt_facetrial_housetype_1n2',
	'vehicle_minput_lastmortgagerinfo_null',
	'vehicle_minput_registcertflag_1',
	'province_consume']


print(len(columns))
clf=XGBClassifier(learning_rate=0.02,
                  min_child_weight=0.8,
                  max_depth=5,
                  gamma=15,
                  n_estimators=250,
                  objective='binary:logistic',random_state=0)
clf.fit(x_train[columns], y_train)
a = clf.feature_importances_.tolist()
pred_p = clf.predict_proba(x_train[columns])[:, 1]
fpr, tpr, th = roc_curve(y_train, pred_p)
ks = tpr - fpr
pred_p2 = clf.predict_proba(x_test[columns])[:, 1]
fpr, tpr, th = roc_curve(y_test, pred_p2)
ks2 = tpr - fpr

feature_importance = pd.DataFrame({'var_name': columns, 'importance': a}).sort_values('importance', ascending=False)
feature_importance = pd.merge(feature_importance, choose_columns_table[['var_name', 'var_desc']], on='var_name', how='left')[['var_name', 'var_desc', 'importance']]
print(feature_importance)
print('train ks: ' + str(max(ks)))
print('test ks:  ' + str(max(ks2)))

pickle.dump(clf, open('E:/liaoliming/重要文档/车贷数据/新增二期模型开发_20190411/结果/newcar2_xgb_v1_20190717.pkl', 'wb'))
feature_importance.to_excel('E:/liaoliming/重要文档/车贷数据/新增二期模型开发_20190411/结果/feature_importance_20190717.xlsx',index=False)


'''
## 模型表现 
'''

pred_p = clf.predict_proba(x_train[columns])[:, 1]
min_scores = r_p_chart(y_train, pred_p, part=20)
min_scores = [round(i, 5) for i in min_scores]
min_scores[19] = 0
cuts = [round(min_scores[i] * 100.0, 3) for i in range(20)[::-1]] + [100.0]

print('训练集')
pred_p = clf.predict_proba(x_train[columns])[:, 1]
fpr, tpr, th = roc_curve(y_train, pred_p)
ks = tpr - fpr
print('train ks: ' + str(max(ks)))
print(roc_auc_score(y_train, pred_p))
r_p_chart2(y_train, pred_p, min_scores, part=20)

print('测试集')
pred_p2 = clf.predict_proba(x_test[columns])[:, 1]
fpr, tpr, th = roc_curve(y_test, pred_p2)
ks2 = tpr - fpr
print('test ks:  ' + str(max(ks2)))
print(roc_auc_score(y_test, pred_p2))
r_p_chart2(y_test, pred_p2, min_scores, part=20)

print('建模全集')
pred_p3 = clf.predict_proba(x[columns])[:, 1]
fpr, tpr, th = roc_curve(y, pred_p3)
ks3 = tpr - fpr
print('all ks:   ' + str(max(ks3)))
print(roc_auc_score(y, pred_p3))
r_p_chart2(y, pred_p3, min_scores, part=20)




'''
时间外验证
'''

outoftime_data['apt_education_4'] = outoftime_data.loc[:, 'apt_education'].isin([4]).astype('float64')
outoftime_data['apt_facetrial_householdregister_2n3'] = outoftime_data.loc[:, 'apt_facetrial_householdregister'].isin([2,3]).astype('float64')
outoftime_data['apt_facetrial_housetype_1n2'] = outoftime_data.loc[:, 'apt_facetrial_housetype'].isin([1,2]).astype('float64')
outoftime_data['apt_facetrial_marry_1n2'] = outoftime_data.loc[:, 'apt_facetrial_marry'].isin([1,2]).astype('float64')
outoftime_data['apt_facetrial_residertogether_1n3n4'] = outoftime_data.loc[:, 'apt_facetrial_residertogether'].isin([1,3,4]).astype('float64')  ##独居或和朋友同住
outoftime_data['apt_gender_0'] = outoftime_data.loc[:, 'apt_gender'].isin(['女']).astype('float64')
outoftime_data['id_fin_black_arised_1'] = outoftime_data.loc[:, 'id_fin_black_arised'].isin([1]).astype('float64')
outoftime_data['vehicle_buymode_2'] = outoftime_data.loc[:, 'vehicle_buymode'].isin([2]).astype('float64')
outoftime_data['vehicle_minput_lastmortgagerinfo_null'] = ((outoftime_data.loc[:, 'vehicle_minput_lastmortgagerinfo'].isin([3])) | (outoftime_data.loc[:, 'vehicle_minput_lastmortgagerinfo'].isnull())).astype('float64')
outoftime_data['vehicle_minput_registcertflag_1'] = outoftime_data.loc[:, 'vehicle_minput_registcertflag'].isin([1]).astype('float64')

outof_data_x=outoftime_data[columns]
outof_data_y=outoftime_data['y']
for cn in outof_data_x:
    if outof_data_x[cn].isnull().sum()>0:
        outof_data_x.loc[outof_data_x[cn].isnull(),cn]=-998

print('时间外验证')
pred_p4= clf.predict_proba(outof_data_x)[:, 1]
fpr, tpr, th = roc_curve(outof_data_y, pred_p4)
ks3 = tpr - fpr
print('all ks:   ' + str(max(ks3)))
print(roc_auc_score(outof_data_y, pred_p4))
r_p_chart2(outof_data_y, pred_p4, min_scores, part=20)



'''
## 入模变量稳定性分析,要包含取值分布、逾期分布，均值分布、缺失分布、iv和ks的计算等
'''

## 统计均值
xx_data_s=pd.concat([model_data[['app_applydate']+columns],outoftime_data[['app_applydate']+columns]])
xx_data_s[xx_data_s==-998]=np.nan
xx_data_s['applymonth']=xx_data_s['app_applydate'].str.slice(0,7)
vars_mean_count=xx_data_s.groupby(xx_data_s['applymonth'])[xx_data_s.columns.tolist()].mean().T.reset_index().rename(columns={'index':'var_name'})
vars_mean_count=pd.merge(vars_mean_count,choose_columns_table[['var_name','var_desc']],on='var_name',how='left')
vars_mean_count.set_index('var_name').ix[columns,:].reset_index().to_excel('所有入模变量的均值分布_20190514v1.xlsx',index=False)
del xx_data_s,vars_mean_count

## 统计缺失率
xx_data_s=pd.concat([model_data[['app_applydate']+columns],outoftime_data[['app_applydate']+columns]])
xx_data_s[xx_data_s==-998]=np.nan
applymonth=xx_data_s['app_applydate'].str.slice(0,7)
xx_data_s=xx_data_s.drop('app_applydate',axis=1).isnull().astype('float64')
null_percents_count = xx_data_s.groupby(applymonth)[xx_data_s.columns.tolist()].mean().T.reset_index().rename(columns={'index': 'var_name', 'applymonth': '申请月份'})
null_percents_count=pd.merge(null_percents_count,choose_columns_table[['var_name','var_desc']],on='var_name',how='left')
null_percents_count.set_index('var_name').ix[columns,:].reset_index().to_excel('所有入模变量的缺失率分布_20190514v1.xlsx',index=False)
del xx_data_s,null_percents_count

## 取值分布，主要针对字符型变量
request_cols=['app_applydate','apt_education', 'apt_facetrial_householdregister', 'apt_facetrial_housetype',
                 'apt_facetrial_marry', 'apt_facetrial_residertogether','apt_gender', 'id_fin_black_arised',
                 'vehicle_buymode','vehicle_minput_lastmortgagerinfo','vehicle_minput_registcertflag']
xx_data_s=pd.concat([model_data[request_cols],outoftime_data[request_cols]])
xx_data_s['applymonth']=xx_data_s['app_applydate'].str.slice(0,7)
dummy_mean_count=pd.crosstab(xx_data_s['applymonth'],xx_data_s['apt_education'],margins=True)
dummy_mean_count=dummy_mean_count.div(dummy_mean_count['All'],axis=0).drop('All',axis=1).reset_index()

request_cols2=['apt_facetrial_householdregister', 'apt_facetrial_housetype',
                 'apt_facetrial_marry', 'apt_facetrial_residertogether','apt_gender', 'id_fin_black_arised',
                 'vehicle_buymode','vehicle_minput_lastmortgagerinfo','vehicle_minput_registcertflag']
for cn in request_cols2:
    try:
       dummy_mean_count_1 = pd.crosstab(xx_data_s['applymonth'], xx_data_s[cn], margins=True)
    except:
       xx_data_s[cn]=xx_data_s[cn].astype('str')
       dummy_mean_count_1 = pd.crosstab(xx_data_s['applymonth'], xx_data_s[cn], margins=True)

    dummy_mean_count_1 = dummy_mean_count_1.div(dummy_mean_count_1['All'], axis=0).drop('All', axis=1).reset_index()
    dummy_mean_count=pd.merge(dummy_mean_count,dummy_mean_count_1,on='applymonth',how='inner')

dummy_mean_count.to_excel('哑变量均值按月统计_20190508v1.xlsx',index=False)
del request_cols,xx_data_s,dummy_mean_count,request_cols2,dummy_mean_count_1

## 逾期分布
def achieve_score_ks(ja_analyzedata,col,times_term,segment_num=10,cuts_min_scores=None):
   gd_apply_termdata = ja_analyzedata[[col,times_term]].copy()
   gd_apply_termdata['applymonth']=ja_analyzedata['app_applydate'].str.slice(0,7)
   
   try:
        gd_apply_termdata[col] = gd_apply_termdata[col].astype('float64')
        gd_apply_termdata.loc[gd_apply_termdata[col].isnull(),col] = -99
   except:
        gd_apply_termdata.loc[gd_apply_termdata[col].isnull(),col]  = '-99'

   whether_str=1
   try:
      gd_apply_termdata[col]=gd_apply_termdata[col].astype('float64')
      whether_str=0
   except:
      gd_apply_termdata[col] = gd_apply_termdata[col].astype('str')

   if   whether_str==1:
       cuts=gd_apply_termdata[col].unique().tolist()
   elif  len(gd_apply_termdata[col].unique())<=segment_num:
       cuts=gd_apply_termdata[col].unique().tolist()
   else:
       min_value=gd_apply_termdata[col].min()
       if  min_value<0:
           middle_cuts=np.unique(gd_apply_termdata.loc[gd_apply_termdata[col].isin([-99])==False,col].quantile(np.arange(0,1+1/segment_num,1/segment_num)).values).tolist()
           middle_cuts[0]=0
           middle_cuts.append(-998)
           cuts=np.unique(np.array(middle_cuts)).tolist()
           cuts[len(cuts)-1]=np.inf
       else:
           cuts = np.unique(gd_apply_termdata[col].quantile(np.arange(0, 1 + 1 / segment_num, 1/segment_num)).values).tolist()
           cuts[len(cuts) - 1] = np.inf
       if cuts_min_scores==None:
          gd_apply_termdata[col]=pd.cut(gd_apply_termdata[col],cuts,right=False)
       else:
          gd_apply_termdata[col] = pd.cut(gd_apply_termdata[col], cuts_min_scores, right=False)
   gd_apply_termdata['applymonth']=gd_apply_termdata['applymonth'].astype('str')
   col_overdue_crosstab=gd_apply_termdata.groupby(['applymonth']+[col])[times_term].agg(['count','sum','mean']).reset_index()
   
   
   return  col_overdue_crosstab


xx_data_s=pd.concat([model_data[['app_applydate']+columns+['y']],outoftime_data[['app_applydate']+columns+['y']]])
for cn  in  columns:
        col_overdue_crosstab=achieve_score_ks(xx_data_s,cn,'y',5)
        col_overdue_crosstab.to_csv('D:/llm/车贷新增模型二期/结果/入模变量逾期分布/'+cn+'.csv',index=False)
del  xx_data_s,col_overdue_crosstab




     
'''
## 对全量申请样本进行评分，可选择申请月份
'''
vars_count_table=pd.read_excel('de_dict_vars_20190305v1.xlsx')
choose_columns_table = vars_count_table[vars_count_table.whether_choose == 1]
numeric_columns_s = choose_columns_table.ix[choose_columns_table.var_type == '\ufeff数据型', 'var_name'].values.tolist()
str_columns_s = choose_columns_table.ix[choose_columns_table.var_type == '\ufeff字符型', 'var_name'].values.tolist()
date_columns_s = choose_columns_table.ix[choose_columns_table.var_type == '\ufeff日期型', 'var_name'].values.tolist()


'''
计算新增客户申请评分二期模型分数
'''
choose_columns=['vehicle_minput_chargetimes',
 'vehicle_minput_transfertimes',
 'yx_otherorgan_times',
 'times_by_current_org',
 'call_time_rank2',
 'contact_each_other_rate',
 'contact_credit_card_call_len',
 'contact_loan_contact_afternoon',
 'contact_shops_call_in_len',
 'contact_operator_call_out_len',
 'max_call_in_time_l6m',
 'max_sms_cnt_l6m',
 'max_total_amount_l6m',
 'vehicle_mileage',
 'check_sjjm_pass',
 'phone_gray_score',
 'coll_contact_avg_sms_cnt',
 'jxl_tel_length',
 'jxl_black_dir_cont_num',
 'jxl_contact1_num',
 'vehicle_illegal_num',
 'vehicle_illegal_penaltypoints',
 'operator_max_interact_cnt_l6m',
 'jxl_id_comb_othertel_num',
 'amount_segment1_num',
 'amount_segment3_percents',
 'amount_segment4_percents',
 'other_avg_interact_cnt_l6m',
 'jxl_tel_comb_othername_num',
 'vehicle_minput_obtaindate',
 'vehicle_minput_firstregistdate',
 'cell_reg_time',
 'vehicle_minput_lastreleasedate',
 'apt_education',
 'apt_facetrial_housetype',
 'vehicle_minput_lastmortgagerinfo',
 'vehicle_minput_registcertflag',
 'app_applydate','apt_age','apt_gender','app_siteprovince']

tn_dict=pd.read_excel('决策引擎变量表.xlsx')
tn_dict_3=pd.read_excel('三方数据整合表字典.xlsx',sheet_name='字典')
tn_dict_4=pd.read_excel('聚信立报告_宜信字典_整合祥业和利明的工作.xlsx')


dt_cols=[cn for cn in choose_columns if cn in tn_dict['var_name'].map(lambda x: x.lower()).values]
zy_cols=[cn for cn in choose_columns if cn in tn_dict_3['字段名'].map(lambda x: x.lower()).values]
lxy_cols=[cn for cn in choose_columns if cn in tn_dict_4['字段名'].map(lambda x: x.lower()).values]
request_cols=dt_cols+['app_applycode','last_update_date','app_callpoint','loan_time']

mdata_0 = pd.read_table('./data_20180702.txt', delimiter='\u0001', dtype={'app_applycode': str}) #读取决策引擎入参数据，从tbd中提取
mdata_0=mdata_0.replace('\\N',np.nan)
mdata_0=mdata_0.loc[mdata_0.app_applycode.notnull(),request_cols]
mdata_0 = mdata_0.sort_values(['app_applycode', 'last_update_date']).drop_duplicates('app_applycode', keep='last')

mdata_1 = pd.read_table('data_20180701-20190314.txt', delimiter='\u0001', dtype={'app_applycode': str}) #读取决策引擎入参数据，从tbd中提取
mdata_1=mdata_1.replace('\\N',np.nan)
mdata_1=mdata_1.loc[mdata_1.app_applycode.notnull(),request_cols]
mdata_1 = mdata_1.sort_values(['app_applycode', 'last_update_date']).drop_duplicates('app_applycode', keep='last')

mdata_2=pd.concat([mdata_0,mdata_1])
del mdata_0,mdata_1
mdata_2 = mdata_2.sort_values(['app_applycode', 'last_update_date']).drop_duplicates('app_applycode', keep='last')

apply_contract_report = pd.read_table('applycode_20190416.txt',sep='\u0001',dtype={'applycode':str})  #车贷申请表
apply_contract_report=apply_contract_report.replace('\\N',np.nan)
apply_contract_report = apply_contract_report[(apply_contract_report.applycode.isnull() == False)].sort_values(['applycode','applydate']).drop_duplicates('applycode',keep='last')
mdata_3 = pd.merge(mdata_2, apply_contract_report, left_on='app_applycode', right_on='applycode', how='inner')
del apply_contract_report,mdata_2
mdata_3 = mdata_3.sort_values(['app_applycode', 'last_update_date']).drop_duplicates('app_applycode', keep='last')
mdata_3['applymonth'] = mdata_3.app_applydate.str.slice(0, 7)  # 生成申请月份
mdata_3['loantime_m']=mdata_3['loan_time'].copy()
mdata_3.loc[mdata_3.loantime_m.isin([1, 3, 6,12, 24, 36]) == False, 'loantime_m'] = 998  ##其余期限改为998

paymentdata_phases_counts_1=pd.read_csv('./paymentdata_phases_counts_20190418v1.csv',encoding='utf-8') #坏客户标签
mdata_4= pd.merge(mdata_3, paymentdata_phases_counts_1, on='contractno', how='left')
del paymentdata_phases_counts_1,mdata_3
mdata_4=mdata_4.sort_values(['app_applycode', 'last_update_date']).drop_duplicates('app_applycode', keep='last')
mdata_4=mdata_4.drop('applycode',axis=1)

newloan_label=pd.read_excel('./2019年3月7日之前的新增贷款客户申请编号.xlsx',converters={'applycode':str}) # 选择新增客户
mdata_4=pd.merge(mdata_4,newloan_label,left_on='app_applycode',right_on='applycode',how='inner')
del  newloan_label
mdata_4['fin_phases']=mdata_4[['fin_totalphases','realtotalphases']].max(axis=1)
mdata_4['TotalPhases_m'] = mdata_4['fin_phases'].copy() ##实际贷款期限，与申请期限略有差别
mdata_4.loc[mdata_4.TotalPhases_m.isin([1, 3, 6,12, 24, 36]) == False, 'TotalPhases_m'] = 998  ##其余期限改为998
mdata_4=mdata_4.drop('applycode',axis=1)

carinfo_final_data = pd.read_table('llm_carinfo_final_data_20190422.txt', delimiter='\u0001', dtype={'applycode': str}) #读取决策引擎入参数据，从tbd中提取
carinfo_final_data=carinfo_final_data.replace('\\N',np.nan)
carinfo_final_data=carinfo_final_data.loc[carinfo_final_data.applycode.notnull(),zy_cols+['applycode']]
mdata_5=pd.merge(mdata_4,carinfo_final_data,left_on='app_applycode',right_on='applycode',how='inner')
del carinfo_final_data,mdata_4
mdata_5 = mdata_5.sort_values(['app_applycode', 'last_update_date']).drop_duplicates('app_applycode', keep='last')
mdata_5 = mdata_5.drop('applycode',axis=1)


llm_xiangye_data=pd.read_table('llm_yixin_info_20190425.txt', delimiter='\u0001', dtype={'applycode': str}) #读取决策引擎入参数据，从tbd中提取
llm_xiangye_data=llm_xiangye_data.replace('\\N',np.nan)
llm_xiangye_data=llm_xiangye_data[llm_xiangye_data.applycode.notnull()]
llm_xiangye_data=llm_xiangye_data.drop('contractno',axis=1)
mdata_6=pd.merge(mdata_5,llm_xiangye_data,left_on='app_applycode',right_on='applycode',how='inner')
del llm_xiangye_data,mdata_5
mdata_6 = mdata_6.drop('applycode',axis=1)


xiangye_jxl_report=pd.read_table('llm_jxl_report_20190506.txt', delimiter='\u0001', dtype={'apply_no': str}) #读取决策引擎入参数据，从tbd中提
xiangye_jxl_report=xiangye_jxl_report.sort_values(['apply_no','query_time']).drop_duplicates('apply_no',keep='last')
xiangye_jxl_report=xiangye_jxl_report.replace('\\N',np.nan)
lxy_cols=['call_time_rank2',
'contact_each_other_rate',
 'contact_credit_card_call_len',
 'contact_loan_contact_afternoon',
 'contact_shops_call_in_len',
 'contact_operator_call_out_len',
 'max_call_in_time_l6m',
 'max_sms_cnt_l6m',
 'max_total_amount_l6m',
 'phone_gray_score',
 'coll_contact_avg_sms_cnt',
 'operator_max_interact_cnt_l6m',
 'other_avg_interact_cnt_l6m',
 'cell_reg_time']
xiangye_jxl_report=xiangye_jxl_report.loc[xiangye_jxl_report.apply_no.notnull(),lxy_cols+['apply_no']]
mdata_7=pd.merge(mdata_6,xiangye_jxl_report,left_on='app_applycode',right_on='apply_no',how='left')
del xiangye_jxl_report,mdata_6
mdata_7 = mdata_7.sort_values(['app_applycode', 'last_update_date']).drop_duplicates('app_applycode', keep='last')

applycode_loantype=pd.read_table('applycode_loantype_20190521.txt', delimiter='\u0001', dtype={'applycode': str}) #去掉垫资再贷
mdata_7=pd.merge(mdata_7,applycode_loantype,left_on='app_applycode',right_on='applycode',how='left')
del applycode_loantype
mdata_7 = mdata_7.sort_values(['app_applycode', 'last_update_date']).drop_duplicates('app_applycode', keep='last')

de_dict_var = pd.read_excel('DE_Var_Select_20190507.xlsx')  # 处理默认值为np.nan
for i, _ in de_dict_var.iterrows():
    name = de_dict_var.loc[i, 'var_name']
    default = de_dict_var.loc[i, 'default']
    if default != '""' and name in set(mdata_7.columns) and name!='app_applycode':
        try:
            mdata_7[name] = mdata_7[name].astype('float64')
            if (mdata_7[name] == float(default)).sum() > 0:
                mdata_7.loc[mdata_7[name] == float(default), name] = np.nan
        except:
            pass

    elif default == '""' and name in set(mdata_7.columns) and name!='app_applycode':
        try:
            mdata_7[name] = mdata_7[name].astype('float64')
            if (mdata_7[name] == float(-99)).sum() > 0:
                mdata_7.loc[mdata_7[name] == float(-99), name] = np.nan
            if (mdata_7[name] == '-99').sum() > 0:
                mdata_7.loc[mdata_7[name] == '-99', name] = np.nan
        except:
            pass
        
        
for col in choose_columns: 
    try:
        mdata_7[col]=mdata_7[col].astype('float64')
        if mdata_7.loc[mdata_7[col] < 0, col].shape[0] > 0:
            print(col + ':', mdata_7.loc[mdata_7[col] < 0, col].unique(),
                  mdata_7.loc[mdata_7[col] < 0, col].shape[0]/mdata_7.shape[0])
            mdata_7.loc[final_data[col] < 0, col] = np.nan
    except: 
        pass


for col in ['vehicle_minput_obtaindate','vehicle_minput_firstregistdate','cell_reg_time','vehicle_minput_lastreleasedate']:  # 去除异常的时间
    try:
        mdata_7.loc[mdata_7[col] >= '2030-01-01', col] = np.nan
    except:
        pass


def date_cal(x, app_applydate):  # 计算申请日期距离其他日期的天数
    days_dt = pd.to_datetime(app_applydate) - pd.to_datetime(x)
    return days_dt.dt.days


for col in ['vehicle_minput_obtaindate','vehicle_minput_firstregistdate','cell_reg_time','vehicle_minput_lastreleasedate']:
    if col != 'app_applydate':
        try:
            if col != 'vehicle_minput_drivinglicensevaliditydate':
                mdata_7[col] = date_cal(mdata_7[col], mdata_7['app_applydate'])
                mdata_7.loc[mdata_7[col] < 0, col] = np.nan
            else:
                mdata_7[col] = date_cal(mdata_7['app_applydate'], mdata_7[col])  # 计算行驶证有效期限距离申请日期的天数
        except:
            pass

## 变量衍生
mdata_7.loc[mdata_7.apt_education.isin(['本科或以上']), 'apt_education'] = 1
mdata_7.loc[mdata_7.apt_education.isin(['本科']), 'apt_education'] = 2
mdata_7.loc[mdata_7.apt_education.isin(['大专']), 'apt_education'] = 3  # 处理变量apt_facetrial_marry
mdata_7.loc[mdata_7.apt_education.isin(['高中及高中以下']), 'apt_education'] = 4
mdata_7.apt_education = mdata_7.apt_education.astype('float64')     
        
mdata_7['apt_education_4'] = mdata_7.loc[:, 'apt_education'].isin([4]).astype('float64')
mdata_7['apt_facetrial_housetype_1n2'] = mdata_7.loc[:, 'apt_facetrial_housetype'].isin([1,2]).astype('float64')
mdata_7['vehicle_minput_lastmortgagerinfo_null'] = ((mdata_7.loc[:, 'vehicle_minput_lastmortgagerinfo'].isin([3])) | (mdata_7.loc[:, 'vehicle_minput_lastmortgagerinfo'].isnull())).astype('float64')
mdata_7['vehicle_minput_registcertflag_1'] = mdata_7.loc[:, 'vehicle_minput_registcertflag'].isin([1]).astype('float64')
mdata_7['apply_segment']=1
mdata_7.loc[mdata_7.app_applydate.str.slice(11,13).astype('int')<12,'apply_segment']=0  ##申请日期衍生，前半段为1，后半段为0
mdata_7['age_and_gender']=1
mdata_7.loc[(mdata_7.apt_age>=39) & (mdata_7.apt_gender.isin(['男'])),'age_and_gender']=0  ##年龄与性别组合
mdata_7.loc[(mdata_7.apt_gender.isin(['女'])),'age_and_gender']=0
consume_province=pd.read_excel('统计局数据_省级.xlsx',sheetname='各省平均工资（元）')
mdata_7=pd.merge(mdata_7,consume_province[['地区','2017年']],left_on='app_siteprovince',right_on='地区',how='left')
mdata_7=mdata_7.rename(columns={'2017年':'province_consume'})


## 统计变量的均值等
xx_data_s=mdata_7[columns+['app_applydate']].copy()
xx_data_s['applymonth']=xx_data_s['app_applydate'].str.slice(0,7)
vars_mean_count=xx_data_s.groupby(xx_data_s['applymonth'])[xx_data_s.columns.tolist()].mean().T.reset_index().rename(columns={'index':'var_name'})
vars_mean_count=pd.merge(vars_mean_count,choose_columns_table[['var_name','var_desc']],on='var_name',how='left')
vars_mean_count.set_index('var_name').loc[columns,:].reset_index().to_excel('所有入模变量的申请数据均值分布_20190514v1.xlsx',index=False)

## 统计缺失率
de_dict_var=de_dict_var.loc[de_dict_var.var_name.map(lambda x: x in xx_data_s.columns.tolist()),:]
de_dict_var['null_percents'] = de_dict_var.var_name.map(lambda x: xx_data_s[x].isnull().sum() / xx_data_s.shape[0])  ##变量的总体缺失率
de_dict_var['different_values'] = de_dict_var.var_name.map(lambda x: len(xx_data_s[x].unique()))  # 计算变量取值个数，包括缺失值
de_dict_var['whether_null'] = (de_dict_var['null_percents'] > 0).astype('int64')  # 变量是否缺失
de_dict_var['different_values'] = de_dict_var['different_values'] - de_dict_var['whether_null']  # 计算除了缺失值后的变量取值个数

applymonth = xx_data_s.app_applydate.str.slice(0, 7)  # 取申请时间的月份
whether_null_matrix = xx_data_s.isnull().astype('float64').groupby(applymonth)[xx_data_s.columns.tolist()].mean()  # 按月统计变量的缺失率
whether_null_matrix = whether_null_matrix.T
whether_null_matrix['mean_null_percents'] = whether_null_matrix.mean(axis=1)  # 按月平均缺失率
whether_null_matrix['null_percents_std/mean'] = whether_null_matrix.std(axis=1) / whether_null_matrix.mean(axis=1)  # 按月缺失率标准差与均值的比值
whether_null_matrix = whether_null_matrix.reset_index().rename(columns={'index': 'var_name'})

de_dict_vars = pd.merge(de_dict_var, whether_null_matrix, on='var_name', how='inner')  # 变量评估，后台根据变量的质量指标进行手动清洗变量
de_dict_vars.to_excel('所有入选变量的申请数据缺失率情况_20190514v1.xlsx',index=False)
del de_dict_var,applymonth,whether_null_matrix,de_dict_vars


## 新老接口默认值设置
xx_data_s=mdata_7[columns+['app_applydate']].copy()
xx_data_s['applymonth']=xx_data_s['app_applydate'].str.slice(0,7)
xx_data_s.loc[(xx_data_s.app_applydate>='2018-12-10') & (xx_data_s['jxl_id_comb_othertel_num']==0),'jxl_id_comb_othertel_num']=np.nan

model_data_s = xx_data_s[columns].copy()
model_data_s[model_data_s.isnull()] = -998
p = clf.predict_proba(model_data_s)[:, 1]

## 获取所有申请押证样本的新增二期分数
mdata_7['new_scores2']=p*100
model_data_s[['app_applydate','app_applycode','contractno','new_scores2','last_update_date','app_callpoint','hkfs','dkfs','loantype']]=\
mdata_7[['app_applydate','app_applycode','contractno','new_scores2','last_update_date','app_callpoint','hkfs','dkfs','loantype_y']].copy()

## 计算建模期全部申请样本客户各分数段占比
temp_1=model_data_s[(model_data_s.app_applydate >= '2017-08-01 00:00:00') & (model_data_s.app_applydate <=  '2018-12-10 23:59:59')].copy()
temp_1=temp_1.loc[(temp_1.dkfs.isin(['押证'])) & (temp_1.hkfs.isin(['2','4']))]
temp_1=temp_1[temp_1.loantype.isin([4,'4'])==False]
temp_1=pd.merge(temp_1,final_data[['app_applycode','y','loan_time']],on='app_applycode',how='left')
temp_1.loc[temp_1.y.isnull(),'y']=0
#占比
temp_1['grp'] = pd.cut(temp_1['new_scores2'], cuts, right=False)
score_dist  = temp_1.groupby('grp').grp.count()
rev = sorted(list(np.arange(score_dist.shape[0])), reverse=True)
print(score_dist[rev])
score_dist = score_dist[rev]/score_dist[rev].sum()
print(score_dist)
#区分能力
r_p_chart2(temp_1.y, temp_1.new_scores2.values / 100, min_scores, part=20)
del temp_1

##按月份统计-时间外申请样本客户各分数段占比
temp_2=model_data_s.copy()
temp_2=temp_2.loc[(temp_2.dkfs.isin(['押证'])) & (temp_2.hkfs.isin(['2','4']))]
temp_2=temp_2[temp_2.loantype.isin([4,'4'])==False]
apply_time_data_2 = temp_2[(temp_2.app_applydate >= '2018-08-01 00:00:00') & (temp_2.app_applydate <=  '2018-12-10 23:59:59')].copy()
apply_time_data_2=apply_time_data_2[((apply_time_data_2.app_applydate >= '2018-10-08 00:00:00') & (apply_time_data_2.app_applydate <=  '2018-10-09 23:59:59'))==False].copy()
apply_time_data_2=apply_time_data_2[apply_time_data_2.app_callpoint.isin(['APP0'])==False]
apply_time_data_2['applymonth']=apply_time_data_2['app_applydate'].str.slice(0,7)
apply_time_data_2['grp']=pd.cut(apply_time_data_2['new_scores2'],cuts,right=False)
applynum_bymonth=pd.crosstab(apply_time_data_2['grp'],apply_time_data_2['applymonth'],margins=True)
applynum_bymonth.reset_index().to_csv('时间外样本各分数段客户数_20190523v1.csv',index=False)
applynum_bymonth=applynum_bymonth.div(applynum_bymonth.ix['All',:],axis=1).reset_index()
applynum_bymonth.to_csv('时间外样本各分数段占比_20190523v1.csv',index=False)
del temp_2,model_data_s

## 为客户打标签

mdata_7['overdue_flag'] = (mdata_7.maxoverduedays >= 16)
mdata_7['bad'] = (mdata_7.overdue_flag == True)  # 占比约为4.6%
mdata_7['chargeoff_flag'] = (mdata_7.maxoverduedays==0) & (mdata_7.returnstatus.isin(['已结清']))  # 结清里面大概有75%没有逾期
mdata_7['r6_good_flag'] = (mdata_7.returnphases >= 6) & (mdata_7.maxoverduedays==0)
mdata_7['good'] = mdata_7.chargeoff_flag | mdata_7.r6_good_flag
mdata_7['y1'] = np.nan
mdata_7.loc[mdata_7.loandate.notnull(),'y1']=2
mdata_7.loc[(mdata_7.bad == True) & (mdata_7.good == False), 'y1'] = 1
mdata_7.loc[(mdata_7.bad == False) & (mdata_7.good == True), 'y1'] = 0

#占比
temp_3=mdata_7[(mdata_7.app_applydate >= '2018-08-01 00:00:00') & (mdata_7.app_applydate <=  '2018-10-31 23:59:59')].copy()
temp_3=temp_3.loc[(temp_3.dkfs.isin(['押证'])) & (temp_3.hkfs.isin(['2','4']))]
temp_3=temp_3[temp_3.y1.isin([0,1])]
temp_3['grp'] = pd.cut(temp_3['new_scores2'], cuts, right=False)
score_dist  = temp_3.groupby('grp').grp.count()
rev = sorted(list(np.arange(score_dist.shape[0])), reverse=True)
print(score_dist[rev])
score_dist = score_dist[rev]/score_dist[rev].sum()
print(score_dist)
#区分能力
r_p_chart2(temp_3.y1, temp_3.new_scores2.values / 100, min_scores, part=20)
del temp_3





'''
为到表现期(固定6个表现期）的押证放款样本打客户标签，主要用于本模型的时间外验证 
'''

## 计算历史最大逾期天数
paymentdata0 = pd.read_table('payment_20190226.txt', sep='\u0001') #导入还款表)
paymentdata = paymentdata0[paymentdata0.loandate >= '2017-05-16 00:00:00'].copy()
paymentdata=paymentdata[(paymentdata.payphases<=6)].copy()
del paymentdata0

shouldpaydate=paymentdata.groupby(['contractno']).shouldpaydate.agg(['min','max']).reset_index().reset_index().rename(columns={'min':'shouldpaydate_0','max':'shouldpaydate_6'})
shouldpaydate['performence_day']=pd.to_datetime(shouldpaydate['shouldpaydate_6'])+datetime.timedelta(days=16)
paymentdata=pd.merge(paymentdata,shouldpaydate[['contractno','performence_day']],on='contractno',how='inner')

late_index=(pd.to_datetime(paymentdata.paydate) >= paymentdata['performence_day']) & (pd.to_datetime(paymentdata.shouldpaydate) < paymentdata['performence_day'])
paymentdata.loc[late_index, 'paydate']=paymentdata.loc[late_index, 'performence_day']  ## 将表现窗口设为截止到2018-03-31
paymentdata.loc[pd.to_datetime(paymentdata.shouldpaydate) >= paymentdata['performence_day'], 'paydate'] = paymentdata.loc[pd.to_datetime(paymentdata.shouldpaydate) >= paymentdata['performence_day'], 'shouldpaydate']

paymentdata=paymentdata[pd.to_datetime(paymentdata.paydate)>=pd.to_datetime('1970-12-03 00:00:00')].copy() #异常值处理
paymentdata['overdue_days'] = (pd.to_datetime(paymentdata.paydate) - pd.to_datetime(paymentdata.shouldpaydate)).dt.days
paymentdata.loc[(paymentdata[['shouldcapital', 'shouldgpsf', 'shouldint', 'shouldmanage']] == 0).all(axis=1), 'overdue_days'] = 0  ##计算历史最大逾期天数
paymentdata.loc[paymentdata['overdue_days'] < 0, 'overdue_days'] = 0
paymentdata_maxdue = paymentdata.groupby(['contractno']).overdue_days.max().reset_index().rename(columns={'overdue_days': 'maxoverduedays'})
del paymentdata

paymentdata_maxdue['overdue_flag'] = (paymentdata_maxdue.maxoverduedays >= 16)
paymentdata_maxdue['bad'] = (paymentdata_maxdue.overdue_flag == True)  # 占比约为4.6%
paymentdata_maxdue['chargeoff_flag'] = (paymentdata_maxdue.maxoverduedays == 0)
paymentdata_maxdue['good'] = paymentdata_maxdue.chargeoff_flag
paymentdata_maxdue['y'] = np.nan
paymentdata_maxdue.loc[(paymentdata_maxdue.bad == True) & (paymentdata_maxdue.good == False), 'y'] = 1
paymentdata_maxdue.loc[(paymentdata_maxdue.bad == False) & (paymentdata_maxdue.good == True), 'y'] = 0

outof_test1= pd.merge(temp_1[['app_applycode','app_applydate','contractno','newcar_model2_notcutof_score','last_update_date','hkfs','loan_time']], paymentdata_maxdue, on='contractno', how='inner')
outof_test1=outof_test1.sort_values(['app_applycode', 'last_update_date']).drop_duplicates('app_applycode', keep='last')


##计算某一个时间段的新增押证放款样本的模型区分能力

start_date = '2018-04-16 00:00:00'
end_date = '2018-06-20 23:59:59'
fin_time_data = outof_test[(outof_test.app_applydate >= start_date) & (outof_test.app_applydate <= end_date)]
fin_time_data=fin_time_data[fin_time_data.y.notnull()]
fpr, tpr, th = roc_curve(fin_time_data['y'], fin_time_data.new_scores2.values/100)
ks4 = tpr - fpr
print('all ks:   ' + str(max(ks4)))
print(roc_auc_score(fin_time_data['y'], fin_time_data.new_scores2.values/100))
r_p_chart2(fin_time_data['y'], fin_time_data.new_scores2.values/100, min_scores, part=20)


## 按月统计模型ks值,份12期先息后本以及非12期先息后本
start_date = '2017-05-16 00:00:00'
end_date = '2018-06-20 23:59:59'
fin_time_data = outof_test[(outof_test.app_applydate >= start_date) & (outof_test.app_applydate <= end_date)]
fin_time_data['whether_12']=((fin_time_data.loan_time==12) & (fin_time_data.hkfs.isin(['1']))).astype('float64')
testdata=fin_time_data[fin_time_data['whether_12']==0].copy()
testdata['applymonth']=testdata['app_applydate'].str.slice(0,7)
testdata=testdata[testdata['y'].isin([0,1])]
num_counts=pd.crosstab(testdata['applymonth'],testdata['y'],margins=True).reset_index()
ks_list={}
gini_list={}
for cn in testdata['applymonth'].unique():
    temp=testdata.ix[testdata['applymonth']==cn,['y','new_scores2']].copy()
    fpr, tpr, th = roc_curve(temp['y'], temp['new_scores2'].values/100)
    ks2 = tpr - fpr
    ks_list[cn]=max(ks2)
    try:
        gini_cn=2*roc_auc_score(temp['y'], temp['new_scores2'].values/100)-1
    except:
        gini_cn=np.nan
    gini_list[cn]=gini_cn

ks_pd=pd.Series(ks_list)
ks_pd=ks_pd.reset_index()

gini_pd=pd.Series(gini_list)
gini_pd=gini_pd.reset_index()

fpr, tpr, th = roc_curve(testdata['y'], testdata['new_scores2'].values / 100)
ks2 = tpr - fpr
print(max(ks2))
print(roc_auc_score(testdata['y'], testdata['new_scores2'].values/100))
r_p_chart2(testdata['y'], testdata['new_scores2'].values/100, min_scores, part=20)



'''
统计表现期时间截止日期（2019年2月11日）的模型表现
'''
paymentdata = pd.read_table('payment_20190212.txt', delimiter='\u0001')
paymentdata= paymentdata.replace('\\N', np.nan)

paymentdata=paymentdata.ix[paymentdata.shouldpaydate < '2019-02-12 00:00:00',['contractno','paydate','shouldpaydate','shouldcapital', 'shouldgpsf', 'shouldint', 'shouldmanage','update_time','totalphases','payphases','phases']]
paymentdata.loc[(paymentdata.paydate >= '2019-02-12 00:00:00'), 'paydate'] = '2019-02-11 23:59:59'  ## 将表现窗口设为截止到2019-01-06

paymentdata=paymentdata[paymentdata.paydate>='1970-12-03 00:00:00'].copy() #异常值处理
paymentdata['overdue_days'] = (pd.to_datetime(paymentdata.paydate) - pd.to_datetime(paymentdata.shouldpaydate)).dt.days
paymentdata.loc[(paymentdata[['shouldcapital', 'shouldgpsf', 'shouldint', 'shouldmanage']] == 0).all(axis=1), 'overdue_days'] = 0  ##计算历史最大逾期天数
paymentdata.loc[paymentdata['overdue_days'] < 0, 'overdue_days'] = 0
paymentdata_maxdue = paymentdata.groupby(['contractno']).overdue_days.max().reset_index().rename(columns={'overdue_days': 'maxoverduedays'})

paymentdata[['totalphases', 'payphases', 'phases']] = paymentdata[['totalphases', 'payphases', 'phases']].astype('int64')  # 将一些字段转成整型数据

paymentdata_totalphases = paymentdata.groupby(['contractno']).totalphases.max().reset_index()  # 计算贷款总期限,不包括展期
paymentdata_realtotalphases = paymentdata[paymentdata.update_time< '2019-02-12 00:00:00'].groupby(['contractno']).payphases.max().reset_index().rename(columns={'payphases': 'max_payphases'})  # 包括是否展期
paymentdata_totalphases = pd.merge(paymentdata_totalphases, paymentdata_realtotalphases, on='contractno', how='inner')
paymentdata_totalphases['realtotalphases'] = paymentdata_totalphases[['totalphases', 'max_payphases']].max(axis=1)  # 在实际贷款期限与是否展期合并获得总贷款期限

paymentdata_returnphases = paymentdata.groupby(['contractno']).payphases.max().reset_index().rename(columns={'payphases': 'returnphases'})  # 计算已还期数
paymentdata_phases_counts = pd.merge(paymentdata_returnphases, paymentdata_totalphases, on='contractno',how='inner')  # 合并贷款期限与已还期数
paymentdata_phases_counts = pd.merge(paymentdata_phases_counts, paymentdata_maxdue, on='contractno',how='inner')  # 合并最大逾期与贷款期限
del paymentdata,paymentdata_totalphases,paymentdata_returnphases,paymentdata_maxdue

findata0 = pd.read_table('fnsche_over20190211.txt',encoding='gbk',dtype={'contractno': str})#导入进度逾期表
findata = findata0.ix[ findata0['loandate'].notnull(), ['loandate', 'contractno', 'currentduedays', 'returnstatus']].copy()
findata['loandate'] = findata['loandate'].map(lambda x: datetime.datetime.strptime(str(x), "%d%b%Y")).copy()  # pd.to_datetime(findata0['loandate']).astype('str')
findata = findata[(findata['loandate'] >= '2017-05-16 00:00:00')].copy()  # .rename(columns={'ContractNo': 'contractno'})
findata = findata.sort_values(['contractno', 'loandate']).drop_duplicates('contractno', keep='last')
findata = pd.merge(findata, paymentdata_phases_counts, on='contractno', how='left')
fin_data = pd.merge(temp_1[['app_applycode','app_applydate','contractno','new_scores2','last_update_date','hkfs','loan_time']], findata, on='contractno', how='inner')
del findata0

fin_data['overdue_flag'] = (fin_data.maxoverduedays >= 16)
fin_data['bad'] = (fin_data.overdue_flag == True)  # 占比约为4.6%
fin_data['chargeoff_flag'] = (fin_data.maxoverduedays == 0) & (fin_data.returnstatus.isin(['已结清']))  # 结清里面大概有75%没有逾期
fin_data['r6_good_flag'] = (fin_data.returnphases >= 8) & (fin_data.maxoverduedays == 0)
fin_data['good'] = fin_data.chargeoff_flag | fin_data.r6_good_flag
fin_data['y'] = 2
fin_data.loc[(fin_data.bad == True) & (fin_data.good == False), 'y'] = 1
fin_data.loc[(fin_data.bad == False) & (fin_data.good == True), 'y'] = 0

## 按月统计模型ks值,份12期先息后本以及非12期先息后本
start_date = '2018-04-16 00:00:00'
end_date = '2018-07-20 23:59:59'
fin_time_data = fin_data[(fin_data.app_applydate >= start_date) & (fin_data.app_applydate <= end_date)]
testdata=fin_time_data[(fin_time_data.loan_time==12) & (fin_time_data.hkfs.isin(['1']))]
testdata['applymonth']=testdata['app_applydate'].str.slice(0,7)
testdata=testdata[testdata['y'].isin([0,1])]
num_counts=pd.crosstab(testdata['applymonth'],testdata['y'],margins=True).reset_index()
ks_list={}
for cn in testdata['applymonth'].unique():
    temp=testdata.ix[testdata['applymonth']==cn,['y','new_scores2']].copy()
    fpr, tpr, th = roc_curve(temp['y'], temp['new_scores2'].values/100)
    ks2 = tpr - fpr
    ks_list[cn]=max(ks2)

ks_pd=pd.Series(ks_list)
ks_pd=ks_pd.reset_index()

print(roc_auc_score(testdata['y'], testdata['new_scores2'].values/100))
r_p_chart2(testdata['y'], testdata['new_scores2'].values/100, min_scores, part=20)










