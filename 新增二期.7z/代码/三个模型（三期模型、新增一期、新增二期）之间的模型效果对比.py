import numpy as np
import pandas as pd
import os
from sklearn.metrics import roc_auc_score,roc_curve

## 加载文件位置
os.chdir('D:/llm/车贷新增模型二期/数据')

## 定义一些函数用于模型评估，计算KS
def r_p(y_test, answer_p, idx, low=0, high=150):
    a = answer_p
    b = y_test

    idx = idx[low:high]
    recall = (b.iloc[idx] == 1).sum() / (b == 1).sum()
    precision = (b.iloc[idx] == 1).sum() / (high - low)
    return (recall, precision)

def r_p_chart(y_test, answer_p, part=20):
    print('分段  平均分 最小分 最大分 客户数 逾期数 逾期数/客户数 KS值 GAIN_INDEX 累计召回率')
    a = answer_p
    b = y_test

    idx = sorted(range(len(a)), key=lambda k: a[k], reverse=True)

    total_label_RATE = (y_test == 1).sum() / len(y_test)

    ths = []
    cum = 0
    if len(np.unique(a)) < part:
        for unq_a in np.unique(a)[::-1]:
            ths.append(cum)
            cum = cum + (a == unq_a).sum()
        ths.append(cum)

    else:
        for i in np.arange(0, len(a), (len(a) / part)):
            ths.append(int(round(i)))
        ths.append(len(a))

    min_scores = []
    for idx_ths, _ in enumerate(ths):
        if idx_ths == 0:
            continue
        # idx_ths = 1
        low = ths[idx_ths - 1]
        high = ths[idx_ths]

        r, p = r_p(y_test, answer_p, idx, low, high)
        cum_r, cum_p = r_p(y_test, answer_p, idx, 0, high)

        max_score = answer_p[idx[low]]
        min_score = answer_p[idx[high - 1]]
        min_scores.append(min_score)
        mean_score = (max_score + min_score) / 2
        len_ = high - low
        idx_tmp = idx[low:high]
        bad_num = (b.iloc[idx_tmp] == 1).sum()
        INTERVAL_label_RATE = bad_num / len_
        idx_tmp = idx[0:high]

        tpr = (b.iloc[idx_tmp] == 1).sum() / (b == 1).sum()
        fpr = (b.iloc[idx_tmp] == 0).sum() / (b == 0).sum()
        ks = tpr - fpr
        gain_index = INTERVAL_label_RATE / total_label_RATE

        print('%d %10.3f %10.3f %10.3f %7d %7d %10.2f %10.2f %10.2f %10.2f'
              % (idx_ths, mean_score * 100, min_score * 100, max_score * 100, len_, bad_num, INTERVAL_label_RATE * 100,
                 ks * 100, gain_index, cum_r * 100))

    return min_scores


def r_p_chart2(y_test, answer_p, min_scores, part=20):
    print('分段  平均分 最小分 最大分 客户数 逾期数 逾期数/客户数 KS值 GAIN_INDEX 累计召回率')
    a = answer_p
    b = y_test

    idx = sorted(range(len(a)), key=lambda k: a[k], reverse=True)

    ths = []
    ths.append(0)
    min_scores_idx = 0
    for num, i in enumerate(idx):
        # print(a[i])
        if a[i] < min_scores[min_scores_idx]:
            ths.append(num)
            min_scores_idx = min_scores_idx + 1
    ths.append(len(idx))

    total_label_RATE = (y_test == 1).sum() / len(y_test)

    min_scores = []
    for idx_ths, _ in enumerate(ths):
        if idx_ths == 0:
            continue
        low = ths[idx_ths - 1]
        high = ths[idx_ths]

        r, p = r_p(y_test, answer_p, idx, low, high)
        cum_r, cum_p = r_p(y_test, answer_p, idx, 0, high)

        max_score = answer_p[idx[low]]
        min_score = answer_p[idx[high - 1]]

        min_scores.append(min_score)
        mean_score = (max_score + min_score) / 2
        len_ = high - low
        idx_tmp = idx[low:high]
        bad_num = (b.iloc[idx_tmp] == 1).sum()
        INTERVAL_label_RATE = bad_num / len_
        idx_tmp = idx[0:high]
        tpr = (b.iloc[idx_tmp] == 1).sum() / (b == 1).sum()
        fpr = (b.iloc[idx_tmp] == 0).sum() / (b == 0).sum()
        ks = tpr - fpr
        gain_index = INTERVAL_label_RATE / total_label_RATE

        print('%d %10.3f %10.3f %10.3f %7d %7d %10.2f %10.2f %10.2f %10.2f'
              % (idx_ths, mean_score * 100, min_score * 100, max_score * 100, len_, bad_num, INTERVAL_label_RATE * 100,
                 ks * 100, gain_index, cum_r * 100))
        
        
##计算好坏标签 
paymentdata = pd.read_table('payment_20190524.txt', delimiter='\u0001')
paymentdata= paymentdata.replace('\\N', np.nan)

paymentdata=paymentdata.ix[paymentdata.shouldpaydate < '2019-05-24 00:00:00',:]
paymentdata.loc[(paymentdata.paydate >= '2019-05-24 00:00:00'), 'paydate'] = '2019-05-23 23:59:59'  ## 将表现窗口设为截止到2019-01-06

paymentdata=paymentdata[paymentdata.paydate>='1970-12-03 00:00:00'].copy() #异常值处理
paymentdata['overdue_days'] = (pd.to_datetime(paymentdata.paydate) - pd.to_datetime(paymentdata.shouldpaydate)).dt.days
paymentdata.loc[(paymentdata[['shouldcapital', 'shouldgpsf', 'shouldint', 'shouldmanage']] == 0).all(axis=1), 'overdue_days'] = 0  ##计算历史最大逾期天数
paymentdata.loc[paymentdata['overdue_days'] < 0, 'overdue_days'] = 0
paymentdata_maxdue = paymentdata.groupby(['contractno']).overdue_days.max().reset_index().rename(columns={'overdue_days': 'maxoverduedays'})

paymentdata[['totalphases', 'payphases', 'phases']] = paymentdata[['totalphases', 'payphases', 'phases']].astype('int64')  # 将一些字段转成整型数据

paymentdata_totalphases = paymentdata.groupby(['contractno']).totalphases.max().reset_index()  # 计算贷款总期限,不包括展期
paymentdata_realtotalphases = paymentdata[paymentdata.update_time< '2019-05-24 00:00:00'].groupby(['contractno']).payphases.max().reset_index().rename(columns={'payphases': 'max_payphases'})  # 包括是否展期
paymentdata_totalphases = pd.merge(paymentdata_totalphases, paymentdata_realtotalphases, on='contractno', how='inner')
paymentdata_totalphases['realtotalphases'] = paymentdata_totalphases[['totalphases', 'max_payphases']].max(axis=1)  # 在实际贷款期限与是否展期合并获得总贷款期限

paymentdata_returnphases = paymentdata.groupby(['contractno']).payphases.max().reset_index().rename(columns={'payphases': 'returnphases'})  # 计算已还期数
paymentdata_phases_counts = pd.merge(paymentdata_returnphases, paymentdata_totalphases, on='contractno',how='inner')  # 合并贷款期限与已还期数
paymentdata_phases_counts = pd.merge(paymentdata_phases_counts, paymentdata_maxdue, on='contractno',how='inner')  # 合并最大逾期与贷款期限
del paymentdata_totalphases,paymentdata_returnphases,paymentdata_maxdue       
        
return_status=paymentdata[['contractno','returnstatus']].drop_duplicates()      
paymentdata_phases_counts1=pd.merge(paymentdata_phases_counts,return_status,on='contractno',how='left')      
        
paymentdata_phases_counts1['overdue_flag'] = (paymentdata_phases_counts1.maxoverduedays >= 16)
paymentdata_phases_counts1['bad'] = (paymentdata_phases_counts1.overdue_flag == True)  # 占比约为4.6%
paymentdata_phases_counts1['chargeoff_flag'] = (paymentdata_phases_counts1.maxoverduedays==0) & (paymentdata_phases_counts1.returnstatus.isin(['已结清']))  # 结清里面大概有75%没有逾期
paymentdata_phases_counts1['r6_good_flag'] = (paymentdata_phases_counts1.returnphases >= 6) & (paymentdata_phases_counts1.maxoverduedays==0)
paymentdata_phases_counts1['good'] = paymentdata_phases_counts1.chargeoff_flag | paymentdata_phases_counts1.r6_good_flag
paymentdata_phases_counts1['y'] = np.nan
paymentdata_phases_counts1.loc[(paymentdata_phases_counts1.bad == True) & (paymentdata_phases_counts1.good == False), 'y'] = 1
paymentdata_phases_counts1.loc[(paymentdata_phases_counts1.bad == False) & (paymentdata_phases_counts1.good == True), 'y'] = 0



## 加载新增二期分数+标签
newcar_model2_score=pd.read_excel('新增二期分数_20190523.xlsx',converters={'app_applycode':str})
newcar_model2_score=pd.merge(newcar_model2_score,mdata_7[['app_applycode','is_newcustomer']],on='app_applycode',how='inner')
newcar_model2_score=newcar_model2_score[newcar_model2_score.is_newcustomer.isin(['yes'])]
newcar_model2_score=newcar_model2_score[(newcar_model2_score.app_applydate>='2018-08-01 00:00:00') & (newcar_model2_score.app_applydate<='2018-10-31 23:59:59')]
newcar_model2_score=pd.merge(newcar_model2_score,paymentdata_phases_counts1[['contractno','y']],on='contractno',how='inner')
newcar_model2_score=newcar_model2_score[(newcar_model2_score.hkfs.isin([4])) & (newcar_model2_score.dkfs.isin(['押证']))]
newcar_model2_score=newcar_model2_score[newcar_model2_score.loan_time.isin([12,24,36])]
newcar_model2_score=newcar_model2_score[newcar_model2_score.loantype_y.isin([4,'4'])==False]


## 加载新增一期分数+标签
newcar_model1_score=pd.read_excel('新增一期分数_20190523.xlsx',converters={'app_applycode':str})
newcar_model1_score=pd.merge(newcar_model1_score,mdata_7[['app_applycode','loantime']],on='app_applycode',how='inner')
newcar_model1_score=newcar_model1_score[newcar_model1_score.newloan==1]
newcar_model1_score=newcar_model1_score[(newcar_model1_score.app_applydate>='2018-08-01 00:00:00') & (newcar_model1_score.app_applydate<='2018-10-31 23:59:59')]
newcar_model1_score=pd.merge(newcar_model1_score,paymentdata_phases_counts1[['contractno','y']],on='contractno',how='inner')
newcar_model1_score=newcar_model1_score[(newcar_model1_score.hkfs.isin([4])) & (newcar_model1_score.dkfs.isin(['押证']))]
newcar_model1_score=newcar_model1_score[newcar_model1_score.loantime.astype('float64').isin([12,24,36])]
newcar_model1_score=newcar_model1_score[newcar_model1_score.loantype.isin([4,'4'])==False]


## 加载三期分数
model3_score=pd.read_excel('三期分数_20190524.xlsx',converters={'app_applycode':str})
model3_score1=pd.read_excel('三期分数.xlsx',converters={'app_applycode':str})



## 新增一期与剔除12期先息后本的新增二期模型对比分析

#新增二期时间外验证：二期分数+二期标签
newcar_model2_score_itself=newcar_model2_score[(newcar_model2_score['y'].notnull())]
print(newcar_model2_score_itself.columns)
fpr, tpr, th = roc_curve(newcar_model2_score_itself.y, (newcar_model2_score_itself.new_scores2/100).values)
ks4 = tpr - fpr
print('all ks:   ' + str(max(ks4)))
print(roc_auc_score(newcar_model2_score_itself.y, (newcar_model2_score_itself.new_scores2/100).values))
model2_cutof_min_scores=[0.58823,
0.52359,
0.47377,
0.43406,
0.40531,
0.38063,
0.35939,
0.33811,
0.31814,
0.30093,
0.28449,
0.27024,
0.25793,
0.24624,
0.23555,
0.22256,
0.20971,
0.19212,
0.16732,
0]


r_p_chart2(newcar_model2_score_itself.y, (newcar_model2_score_itself.new_scores2/100).values, model2_cutof_min_scores, part=20)
# newcar_model2_score_itself['applymonth']=newcar_model2_score_itself['app_applydate'].str.slice(0,7)
# testdata=newcar_model2_score_itself[newcar_model2_score_itself['y'].isin([0,1])]
# num_counts=pd.crosstab(testdata['applymonth'],testdata['y'],margins=True).reset_index()
# ks_list={}
# gini_list={}
# for cn in testdata['applymonth'].unique():
#     temp=testdata.ix[testdata['applymonth']==cn,['y','new_scores2']].copy()
#     fpr, tpr, th = roc_curve(temp['y'], temp['new_scores2'].values/100)
#     ks2 = tpr - fpr
#     ks_list[cn]=max(ks2)
#     try:
#         gini_cn=2*roc_auc_score(temp['y'], temp['new_scores2'].values/100)-1
#     except:
#         gini_cn=np.nan
#     gini_list[cn]=gini_cn
#
# ks_pd=pd.Series(ks_list)
# ks_pd=ks_pd.reset_index()
#
# gini_pd=pd.Series(gini_list)
# gini_pd=gini_pd.reset_index()



#新增一期时间外验证：一期分数+一期标签
newcar_model2_score_itself=newcar_model1_score[(newcar_model1_score['y'].notnull())]
newcar_model2_score_vs_model1_label=newcar_model2_score_itself.copy()
print(newcar_model2_score_vs_model1_label.columns)
fpr, tpr, th = roc_curve(newcar_model2_score_vs_model1_label.y, (newcar_model2_score_vs_model1_label.new_scores1/100).values)
ks4 = tpr - fpr
print('all ks:   ' + str(max(ks4)))
print(roc_auc_score(newcar_model2_score_vs_model1_label.y, (newcar_model2_score_vs_model1_label.new_scores1/100).values))
model2_score_vs_model1_label_min_scores=[0.28743000000000002,	
0.24163999999999999,	
0.21647,	
0.19731000000000001,	
0.17763000000000001,	
0.14918000000000001,	
0.13544,	
0.12948000000000001,	
0.12670000000000001,	
0.12393,	
0.12013,	
0.11593000000000001,	
0.11335000000000001,	
0.10947,	
0.105,	
0.10263,	
0.098339999999999997,	
0.093679999999999999,	
0.08974,	
0]	

r_p_chart2(newcar_model2_score_vs_model1_label.y, (newcar_model2_score_vs_model1_label.new_scores1/100).values,model2_score_vs_model1_label_min_scores, part=20)



#新增二期时间外验证：二期分数+一期新增定义
newcar_model2_score=pd.read_excel('新增二期分数_20190523.xlsx',converters={'app_applycode':str})
newcar_model1_score_itself=newcar_model1_score[(newcar_model1_score['y'].notnull())]
newcar_model1_score_vs_model2_label=pd.merge(newcar_model1_score_itself[['app_applycode','y']],newcar_model2_score[['app_applycode','app_applydate','new_scores2']],on='app_applycode',how='inner')
print(newcar_model1_score_vs_model2_label.columns)
fpr, tpr, th = roc_curve(newcar_model1_score_vs_model2_label.y, (newcar_model1_score_vs_model2_label.new_scores2/100).values)
ks4 = tpr - fpr
print('all ks:   ' + str(max(ks4)))
print(roc_auc_score(newcar_model1_score_vs_model2_label.y, (newcar_model1_score_vs_model2_label.new_scores2/100).values))

r_p_chart2(newcar_model1_score_vs_model2_label.y, (newcar_model1_score_vs_model2_label.new_scores2/100).values,model2_cutof_min_scores, part=20)



#新增二期时间外验证：一期分数+二期新增定义
newcar_model1_score=pd.read_excel('新增一期分数_20190523.xlsx',converters={'app_applycode':str})
newcar_model2_score_itself=newcar_model2_score[(newcar_model2_score['y'].notnull())]
newcar_model1_score_vs_model2_label=pd.merge(newcar_model2_score_itself[['app_applycode','y']],newcar_model1_score[['app_applycode','app_applydate','new_scores1']],on='app_applycode',how='inner')
print(newcar_model1_score_vs_model2_label.columns)
fpr, tpr, th = roc_curve(newcar_model1_score_vs_model2_label.y, (newcar_model1_score_vs_model2_label.new_scores1/100).values)
ks4 = tpr - fpr
print('all ks:   ' + str(max(ks4)))
print(roc_auc_score(newcar_model1_score_vs_model2_label.y, (newcar_model1_score_vs_model2_label.new_scores1/100).values))

r_p_chart2(newcar_model1_score_vs_model2_label.y, (newcar_model1_score_vs_model2_label.new_scores1/100).values,model2_score_vs_model1_label_min_scores, part=20)



## 三期分数+二期新增定义

#新增二期时间外验证：三期分数+二期新增定义
newcar_model2_score_itself=newcar_model2_score[(newcar_model2_score['y'].notnull())]
newcar_model1_score_vs_model2_label=pd.merge(newcar_model2_score_itself[['app_applycode','y']],model3_score[['app_applycode','scores3']],on='app_applycode',how='inner')
print(newcar_model2_score_itself.columns)
fpr, tpr, th = roc_curve(newcar_model1_score_vs_model2_label.y, (newcar_model1_score_vs_model2_label.scores3/100).values)
ks4 = tpr - fpr
print('all ks:   ' + str(max(ks4)))
print(roc_auc_score(newcar_model1_score_vs_model2_label.y, (newcar_model1_score_vs_model2_label.scores3/100).values))
model3_notcutof_min_scores=[0.25719999999999998,
0.20455000000000001,
0.17644000000000001,
0.15728,
0.1424,
0.13058,
0.12107,
0.11312999999999999,
0.10629,
0.10051,
0.095630000000000007,
0.091170000000000001,
0.087359999999999993,
0.083839999999999998,
0.080360000000000001,
0.076920000000000002,
0.073539999999999994,
0.069940000000000002,
0.065949999999999995,
0]



r_p_chart2(newcar_model1_score_vs_model2_label.y, (newcar_model1_score_vs_model2_label.scores3/100).values, model3_notcutof_min_scores, part=20)










