import os
import pandas as pd
import numpy as np
from scipy import stats
from sklearn.metrics import roc_curve, roc_auc_score
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.model_selection import train_test_split
import pickle
import csv
import warnings
import matplotlib.pyplot as plt
from matplotlib import rcParams
import datetime

warnings.filterwarnings("ignore")
rcParams['font.sans-serif'] = ['Microsoft YaHei']

## 修改路径到数据存储的文件夹
os.chdir('E:/liaoliming/重要文档/车贷数据/新增二期模型开发_20190411/数据')


paymentdata = pd.read_table('payment_20190416.txt', delimiter='\u0001')
paymentdata= paymentdata.replace('\\N', np.nan)
paymentdata=paymentdata.loc[paymentdata.shouldpaydate < '2019-04-16 00:00:00',['contractno','paydate','shouldpaydate','shouldcapital', 'shouldgpsf', 'shouldint', 'shouldmanage','update_time','totalphases','payphases','phases']]

def comput_perform_maxoverduedays(paymentdata,perform_date):
      data_1=paymentdata[['contractno','paydate','shouldpaydate','shouldcapital', 'shouldgpsf', 'shouldint', 'shouldmanage']]
      data_1.loc[(data_1.paydate >= perform_date), 'paydate'] = perform_date  ## 将表现窗口设为截止到2019-01-06
      data_1=data_1[data_1.paydate>='1970-12-03 00:00:00'].copy() #异常值处理
      data_1['overdue_days'] = (pd.to_datetime(data_1.paydate) - pd.to_datetime(data_1.shouldpaydate)).dt.days
      data_1.loc[(data_1[['shouldcapital', 'shouldgpsf', 'shouldint', 'shouldmanage']] == 0).all(axis=1), 'overdue_days'] = 0  ##计算历史最大逾期天数
      data_1.loc[data_1['overdue_days'] < 0, 'overdue_days'] = 0
      paymentdata_maxdue= data_1.groupby(['contractno']).overdue_days.max().reset_index().rename(columns={'overdue_days': 'maxoverduedays'+'_'+str(perform_date[0:11])})
      return  paymentdata_maxdue

perform_date=['2017-10-16 00:00:00','2017-11-16 00:00:00','2017-12-16 00:00:00','2018-01-16 00:00:00','2018-02-16 00:00:00','2018-03-16 00:00:00',
              '2018-04-16 00:00:00','2018-05-16 00:00:00','2018-06-16 00:00:00','2018-07-16 00:00:00','2018-08-16 00:00:00','2018-09-16 00:00:00','2018-10-16 00:00:00',
              '2018-11-16 00:00:00','2018-12-16 00:00:00','2019-01-16 00:00:00','2019-02-16 00:00:00','2019-03-16 00:00:00','2019-04-16 00:00:00']

paymentdata_maxdue=comput_perform_maxoverduedays(paymentdata,'2017-09-16 00:00:00')
for date in perform_date:
    paymentdata_maxdue1=comput_perform_maxoverduedays(paymentdata,date)
    paymentdata_maxdue=pd.merge(paymentdata_maxdue,paymentdata_maxdue1,on='contractno',how='inner')