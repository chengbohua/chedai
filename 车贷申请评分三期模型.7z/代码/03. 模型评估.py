
## 剔除相关性较高变量 

'''
# 最终模型
'''

columns=['jxl_id_comb_othertel_num',
 'jxl_tel_loan_call_sumnum',
 'vehicle_illegal_num',
 'jxl_tel_length',
 'jxl_eachphone_num',
 'jxl_call_num_aver_6months',
 'jxl_nocturnal_ratio',
 'jxl_black_dir_cont_num',
 'yx_underly_record_num',
 'yx_otherorgan_times',
 'apt_currentaddrresideyears',
 'vehicle_evtrpt_mileage',
 'apt_ec_historyloantimes',
 'apt_ec_overduedaystotallastyear',
 'apt_age',
 'vehicle_evtrpt_2bprice_gap',
 'vehicle_evtrpt_evalprice_trend',
 'apt_ec_lastloansettleddate',
 'vehicle_minput_lastreleasedate',
 'vehicle_minput_drivinglicensevaliditydate',
 'vehicle_minput_obtaindate',
 'apt_facetrial_creditcardfalg_2',
 'apt_gender_0',
 'apt_telecom_phoneattribution_2n3',
 'vehicle_minput_lastmortgagerinfo_1n2',
 'apt_facetrial_housetype_1']

print(len(columns))
clf = GradientBoostingClassifier(learning_rate=0.05,
                                     min_samples_leaf=24,
                                     max_depth=7,
                                     max_leaf_nodes=25,
                                     n_estimators=46,
                                     random_state=0)
clf.fit(x_train[columns], y_train)
a = clf.feature_importances_.tolist()
pred_p = clf.predict_proba(ori_x_train[columns])[:,1]
fpr, tpr, th = roc_curve(ori_y_train, pred_p)
ks = tpr - fpr
pred_p2 = clf.predict_proba(x_test[columns])[:,1]
fpr, tpr, th = roc_curve(y_test, pred_p2)
ks2 = tpr - fpr

feature_importance = pd.DataFrame({'var_name':columns, 'importance':a}).sort_values('importance', ascending=False)
feature_importance = pd.merge(feature_importance, de_dict_var[['var_name', 'var_desc']], on='var_name', how='left')[['var_name', 'var_desc', 'importance']]
print(feature_importance)
print('train ks: ' + str(max(ks)))
print('test ks:  ' + str(max(ks2)))

# pickle.dump(clf, open('../部署/gbdt3_v3_20180810.pkl', 'wb'))
# feature_importance.to_excel('./feature_importance_v2.xlsx')

'''
## 模型表现 
'''

pred_p = clf.predict_proba(ori_x_train[columns])[:,1]
min_scores = r_p_chart(ori_y_train, pred_p, part=20)
min_scores = [round(i, 5) for i in min_scores]
min_scores[19] = 0
cuts = [round(min_scores[i]*100.0, 3) for i in range(20)[::-1]] + [100.0]

print('训练集')
pred_p = clf.predict_proba(ori_x_train[columns])[:,1]
fpr, tpr, th = roc_curve(ori_y_train, pred_p)
ks = tpr - fpr
print('train ks: ' + str(max(ks)))
print(roc_auc_score(ori_y_train,pred_p))
r_p_chart2(ori_y_train, pred_p, min_scores, part=20)

print('验证集')
pred_p2 = clf.predict_proba(x_test[columns])[:,1]
fpr, tpr, th = roc_curve(y_test, pred_p2)
ks2 = tpr - fpr
print('test ks:  ' + str(max(ks2)))
print(roc_auc_score(y_test,pred_p2))
r_p_chart2(y_test, pred_p2, min_scores, part=20)

print('全部数据')
pred_p3 = clf.predict_proba(x[columns])[:,1]
fpr, tpr, th = roc_curve(y, pred_p3)
ks3 = tpr - fpr
print('all ks:   ' + str(max(ks3)))
print(roc_auc_score(y,pred_p3))
r_p_chart2(y, pred_p3, min_scores, part=20)

'''
## 对全量申请样本进行评分，可选择申请月份
'''
vars_count_table=pd.read_excel('de_dict_vars.xlsx',sheetname='变量质量情况')
choose_columns_table=vars_count_table[vars_count_table.whether_choose==1]
numeric_cols=choose_columns_table.ix[choose_columns_table.var_type=='\ufeff数据型','var_name'].values.tolist()
str_cols=choose_columns_table.ix[choose_columns_table.var_type=='\ufeff字符型','var_name'].values.tolist()
date_cols=choose_columns_table.ix[choose_columns_table.var_type=='\ufeff日期型','var_name'].values.tolist()


mdata0 = pd.read_table('data_20180613.txt', delimiter='\u0001', dtype={'app_applycode': str}) #读取决策引擎入参数据，从tbd中提取
mdata0=mdata0.replace('\\N',np.nan)
mdata0=mdata0[mdata0.app_applycode.notnull()]
mdata0 = mdata0[(mdata0.app_applydate>='2017-09-16 00:00:00')]
mdata0=mdata0.sort_values(['app_applycode', 'last_update_date']).drop_duplicates('app_applycode', keep='last')
mdata0['applymonth']=mdata0.app_applydate.str.slice(0,7)
mdata1=mdata0[mdata0.loan_mode.isin([1,'1','押证'])].copy()
# mdata1=pd.merge(mdata1,my_data[['app_applycode','y']].drop_duplicates(),on='app_applycode',how='left')

xx_data = mdata1[choose_columns_table['var_name'].values.tolist()].copy()
de_dict_var=pd.read_excel('DE_Var_Select_0.xlsx') #处理默认值为np.nan
for i, _ in de_dict_var.iterrows():
    name = de_dict_var.loc[i, 'var_name']
    default = de_dict_var.loc[i, 'default']
    if default != '""' and name in set(xx_data.columns) :
        try:
            xx_data[name] = xx_data[name].astype('float64')
            if (xx_data[name] == float(default)).sum() > 0:
               xx_data.loc[xx_data[name] == float(default), name] = np.nan
        except:
            pass

    elif default == '""' and name in set(xx_data.columns) :
        try:
            xx_data[name] = xx_data[name].astype('float64')
            if (xx_data[name] == float(-99)).sum() > 0:
                xx_data.loc[xx_data[name] == float(-99), name] = np.nan
            if (xx_data[name] == '-99').sum() > 0:
                xx_data.loc[xx_data[name] == '-99', name] = np.nan
        except:
            pass

for col in numeric_cols:  #列出数据型变量异常值并对异常值进行处理 ，只有jxl_call_num_aver_6months异常值（负值）
    if xx_data.ix[xx_data[col]<0,col].shape[0]>0:
       xx_data.ix[xx_data[col] < 0, col]=np.nan

for col in date_cols:  #去除异常的时间
       try:
          xx_data.ix[xx_data[col]>='2030-01-01',col]=np.nan
       except:
           pass

def date_cal(x, app_applydate): #计算申请日期距离其他日期的天数
    days_dt = pd.to_datetime(app_applydate) - pd.to_datetime(x)
    return days_dt.dt.days

for col in date_cols:
    if col!='app_applydate':
        try:
            if col!='vehicle_minput_drivinglicensevaliditydate':
                 xx_data[col] = date_cal(xx_data[col], xx_data['app_applydate'])
                 xx_data.loc[xx_data[col] == -1, col] = 0
                 xx_data.loc[xx_data[col] < -1, col] = np.nan
            else:
                xx_data[col] = date_cal( xx_data['app_applydate'],xx_data[col])  #计算行驶证有效期限距离申请日期的天数
        except:
            pass

for col in str_cols:  #列出字符变量的不同取值
    print(col+':',xx_data[col].unique())

xx_data.ix[xx_data.cont01_knowloan.isin(['Y']),'cont01_knowloan']=1
xx_data.ix[xx_data.cont01_knowloan.isin(['N']),'cont01_knowloan']=2  #处理变量cont01_knowloan
xx_data.cont01_knowloan=xx_data.cont01_knowloan.astype('float64')
xx_data.ix[xx_data.cont03_knowloan.isin(['Y']),'cont03_knowloan']=1
xx_data.ix[xx_data.cont03_knowloan.isin(['N']),'cont03_knowloan']=2  #处理变量cont03_knowloan
xx_data.cont03_knowloan=xx_data.cont03_knowloan.astype('float64')
xx_data.ix[xx_data.cont02_knowloan.isin(['Y']),'cont02_knowloan']=1
xx_data.ix[xx_data.cont02_knowloan.isin(['N']),'cont02_knowloan']=2  #处理变量cont02_knowloan
xx_data.cont02_knowloan=xx_data.cont02_knowloan.astype('float64')
xx_data.ix[xx_data.apt_education.isin(['本科以上']),'apt_education']=1
xx_data.ix[xx_data.apt_education.isin(['本科']),'apt_education']=2
xx_data.ix[xx_data.apt_education.isin(['大专']),'apt_education']=3  #处理变量apt_education
xx_data.ix[xx_data.apt_education.isin(['高中及高中以下']),'apt_education']=4
xx_data.apt_education=xx_data.apt_education.astype('float64')

xx_data['apt_facetrial_creditcardfalg_2'] = xx_data.loc[:,'apt_facetrial_creditcardfalg'].isin([2]).astype('float64')
xx_data['apt_telecom_phoneattribution_2n3'] =  xx_data.loc[:,'apt_telecom_phoneattribution'].isin([2,3]).astype('float64')
xx_data['apt_gender_0'] = xx_data.loc[:,'apt_gender'].isin(['女']).astype('float64')
xx_data['vehicle_minput_lastmortgagerinfo_1n2'] = xx_data.loc[:,'vehicle_minput_lastmortgagerinfo'].isin([1,2]).astype('float64')
xx_data['vehicle_evtrpt_2bprice_gap'] = abs(xx_data['vehicle_evtrpt_b2bprice'] - xx_data['vehicle_evtrpt_c2bprice'])/xx_data['vehicle_evtrpt_b2bprice']
xx_data['vehicle_evtrpt_evalprice_trend'] = xx_data['vehicle_evtrpt_evalprice3']/xx_data['vehicle_evtrpt_evalprice2']
xx_data['apt_facetrial_housetype_1']=xx_data.loc[:,'apt_facetrial_housetype'].isin([1]).astype('float64')


x = xx_data[columns].copy()
x[x.isnull()] = -998
p = clf.predict_proba(x)[:,1]
x['grp'] = pd.cut(p * 100.0, cuts, right=False)


r_p_chart2(mdata1['y'], p, min_scores, part=20)


score_dist  = x.groupby('grp').grp.count()
rev = sorted(list(np.arange(score_dist.shape[0])), reverse=True)
print(score_dist[rev])
score_dist = score_dist[rev]/score_dist[rev].sum()
print(score_dist)


## 生成新的20个分数区间
p = pd.Series(p) 
newcuts = [0.0] + round(p.quantile(np.linspace(0,1,21,endpoint=True)) * 100, 3).values.tolist()[1:20] + [100.0]
newgrp = pd.cut(p*100, newcuts, right=False)
score_dist  = newgrp.groupby(newgrp).count()         
rev = sorted(list(np.arange(score_dist.shape[0])), reverse=True) 
score_dist = score_dist[rev] 
print(score_dist)

 
