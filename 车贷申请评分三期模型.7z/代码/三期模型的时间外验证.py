import os
import pandas as pd
import numpy as np
from scipy import stats
from sklearn.metrics import roc_curve,roc_auc_score
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.model_selection import train_test_split
import pickle
import csv
import warnings
import matplotlib.pyplot as plt
from matplotlib import rcParams
from sklearn.externals import joblib

warnings.filterwarnings("ignore")
rcParams['font.sans-serif'] = ['Microsoft YaHei']

## 修改路径到数据存储的文件夹
os.chdir('E:/liaoliming/重要文档/车贷数据/车贷反欺诈三期（廖利明）_优化/fraud_v3/data')

## 加载模型
clf = joblib.load('gbdt3_v4.pkl')


def r_p(y_test, answer_p, idx, low=0, high=150):
    a = answer_p
    b = y_test

    idx = idx[low:high]
    recall = (b.iloc[idx] == 1).sum() / (b == 1).sum()
    precision = (b.iloc[idx] == 1).sum() / (high - low)
    return (recall, precision)


def r_p_chart(y_test, answer_p, part=20):
    print('分段  平均分 最小分 最大分 客户数 逾期数 逾期数/客户数 KS值 GAIN_INDEX 累计召回率')
    a = answer_p
    b = y_test

    idx = sorted(range(len(a)), key=lambda k: a[k], reverse=True)

    total_label_RATE = (y_test == 1).sum() / len(y_test)

    ths = []
    cum = 0
    if len(np.unique(a)) < part:
        for unq_a in np.unique(a)[::-1]:
            ths.append(cum)
            cum = cum + (a == unq_a).sum()
        ths.append(cum)

    else:
        for i in np.arange(0, len(a), (len(a) / part)):
            ths.append(int(round(i)))
        ths.append(len(a))

    min_scores = []
    for idx_ths, _ in enumerate(ths):
        if idx_ths == 0:
            continue
        # idx_ths = 1
        low = ths[idx_ths - 1]
        high = ths[idx_ths]

        r, p = r_p(y_test, answer_p, idx, low, high)
        cum_r, cum_p = r_p(y_test, answer_p, idx, 0, high)

        max_score = answer_p[idx[low]]
        min_score = answer_p[idx[high - 1]]
        min_scores.append(min_score)
        mean_score = (max_score + min_score) / 2
        len_ = high - low
        idx_tmp = idx[low:high]
        bad_num = (b.iloc[idx_tmp] == 1).sum()
        INTERVAL_label_RATE = bad_num / len_
        idx_tmp = idx[0:high]

        tpr = (b.iloc[idx_tmp] == 1).sum() / (b == 1).sum()
        fpr = (b.iloc[idx_tmp] == 0).sum() / (b == 0).sum()
        ks = tpr - fpr
        gain_index = INTERVAL_label_RATE / total_label_RATE

        print('%d %10.3f %10.3f %10.3f %7d %7d %10.2f %10.2f %10.2f %10.2f'
              % (idx_ths, mean_score * 100, min_score * 100, max_score * 100, len_, bad_num, INTERVAL_label_RATE * 100,
                 ks * 100, gain_index, cum_r * 100))

    return min_scores


def r_p_chart2(y_test, answer_p, min_scores, part=20):
    print('分段  平均分 最小分 最大分 客户数 逾期数 逾期数/客户数 KS值 GAIN_INDEX 累计召回率')
    a = answer_p
    b = y_test

    idx = sorted(range(len(a)), key=lambda k: a[k], reverse=True)

    ths = []
    ths.append(0)
    min_scores_idx = 0
    for num, i in enumerate(idx):
        # print(a[i])
        if a[i] < min_scores[min_scores_idx]:
            ths.append(num)
            min_scores_idx = min_scores_idx + 1
    ths.append(len(idx))

    total_label_RATE = (y_test == 1).sum() / len(y_test)

    min_scores = []
    for idx_ths, _ in enumerate(ths):
        if idx_ths == 0:
            continue
        low = ths[idx_ths - 1]
        high = ths[idx_ths]

        r, p = r_p(y_test, answer_p, idx, low, high)
        cum_r, cum_p = r_p(y_test, answer_p, idx, 0, high)

        max_score = answer_p[idx[low]]
        min_score = answer_p[idx[high - 1]]

        min_scores.append(min_score)
        mean_score = (max_score + min_score) / 2
        len_ = high - low
        idx_tmp = idx[low:high]
        bad_num = (b.iloc[idx_tmp] == 1).sum()
        INTERVAL_label_RATE = bad_num / len_
        idx_tmp = idx[0:high]
        tpr = (b.iloc[idx_tmp] == 1).sum() / (b == 1).sum()
        fpr = (b.iloc[idx_tmp] == 0).sum() / (b == 0).sum()
        ks = tpr - fpr
        gain_index = INTERVAL_label_RATE / total_label_RATE

        print('%d %10.3f %10.3f %10.3f %7d %7d %10.2f %10.2f %10.2f %10.2f'
              % (idx_ths, mean_score * 100, min_score * 100, max_score * 100, len_, bad_num, INTERVAL_label_RATE * 100,
                 ks * 100, gain_index, cum_r * 100))


'''
## 导入决策引擎数据，合同信息
'''

mdata0 = pd.read_table('data_20180613.txt', delimiter='\u0001', dtype={'app_applycode': str})  # 读取决策引擎入参数据，从tbd中提取
mdata0 = mdata0.replace('\\N', np.nan)
mdata0 = mdata0[mdata0.app_applycode.notnull()]

apply_contract_report = pd.read_table('applyid_applycode_htbh_20180613.txt', delimiter='\u0001',dtype={'applycode': str})  # 申请表关联合同表
apply_contract_report = apply_contract_report.replace('\\N', np.nan)
apply_contract_report = apply_contract_report.ix[(apply_contract_report.applycode.isnull() == False) & (apply_contract_report.contractno.isnull() == False), :].drop_duplicates()  #去重

'''
## 申请窗口的数据(去重，删除申请号为空记录
'''

start_date = '2017-05-16 00:00:00'
end_date = '2017-09-15 23:59:59'
mdata1 = mdata0[(mdata0.app_applydate >= start_date) & (mdata0.app_applydate <= end_date)]
mdata1 = mdata1.sort_values(['app_applycode', 'last_update_date']).drop_duplicates('app_applycode', keep='last')
mdata1 = pd.merge(mdata1, apply_contract_report, left_on='app_applycode', right_on='applycode', how='left')
mdata1['applymonth'] = mdata1.app_applydate.str.slice(0, 7)  # 生成申请月份
mdata1['loan_time_m'] = mdata1['loan_time']
mdata1.loc[mdata1.loan_time.isin([1, 3, 6, 12, 24, 36]) == False, 'loan_time_m'] = 998  # 将其余的期限赋值为998期


'''
## 导入财务数据，合并
'''
## 用TBD上的底层还款表计算曾经最大逾期天数（表现期截止到2018-03-31）
paymentdata0 = pd.read_table('tb_lf_returndetail_20180612.txt', delimiter='\u0001', quoting=csv.QUOTE_NONE,encoding='utf-8')
paymentdata0 = paymentdata0.replace('\\N', np.nan)
paymentdata0 = paymentdata0[paymentdata0.returnid.notnull()]
paymentdata0.returnid = paymentdata0.returnid.astype('int64')

returndata0 = pd.read_table('tb_lf_return_20180612.txt', delimiter='\u0001', quoting=csv.QUOTE_NONE, encoding='utf-8')
returndata0 = returndata0.replace('\\N', np.nan)
returndata0 = returndata0[returndata0.contractno.notnull()]

paymentdata = pd.merge(paymentdata0, returndata0, left_on='returnid', right_on='id', how='inner')
del paymentdata0, returndata0

paymentdata.loc[(paymentdata.paydate >= '2018-06-11 00:00:00') & (paymentdata.shouldpaydate < '2018-06-11 00:00:00'), 'paydate'] = '2018-06-10 23:59:59'  ## 将表现窗口设为截止到2018-03-31
paymentdata.loc[paymentdata.shouldpaydate >= '2018-06-11 00:00:00', 'paydate'] = paymentdata.loc[paymentdata.shouldpaydate >= '2018-06-11 00:00:00', 'shouldpaydate']

paymentdata['overdue_days'] = (pd.to_datetime(paymentdata.paydate) - pd.to_datetime(paymentdata.shouldpaydate)).dt.days
paymentdata.loc[(paymentdata[['shouldcapital', 'shouldgpsf', 'shouldint', 'shouldmanage']] == 0).all(axis=1), 'overdue_days'] = 0  ##计算历史最大逾期天数
paymentdata.loc[paymentdata['overdue_days'] < 0, 'overdue_days'] = 0
paymentdata_maxdue = paymentdata.groupby(['contractno']).overdue_days.max().reset_index().rename(columns={'overdue_days': 'maxoverduedays'})

paymentdata[['totalphases', 'payphases', 'phases', 'status', 'delaystatus']] = paymentdata[['totalphases', 'payphases', 'phases', 'status', 'delaystatus']].astype('int64')  # 将一些字段转成整型数据

paymentdata_totalphases = paymentdata.groupby(['contractno']).totalphases.max().reset_index()  # 计算贷款总期限,不包括展期
paymentdata_realtotalphases = paymentdata[paymentdata.update_time_x < '2018-06-11 23:59:59'].groupby(['contractno']).payphases.max().reset_index().rename(columns={'payphases': 'max_payphases'})  # 包括是否展期
paymentdata_totalphases = pd.merge(paymentdata_totalphases, paymentdata_realtotalphases, on='contractno', how='inner')
paymentdata_totalphases['realtotalphases'] = paymentdata_totalphases[['totalphases', 'max_payphases']].max(axis=1)  # 在实际贷款期限与是否展期合并获得总贷款期限

paymentdata_returnphases = paymentdata.ix[(paymentdata.shouldpaydate < '2018-06-11 00:00:00'), :].groupby(['contractno']).payphases.max().reset_index().rename(columns={'payphases': 'returnphases'})  # 计算已还期数
paymentdata_phases_counts = pd.merge(paymentdata_returnphases, paymentdata_totalphases, on='contractno',how='inner')  # 合并贷款期限与已还期数
paymentdata_phases_counts = pd.merge(paymentdata_phases_counts, paymentdata_maxdue, on='contractno',how='inner')  # 合并最大逾期与贷款期限
del paymentdata

fin_mdata1 = pd.merge(mdata1, paymentdata_phases_counts, on='contractno', how='inner')
print(fin_mdata1.shape[0])  # 78076

'''
## 提取放款的押证客户
'''

## 押证放款
print(fin_mdata1.loan_mode.unique())
fin_mdata = fin_mdata1[(fin_mdata1.loan_mode.isin([1, '1', '押证']))]

'''
----------------------------
## 定义好坏客户

## 坏客户定义：
#      1)  曾经逾期16+
## 好客户的定义： 
#      1） 已结清且未发生逾期，   
#      2） 已还至少6期且未发生过逾期，

----------------------------
'''

my_data = fin_mdata.copy()
my_data['overdue_flag'] = (my_data.maxoverduedays >= 16)
my_data['bad'] = (my_data.overdue_flag == True)  # 占比约为4.6%
my_data['chargeoff_flag'] = (my_data.maxoverduedays == 0) & (my_data.returnstatus.isin([1]))  # 结清里面大概有75%没有逾期
my_data['r6_good_flag'] = (my_data.returnphases >= 6) & (my_data.maxoverduedays == 0)
my_data['tl6_good_flag'] = (my_data.realtotalphases < 6) & (my_data.maxoverduedays == 0)
my_data['good'] = my_data.chargeoff_flag | my_data.r6_good_flag | my_data.tl6_good_flag
my_data['y'] = np.nan
my_data.loc[(my_data.bad == True) & (my_data.good == False), 'y'] = 1
my_data.loc[(my_data.bad == False) & (my_data.good == True), 'y'] = 0

print(sum(my_data.bad))
# 3825
print(sum(my_data.good))
# 35490

##针对最大逾期期数介于0和15天的，剔除13805
print(sum((my_data.maxoverduedays > 0) & (my_data.maxoverduedays < 16) & (my_data.y.isnull())))
## 针对还款不到6个月，剔除灰样本0
print(sum((my_data.maxoverduedays == 0) & (my_data.returnphases < 6) & (my_data.y.isnull())))

'''
## 2. 对初步筛选出的变量进行变量衍生、哑变量衍生等
'''
vars_count_table = pd.read_excel('de_dict_vars.xlsx', sheetname='变量质量情况')
choose_columns_table = vars_count_table[vars_count_table.whether_choose == 1]
numeric_columns = choose_columns_table.ix[choose_columns_table.var_type == '\ufeff数据型', 'var_name'].values.tolist()
str_columns = choose_columns_table.ix[choose_columns_table.var_type == '\ufeff字符型', 'var_name'].values.tolist()
date_columns = choose_columns_table.ix[choose_columns_table.var_type == '\ufeff日期型', 'var_name'].values.tolist()

xxdata = my_data[choose_columns_table.var_name.tolist() + ['y']].copy()  # 选择初选变量的数据
de_dict_var = pd.read_excel('DE_Var_Select_0.xlsx')  # 处理默认值为np.nan
for i, _ in de_dict_var.iterrows():
    name = de_dict_var.loc[i, 'var_name']
    default = de_dict_var.loc[i, 'default']
    if default != '""' and name in set(xxdata.columns):
        try:
            xxdata[name] = xxdata[name].astype('float64')
            if (xxdata[name] == float(default)).sum() > 0:
                xxdata.loc[xxdata[name] == float(default), name] = np.nan
        except:
            pass

    elif default == '""' and name in set(xxdata.columns):
        try:
            xxdata[name] = xxdata[name].astype('float64')
            if (xxdata[name] == float(-99)).sum() > 0:
                xxdata.loc[xxdata[name] == float(-99), name] = np.nan
            if (xxdata[name] == '-99').sum() > 0:
                xxdata.loc[xxdata[name] == '-99', name] = np.nan
        except:
            pass

'''
## 2.1 处理数据型变量，包括异常值处理等
'''
numeric_data = xxdata[numeric_columns]
for col in numeric_columns:  # 列出数据型变量异常值并对异常值进行处理 ，只有jxl_call_num_aver_6months异常值（负值）
    if xxdata.ix[xxdata[col] < 0, col].shape[0] > 0:
        print(col + ':', xxdata.ix[xxdata[col] < 0, col].unique())
        xxdata.ix[xxdata[col] < 0, col] = np.nan

'''
## 2.2 处理日期型变量，将日期变量转为距离申请日期的天数
'''
for col in date_columns:  # 去除异常的时间
    try:
        xxdata.ix[xxdata[col] >= '2030-01-01', col] = np.nan
    except:
        pass


def date_cal(x, app_applydate):  # 计算申请日期距离其他日期的天数
    days_dt = pd.to_datetime(app_applydate) - pd.to_datetime(x)
    return days_dt.dt.days


for col in date_columns:
    if col != 'app_applydate':
        try:
            if col != 'vehicle_minput_drivinglicensevaliditydate':
                xxdata[col] = date_cal(xxdata[col], xxdata['app_applydate'])
                xxdata.loc[xxdata[col] == -1, col] = 0
                xxdata.loc[xxdata[col] < -1, col] = np.nan
            else:
                xxdata[col] = date_cal(xxdata['app_applydate'], xxdata[col])  # 计算行驶证有效期限距离申请日期的天数
        except:
            pass

'''
## 2.3 处理字符型变量，将一些不统计的取值统一
'''

for col in str_columns:  # 列出字符变量的不同取值
    print(col + ':', xxdata[col].unique())

abnorm_str_columns = ['cont01_knowloan', 'cont03_knowloan', 'cont02_knowloan', 'apt_education', 'apt_facetrial_marry']

xxdata.ix[xxdata.cont01_knowloan.isin(['Y']), 'cont01_knowloan'] = 1
xxdata.ix[xxdata.cont01_knowloan.isin(['N']), 'cont01_knowloan'] = 2  # 处理变量cont01_knowloan
xxdata.cont01_knowloan = xxdata.cont01_knowloan.astype('float64')
xxdata.ix[xxdata.cont03_knowloan.isin(['Y']), 'cont03_knowloan'] = 1
xxdata.ix[xxdata.cont03_knowloan.isin(['N']), 'cont03_knowloan'] = 2  # 处理变量cont03_knowloan
xxdata.cont03_knowloan = xxdata.cont03_knowloan.astype('float64')
xxdata.ix[xxdata.cont02_knowloan.isin(['Y']), 'cont02_knowloan'] = 1
xxdata.ix[xxdata.cont02_knowloan.isin(['N']), 'cont02_knowloan'] = 2  # 处理变量cont02_knowloan
xxdata.cont02_knowloan = xxdata.cont02_knowloan.astype('float64')
xxdata.ix[xxdata.apt_education.isin(['本科以上']), 'apt_education'] = 1
xxdata.ix[xxdata.apt_education.isin(['本科']), 'apt_education'] = 2
xxdata.ix[xxdata.apt_education.isin(['大专']), 'apt_education'] = 3  # 处理变量apt_education
xxdata.ix[xxdata.apt_education.isin(['高中及高中以下']), 'apt_education'] = 4
xxdata.apt_education = xxdata.apt_education.astype('float64')
xxdata.ix[xxdata.apt_facetrial_marry.isin(['已婚']), 'apt_facetrial_marry'] = 2
xxdata.ix[xxdata.apt_facetrial_marry.isin(['未婚']), 'apt_facetrial_marry'] = 3
xxdata.ix[xxdata.apt_facetrial_marry.isin(['离异']), 'apt_facetrial_marry'] = 4  # 处理变量apt_facetrial_marry
xxdata.ix[xxdata.apt_facetrial_marry.isin(['丧偶']), 'apt_facetrial_marry'] = 5
xxdata.ix[xxdata.apt_facetrial_marry.isin(['其他']), 'apt_facetrial_marry'] = 6
xxdata.apt_facetrial_marry = xxdata.apt_facetrial_marry.astype('float64')

## 哑变量衍生

xxdata['apt_comp_businesslicenseflag_1'] = xxdata.loc[:, 'apt_comp_businesslicenseflag'].isin([1]).astype('float64')
xxdata['apt_comp_category_3n4'] = xxdata.loc[:, 'apt_comp_category'].isin([ 3, 4]).astype('float64')
xxdata['apt_comp_jobcategory_2'] = xxdata.loc[:, 'apt_comp_jobcategory'].isin([2]).astype('float64')
xxdata['apt_education_1n2'] = xxdata.loc[:, 'apt_education'].isin([1, 2]).astype('float64')
xxdata['apt_facetrial_accompaniedloanpersonnel_3n4'] = xxdata.loc[:, 'apt_facetrial_accompaniedloanpersonnel'].isin([3, 4]).astype('float64')
xxdata['apt_facetrial_creditcardfalg_2'] = xxdata.loc[:, 'apt_facetrial_creditcardfalg'].isin([2]).astype('float64')
xxdata['apt_facetrial_householdregister_2n3'] = xxdata.loc[:, 'apt_facetrial_householdregister'].isin([2, 3]).astype('float64')
xxdata['apt_facetrial_marry_1n2n6'] = xxdata.loc[:, 'apt_facetrial_marry'].isin([1, 2, 6]).astype('float64')
xxdata['apt_facetrial_otherhouseflag_0'] = xxdata.loc[:, 'apt_facetrial_otherhouseflag'].isin([0]).astype('float64')
xxdata['apt_facetrial_residertogether_1n3n4'] = xxdata.loc[:, 'apt_facetrial_residertogether'].isin([1, 3, 4]).astype('float64')  ##独居或和朋友同住
xxdata['apt_gender_0'] = xxdata.loc[:, 'apt_gender'].isin(['女']).astype('float64')
xxdata['apt_housingfund_flag_1'] = xxdata.loc[:, 'apt_housingfund_flag'].isin([1]).astype('float64')
xxdata['apt_socialsecurity_flag_1'] = xxdata.loc[:, 'apt_socialsecurity_flag'].isin([1]).astype('float64')
xxdata['apt_telecom_phoneattribution_2n3'] = xxdata.loc[:, 'apt_telecom_phoneattribution'].isin([2, 3]).astype('float64')
xxdata['code_jxl1_0'] = xxdata.loc[:, 'code_jxl1'].isin([0]).astype('float64')
xxdata['cont01_knowloan_1'] = xxdata.loc[:, 'cont01_knowloan'].isin([1]).astype('float64')
xxdata['cont01_relationship_5'] = xxdata.loc[:, 'cont01_relationship'].isin(['亲戚', '其他', '子女', '朋友', '配偶']).astype('float64')
xxdata['cont02_knowloan_1'] = xxdata.loc[:, 'cont02_knowloan'].isin([1]).astype('float64')
xxdata['cont02_relationship_4'] = xxdata.loc[:, 'cont02_relationship'].isin(['同事', '其他', '子女', '朋友']).astype('float64')
xxdata['cont03_knowloan_1'] = xxdata.loc[:, 'cont03_knowloan'].isin([1]).astype('float64')
xxdata['cont03_relationship_2'] = xxdata.loc[:, 'cont03_relationship'].isin(['子女', '配偶']).astype('float64')
xxdata['jxl_110_record_3'] = xxdata.loc[:, 'jxl_110_record'].isin(['偶尔通话(3次以内，包括3次)', '多次通话(3次以上)', '无数据']).astype('float64')
xxdata['jxl_120_record_3'] = xxdata.loc[:, 'jxl_120_record'].isin(['偶尔通话(3次以内，包括3次)', '多次通话(3次以上)', '无数据']).astype('float64')
xxdata['jxl_contact1_rel_2'] = xxdata.loc[:, 'jxl_contact1_rel'].isin(['父母', '兄弟姐妹']).astype('float64')
xxdata['jxl_contact2_rel_2'] = xxdata.loc[:, 'jxl_contact2_rel'].isin(['同学', '同事']).astype('float64')
xxdata['jxl_contact3_rel_3'] = xxdata.loc[:, 'jxl_contact3_rel'].isin(['子女', '父母', '配偶']).astype('float64')
xxdata['jxl_court_phone_record_2'] = xxdata.loc[:, 'jxl_court_phone_record'].isin(['无通话记录', '无数据']).astype('float64')
xxdata['jxl_id_operator_record_2'] = xxdata.loc[:, 'jxl_id_operator'].isin(['失败']).astype('float64')
xxdata['jxl_law_phone_record_3'] = xxdata.loc[:, 'jxl_law_phone_record'].isin(['偶尔通话(3次以内，包括3次)', '无数据', '无通话记录']).astype('float64')
xxdata['jxl_macau_phone_record_3'] = xxdata.loc[:, 'jxl_macau_phone_record'].isin(['偶尔通话(3次以内，包括3次)', '多次通话(3次以上)', '无数据']).astype('float64')
xxdata['jxl_name_operator_record_2'] = xxdata.loc[:, 'jxl_name_operator'].isin(['失败', '运营商未提供身份证号码']).astype('float64')
xxdata['tx_badinfor_is_exist'] = xxdata.loc[:, 'tx_badinfor_is'].isin(['EXIST']).astype('float64')
xxdata['tx_cardid_NaN'] = xxdata['tx_cardid'].isnull().astype('float64')
xxdata['tx_punish_history_no'] = xxdata.loc[:, 'tx_punish_history'].isin(['无']).astype('float64')
xxdata['vehicle_minput_attribution_1'] = xxdata.loc[:, 'vehicle_minput_attribution'].isin([1]).astype('float64')
xxdata['vehicle_minput_driverlicenseflag_1'] = xxdata.loc[:, 'vehicle_minput_driverlicenseflag'].isin([1]).astype('float64')
xxdata['vehicle_minput_lastmortgagerinfo_1n2'] = xxdata.loc[:, 'vehicle_minput_lastmortgagerinfo'].isin([1, 2]).astype( 'float64')
xxdata['vehicle_minput_registcertflag_1'] = xxdata.loc[:, 'vehicle_minput_registcertflag'].isin([1]).astype('float64')
xxdata['apt_ec_currentoverdue_0'] = xxdata.loc[:, 'apt_ec_currentoverdue'].isin([0]).astype('float64')
xxdata['apt_facetrial_housetype_1'] = xxdata.loc[:, 'apt_facetrial_housetype'].isin([1]).astype('float64')
xxdata['vehicle_minput_ownerway_1n2'] = xxdata.loc[:, 'vehicle_minput_ownerway'].isin([1, 2]).astype('float64')
xxdata['vehicle_buymode_2'] = xxdata.loc[:, 'vehicle_buymode'].isin([2]).astype('float64')
xxdata['apt_illegal_flag_1'] = xxdata.loc[:, 'apt_illegal_flag'].isin([1]).astype('float64')

xxdata = xxdata.drop(str_columns, axis=1)
xxdata = xxdata.drop('app_applydate', axis=1)

dummy_columns = ['apt_comp_businesslicenseflag_1', 'apt_comp_category_3n4',
                 'apt_comp_jobcategory_2', 'apt_education_1n2', 'apt_facetrial_accompaniedloanpersonnel_3n4',
                 'apt_facetrial_creditcardfalg_2', 'apt_facetrial_householdregister_2n3', 'apt_facetrial_marry_1n2n6',
                 'apt_facetrial_otherhouseflag_0', 'apt_facetrial_residertogether_1n3n4', 'apt_gender_0',
                 'apt_housingfund_flag_1', 'apt_socialsecurity_flag_1', 'apt_telecom_phoneattribution_2n3',  # 哑变量集合
                 'code_jxl1_0', 'cont01_knowloan_1', 'cont01_relationship_5', 'cont02_knowloan_1',
                 'cont02_relationship_4', 'cont03_knowloan_1', 'cont03_relationship_2', 'jxl_110_record_3',
                 'jxl_120_record_3', 'jxl_contact1_rel_2', 'jxl_contact2_rel_2', 'jxl_contact3_rel_3',
                 'jxl_court_phone_record_2', 'jxl_id_operator_record_2', 'jxl_law_phone_record_3',
                 'jxl_macau_phone_record_3', 'jxl_name_operator_record_2', 'tx_badinfor_is_exist',
                 'tx_cardid_NaN', 'tx_punish_history_no', 'vehicle_minput_attribution_1',
                 'vehicle_minput_driverlicenseflag_1', 'vehicle_minput_lastmortgagerinfo_1n2',
                 'vehicle_minput_registcertflag_1','apt_ec_currentoverdue_0', 'apt_facetrial_housetype_1', 'vehicle_minput_ownerway_1n2',
                 'vehicle_buymode_2', 'apt_illegal_flag_1']

'''
## 2.4 衍生变量
'''
xxdata['vehicle_evtrpt_2bprice_gap'] = abs(xxdata['vehicle_evtrpt_b2bprice'] - xxdata['vehicle_evtrpt_c2bprice']) / xxdata['vehicle_evtrpt_b2bprice']
xxdata['vehicle_evtrpt_evalprice_trend'] = xxdata['vehicle_evtrpt_evalprice3'] / xxdata['vehicle_evtrpt_evalprice2']

'''
## 选择初始变量
'''

numeric_columns = numeric_columns + ['vehicle_evtrpt_2bprice_gap', 'vehicle_evtrpt_evalprice_trend'] #数值变量
numeric_columns.remove('vehicle_evtrpt_b2bprice')
numeric_columns.remove('vehicle_evtrpt_c2bprice')
numeric_columns.remove('vehicle_evtrpt_evalprice3')
numeric_columns.remove('vehicle_evtrpt_evalprice2')
numeric_columns.remove('vehicle_evtrpt_evaluateprice')
date_columns.remove('app_applydate') #去掉申请日期后的日期变量集合


print(len(numeric_columns)) #57
print(len(date_columns)) #7
print(len(dummy_columns)) #43

'''
## 汇集好坏样本，单变量分析 (用 R作图)
'''
sample_flag = xxdata.y.notnull()
sample_data = xxdata[sample_flag]

ori_columns = numeric_columns + date_columns + dummy_columns
model_data = sample_data.loc[:, ['y']+ori_columns]
xxdata = model_data[ori_columns]
xxdata[xxdata.isnull()] = -998
model_data[xxdata.columns.tolist()] = xxdata.copy()

columns=['jxl_id_comb_othertel_num',
 'jxl_tel_loan_call_sumnum',
 'vehicle_illegal_num',
 'jxl_tel_length',
 'jxl_eachphone_num',
 'jxl_call_num_aver_6months',
 'jxl_nocturnal_ratio',
 'jxl_black_dir_cont_num',
 'yx_underly_record_num',
 'yx_otherorgan_times',
 'apt_currentaddrresideyears',
 'vehicle_evtrpt_mileage',
 'apt_ec_historyloantimes',
 'apt_ec_overduedaystotallastyear',
 'apt_age',
 'vehicle_evtrpt_2bprice_gap',
 'vehicle_evtrpt_evalprice_trend',
 'apt_ec_lastloansettleddate',
 'vehicle_minput_lastreleasedate',
 'vehicle_minput_drivinglicensevaliditydate',
 'vehicle_minput_obtaindate',
 'apt_facetrial_creditcardfalg_2',
 'apt_gender_0',
 'apt_telecom_phoneattribution_2n3',
 'vehicle_minput_lastmortgagerinfo_1n2',
 'apt_facetrial_housetype_1']

min_scores=[0.25719999999999998,
 0.20455000000000001,
 0.17644000000000001,
 0.15728,
 0.1424,
 0.13058,
 0.12107,
 0.11312999999999999,
 0.10629,
 0.10051,
 0.095630000000000007,
 0.091170000000000001,
 0.087359999999999993,
 0.083839999999999998,
 0.080360000000000001,
 0.076920000000000002,
 0.073539999999999994,
 0.069940000000000002,
 0.065949999999999995,
 0]

y = model_data['y']
x = model_data[columns]

print('时间外验证')
pred_p2 = clf.predict_proba(x)[:,1]
fpr, tpr, th = roc_curve(y, pred_p2)
ks2 = tpr - fpr
print('test ks:  ' + str(max(ks2)))
print(roc_auc_score(y,pred_p2))
r_p_chart2(y, pred_p2, min_scores, part=20)