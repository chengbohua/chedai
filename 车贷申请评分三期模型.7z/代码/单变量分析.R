

library(xlsx)
library(readr)
library(dplyr)

## Single variable analysis

data_dir = "E:/liaoliming/重要文档/车贷数据/模型交接/车贷反欺诈（陈总）/chenzhijian/fraud_v2/data"
setwd(data_dir)

sample_data <- read_csv("E:/liaoliming/重要文档/车贷数据/模型交接/车贷反欺诈（陈总）/chenzhijian/fraud_v2/data/sample_data.csv")
sample_data = as.data.frame(sample_data)


str_columns = c('apt_illegal_flag',
                'apt_telecom_phoneattribution',
                'apt_socialsecurity_flag',
                'apt_facetrial_residertogether',
                'apt_facetrial_housetype',
                'apt_facetrial_creditcardfalg',
                'apt_facetrial_otherhouseflag',
                'apt_facetrial_marry',
                'apt_comp_businesslicenseflag',
                'apt_comp_jobcategory',
                'vehicle_minput_lastmortgagerinfo',
                'vehicle_minput_driverlicenseflag',
                'vehicle_minput_registcertflag',
                'vehicle_minput_ownerway', 
                'vehicle_buymode',
                'tx_badinfor_is',
                'tx_punish_history',
                'code_td_loan',
                'td_dishonest_list_check',
                'code_yx_risk')


date_columns = c("apt_ec_lastloansettleddate",           
                "vehicle_minput_lastreleasedate",       
                "vehicle_minput_firstregistdate",       
                "vehicle_minput_obtaindate",            
                "vehicle_buydate")

numeric_columns = c('apt_childnum',
                    'apt_currentaddrresideyears',
                    'apt_telecom_callfrequency',
                    'apt_telecom_phoneuserduration',
                    'apt_telecom_interconnectedcallsnum',
                    'apt_age',
                    'apt_facetrial_contactpersonnum',
                    'apt_facetrial_localresideyears',
                    'apt_ec_overduedaystotallastyear',
                    'apt_ec_longestoverduedaystotallastyear',
                    'apt_ec_overduephasetotallastyear',
                    'apt_ec_historyloantimes',
                    'apt_comp_monthlysalary',
                    'apt_comp_experienceyears',
                    'apt_localresidemonths',
                    'vehicle_illegal_yearchargeamount',
                    'vehicle_illegal_penaltypoints',
                    'vehicle_illegal_num',
                    'vehicle_evtrpt_mileage',
                    'vehicle_evtrpt_b2bprice',
                    'vehicle_evtrpt_c2bprice',
                    'vehicle_evtrpt_transfersnums',
                    'vehicle_evtrpt_evalprice3',
                    'vehicle_evtrpt_evalprice2',
                    'vehicle_minput_transfertimes',
                    'vehicle_minput_chargetimes',
                    'fh_execu_annu_num',
                    'jxl_110_called_num',
                    'jxl_110_called_length',
                    'jxl_appear_num',
                    'jxl_tel_loan_call_sumnum',
                    'jxl_tel_length',
                    'jxl_black_interme_score',
                    'jxl_dir_black_num',
                    'jxl_eachphone_num',
                    'jxl_call_num_aver_6months',
                    'jxl_id_comb_othertel_num',
                    'jxl_turnoff_length',
                    'jxl_tel_credit_call_sumnum',
                    'jxl_nocturnal_ratio',
                    'jxl_black_dir_cont_num',
                    'jxl_contact1_num',
                    'jxl_contact1_rank',
                    'jxl_contact1_times',
                    'jxl_contact2_num',
                    'jxl_contact2_rank',
                    'jxl_contact2_times',
                    'jxl_contact3_num',
                    'jxl_contact3_rank',
                    'jxl_contact3_times',
                    'tx_num_cancel_status',
                    'yx_overdue_num_90days',
                    'yx_risk_num',
                    'yx_underly_record_num',
                    'yx_otherorgan_times',
                     'vehicle_evtrpt_2bprice_gap',
                     'vehicle_evtrpt_evalprice_trend'
                    )


library(dplyr)
library(plotrix)

i= 1
  colname = numeric_columns[i]
  x = sample_data[,colname]
  sample_data[,'x_group'] = cut(x, c(-Inf, unique(quantile(x, probs=seq(0.1,0.9,0.1), na.rm=TRUE)), Inf), right=FALSE)
  if(colname == 'apt_ec_overduedaystotallastyear') {
    sample_data[,'x_group'] = cut(x, c(-Inf, 0, 1, 2, 3, 4, 5, Inf),right=FALSE)
  }
  if(colname == 'apt_ec_longestoverduedaystotallastyear') {
    sample_data[,'x_group'] = cut(x, c(-Inf, 0, 1, 2, 3, 4, 5, 10, Inf),right=FALSE)
  }
  if(colname == 'apt_ec_overduephasetotallastyear') {
    sample_data[,'x_group'] = cut(x, c(-Inf, 0, 1, 2, 3, Inf),right=FALSE)
  }
  
  y_mean = data.frame(sample_data %>% group_by(x_group) %>% summarise(count=n(), mean=mean(y,na.rm=TRUE)))
  xytrend = rbind(xytrend, data.frame(var_name=colname, y_mean))
  
  x_group = as.character(y_mean$x_group ) 
  x_group[is.na(x_group)] = 'NA'
  xpos = 1:length(x_group)
  lylim = c(-max(y_mean$count)*1.1*0.05, max(y_mean$count)*1.1)
  rylim = c(-max(y_mean$mean)*110*0.05, max(y_mean$mean)*110)
  lytickposmax = floor(round(floor(max(y_mean$count)/1000)/2)*2000)
  twoord.plot(xpos, y_mean$count, xpos, y_mean$mean * 100, type=c('bar', 'l'), lcol = 4, rcol = 'red', 
              xtickpos=xpos, xticklab =x_group, halfwidth=0.3, lwd=3,
              lytickpos=seq(0, lytickposmax, by=ifelse(lytickposmax/2000<=4, 2000, 4000)),
              xlab=colname, ylab='samples', rylab='%bad', 
              xlim=c(0.5, length(xpos)+0.5), lylim=lylim, rylim=rylim,
              do.first="plot_bg();grid(col=\"white\", lty=1)")
 