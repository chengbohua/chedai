from sklearn.externals import joblib
import datetime
clf = joblib.load('gbdt3_v4.pkl')

def gbdt3(jxl_id_comb_othertel_num,
          jxl_tel_loan_call_sumnum,
          vehicle_illegal_num,
          jxl_tel_length,
          jxl_eachphone_num,
          jxl_call_num_aver_6months,
          jxl_nocturnal_ratio,
          jxl_black_dir_cont_num,
          yx_underly_record_num,
          yx_otherorgan_times,
          apt_currentaddrresideyears,
          vehicle_evtrpt_mileage,
          apt_ec_historyloantimes,
          apt_ec_overduedaystotallastyear,
          apt_age,
          vehicle_evtrpt_b2bprice,
          vehicle_evtrpt_c2bprice,
          vehicle_evtrpt_evalprice3,
          vehicle_evtrpt_evalprice2,
          apt_ec_lastloansettleddate,
          vehicle_minput_lastreleasedate,
          vehicle_minput_drivinglicensevaliditydate,
          vehicle_minput_obtaindate,
          apt_facetrial_creditcardfalg,
          apt_gender,
          apt_telecom_phoneattribution,
          vehicle_minput_lastmortgagerinfo,
          apt_facetrial_housetype,
          app_applydate):

    x1 = [jxl_id_comb_othertel_num,
          jxl_tel_loan_call_sumnum,
          vehicle_illegal_num,
          jxl_tel_length,
          jxl_eachphone_num,
          jxl_call_num_aver_6months,
          jxl_nocturnal_ratio,
          jxl_black_dir_cont_num,
          yx_underly_record_num,
          yx_otherorgan_times,
          apt_currentaddrresideyears,
          vehicle_evtrpt_mileage,
          apt_ec_historyloantimes,
          apt_ec_overduedaystotallastyear,
          apt_age]

    x2 = [vehicle_evtrpt_b2bprice,
          vehicle_evtrpt_c2bprice,
          vehicle_evtrpt_evalprice3,
          vehicle_evtrpt_evalprice2]
    x3 = [apt_facetrial_creditcardfalg,
          apt_gender,
          apt_telecom_phoneattribution,
          vehicle_minput_lastmortgagerinfo,
          apt_facetrial_housetype]
    dates = [apt_ec_lastloansettleddate,
          vehicle_minput_lastreleasedate,
          vehicle_minput_obtaindate]
    
    
    def fun(x):
        if x == '' or x == ' ' or float(x) == -1 or float(x) == -99:
            return -998
        else:
            return float(x)
        
    def fun_date(x,app_applydate):
        x = x.replace('/', '-')
        try:
            x = datetime.datetime.strptime(x, '%Y-%m-%d %H:%M:%S')
        except:
            return -998
        app_applydate=app_applydate.replace('/','-')
        try:
            now_time = datetime.datetime.strptime(app_applydate,'%Y-%m-%d %H:%M:%S')
        except:
            return -998
        x = (now_time - x).days
        return x

    def driving_fun_date(x,app_applydate):
        x = x.replace('/', '-')
        try:
            x = datetime.datetime.strptime(x, '%Y-%m-%d %H:%M:%S')
        except:
            return -998
        app_applydate=app_applydate.replace('/','-')
        try:
            now_time = datetime.datetime.strptime(app_applydate,'%Y-%m-%d %H:%M:%S')
        except:
            return -998
        x = (x-now_time).days
        return x
           
    try:
        x1 = [fun(i) for i in x1]
        x2 = [fun(i) for i in x2]
        dates = [fun_date(i,app_applydate) for i in dates]
        vehicle_minput_drivinglicensevaliditydate=driving_fun_date(vehicle_minput_drivinglicensevaliditydate,app_applydate)
    except:
        return -1
    
    if x2[0] == -998 or x2[1] == -998 or x2[0] == 0:
        vehicle_evtrpt_2bprice_gap = -998
    else:
        vehicle_evtrpt_2bprice_gap = (x2[0]-x2[1]) / x2[0]

    if x2[2] == -998 or x2[3] == -998 or x2[3] == 0:
        vehicle_evtrpt_evalprice_trend = -998
    else:
        vehicle_evtrpt_evalprice_trend = x2[2]/x2[3]
    
    if x3[0] == '2':
        apt_facetrial_creditcardfalg_2 = 1.0
    else:
        apt_facetrial_creditcardfalg_2 = 0.0

    if x3[1] == '女':
        apt_gender_0 = 1.0
    else:
        apt_gender_0 = 0.0

    if x3[2] == '2' or x3[2] == '3':
        apt_telecom_phoneattribution_2n3 = 1.0
    else:
        apt_telecom_phoneattribution_2n3 = 0.0
        
    if x3[3] == '1' or x3[3] == '2':
        vehicle_minput_lastmortgagerinfo_1n2 = 1.0
    else:
        vehicle_minput_lastmortgagerinfo_1n2 = 0.0
                
    if x3[4] == '1':
        apt_facetrial_housetype_1 = 1.0
    else:
        apt_facetrial_housetype_1 = 0.0
           
    x2d=[vehicle_evtrpt_2bprice_gap,vehicle_evtrpt_evalprice_trend]
    newdates=[dates[0],dates[1],vehicle_minput_drivinglicensevaliditydate,dates[2]]
    x3d=[apt_facetrial_creditcardfalg_2,apt_gender_0,apt_telecom_phoneattribution_2n3,vehicle_minput_lastmortgagerinfo_1n2,apt_facetrial_housetype_1]

    x =x1+x2d+newdates+x3d

    res = float(clf.predict_proba(x)[:, 1]) * 100.0
    return '%.3f' % res


if __name__ == "__main__":
    print(gbdt3('1',
                '2',
                '20',
                '18',
                '98',
                '132.35',
                '10.18',
                '3',
                '0',
                '2',
                '23',
                '44891',
                '1',
                '2',
                '23',
                '7.79',
                '7.69',
                '6.16',
                '6.91',
                '2018/5/21  00:00:00',
                '2018/7/30  00:00:00',
                '2019/2/23  00:00:00',
                '2017/5/11  00:00:00',
                '1',
                '男',
                '1',
                '2',
                '1',
                 '2018-08-03 09:54:10'))




    