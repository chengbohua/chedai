
'''
## 2. 模型训练
'''

ori_columns = numeric_columns + date_columns + dummy_columns 
model_data = sample_data.loc[:, ['y']+ori_columns]
xxdata = model_data[ori_columns]
xxdata[xxdata.isnull()] = -998
model_data[xxdata.columns.tolist()] = xxdata.copy()


## 拆分训练集和验证集   

y = model_data['y']
x = model_data[ori_columns]
x_train,x_test,y_train,y_test=train_test_split(x, y, test_size=0.3,stratify = y ,random_state=0)
ori_x_train = x_train
ori_y_train = y_train  
bad = y_train[(y_train==1)]
good = y_train[(y_train==0)].sample(len(bad)*7, random_state=0)
y_train = pd.concat([bad,good])
x_train = x_train.ix[y_train.index, :]

    
## 选取在模型中重要性不小于给定阈值的变量

tol = 0.01
columns = numeric_columns + date_columns + dummy_columns
a = range(len(columns)+1)
clf = GradientBoostingClassifier(learning_rate=0.05,
                                     min_samples_leaf=24,
                                     max_depth=7,
                                     max_leaf_nodes=25,
                                     n_estimators=46,
                                     random_state=0)
## 去除相关性比较强的变量
clf.fit(x_train[columns], y_train)
pred_p = clf.predict_proba(ori_x_train[columns])[:, 1]
a0 = clf.feature_importances_.tolist()
importances = pd.DataFrame(np.array(a0), index=columns).T
del_columns=[]
for onecol in numeric_columns:
    for othercol in numeric_columns:
        if (onecol != othercol) and np.abs(columns_corrcoef.ix[onecol, othercol]) >= 0.50 and (importances.get_value(0, onecol) >= importances.get_value(0, othercol)):
            del_columns.append(othercol)
        else:
            pass
columns=[col for col in columns if col not in del_columns]

while (len(a)>len(columns)):    
    ## 训练模型并估计参数    
    clf.fit(x_train[columns], y_train)     
    pred_p = clf.predict_proba(ori_x_train[columns])[:,1]
    fpr, tpr, th = roc_curve(ori_y_train, pred_p)
    ks = tpr - fpr
    pred_p2 = clf.predict_proba(x_test[columns])[:,1]
    fpr, tpr, th = roc_curve(y_test, pred_p2)
    ks2 = tpr - fpr
    a = clf.feature_importances_.tolist()
    print(columns)
    print('len(columns)= ', len(columns))
    print('minimum feature importance = ', min(a))
    print('train ks: ' + str(max(ks)))
    print('test ks:  ' + str(max(ks2)))

    if( min(a) < tol ):
        b = (clf.feature_importances_ == min(a))
        columns = [columns[i] for i in range(len(columns)) if b[i]==False]

## 当变量个数为26时，模型总体表现最好
