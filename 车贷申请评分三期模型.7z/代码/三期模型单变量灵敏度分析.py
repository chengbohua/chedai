import numpy as np
import pandas as pd
import os
from sklearn.externals import joblib #保持模型包
import warnings

warnings.filterwarnings("ignore") #去除警告
## 修改路径到数据存储的文件夹
os.chdir('E:/liaoliming/重要文档/车贷数据/车贷反欺诈三期（廖利明）_优化/fraud_v3/data')
##加载模型
clf=joblib.load('gbdt3_v4.pkl')

## 输入参数
columns =['jxl_id_comb_othertel_num',
 'jxl_tel_loan_call_sumnum',
 'vehicle_illegal_num',
 'jxl_tel_length',
 'jxl_eachphone_num',
 'jxl_call_num_aver_6months',
 'jxl_nocturnal_ratio',
 'jxl_black_dir_cont_num',
 'yx_underly_record_num',
 'yx_otherorgan_times',
 'apt_currentaddrresideyears',
 'vehicle_evtrpt_mileage',
 'apt_ec_historyloantimes',
 'apt_ec_overduedaystotallastyear',
 'apt_age',
 'vehicle_evtrpt_2bprice_gap',
 'vehicle_evtrpt_evalprice_trend',
 'apt_ec_lastloansettleddate',
 'vehicle_minput_lastreleasedate',
 'vehicle_minput_drivinglicensevaliditydate',
 'vehicle_minput_obtaindate',
 'apt_facetrial_creditcardfalg_2',
 'apt_gender_0',
 'apt_telecom_phoneattribution_2n3',
 'vehicle_minput_lastmortgagerinfo_1n2',
 'apt_facetrial_housetype_1']

min_scores=[0.25719999999999998,
0.20455000000000001,
0.17644000000000001,
0.15728,
0.1424,
0.13058,
0.12107,
0.11312999999999999,
0.10629,
0.10051,
0.095630000000000007,
0.091170000000000001,
0.087359999999999993,
0.083839999999999998,
0.080360000000000001,
0.076920000000000002,
0.073539999999999994,
0.069940000000000002,
0.065949999999999995,
0]

## 读取建模数据
model_data=pd.read_excel('model_data_20180822.xlsx')
y=model_data['y']
x=model_data[columns]


## 计算单变量进行某一操作后的反欺诈分
def sensitive_analysis(new,column,method='None',value=0.1):

    data = new.copy()
    if method=='None':
       len=data.shape[0]
    elif method=='change_to_space': #变成缺失值
        data[column]=-998
        len=(new[column]!=-998).sum()  #不考虑原来是缺失值的样本
    elif method=='cup_10%_percent': #减少10%
        index = (new[column] != -998)
        data[column][index] = data[column][index]*(1-0.1)
        len=index.sum()
    elif method=='cup_20%_percent':
        index = (new[column] != -998)
        data[column][index] = data[column][index] * (1 - 0.2)
        len = index.sum()
    elif method == 'cup_30%_percent':
        index = (new[column] != -998)
        data[column][index] = data[column][index]*(1-0.3)
        len = index.sum()
    elif method == 'add_10%_percent': #增加10%
        index = (new[column] != -998)
        data[column][index] = data[column][index] * (1+0.1)
        len = index.sum()
    elif method == 'add_20%_percent':
        index = (new[column] != -998)
        data[column][index] = data[column][index]*(1+0.2)
        len = index.sum()
    elif method == 'add_30%_percent':
        index = (new[column] != -998)
        data[column][index] = data[column][index] * (1 + 0.3)
        len = index.sum()
    else: #处理哑变量
        data[column]=value
        len=(new[column]!=value).sum()

    answer_p = clf.predict_proba(data)[:, 1] #计算操作后的反欺诈分

    return  answer_p*100,len

## 计算操作后的反欺诈分数段对应的客户数分布情况
def  segment_vec(answer_p,min_scores):
    if min_scores[19] > np.min(answer_p):
        min_scores[19] = np.min(answer_p)

    segment=[]
    for index in range(len(answer_p)):
        if answer_p[index] >=min_scores[0]:
            segment.append(1)
        elif  answer_p[index] <min_scores[19]:
            segment.append(20)
        else:
            for seg in np.arange(0,19):
                if  answer_p[index]<min_scores[seg] and answer_p[index]>=min_scores[seg+1]:
                      segment.append(seg+2)
    return  np.array(segment)

##　计算单变量的灵敏度分析：选择某一个变量，将该变量的值全部变成缺失值等其他操作，统计操作后与操作前的反欺诈分的差异
def  gbdt_count_analysis(new,column,min_scores):

    count_results = {}
    len_counts={}

    dummy_vars=['apt_facetrial_creditcardfalg_2','apt_gender_0','apt_telecom_phoneattribution_2n3','apt_facetrial_housetype_1','vehicle_minput_lastmortgagerinfo_1n2'] #哑变量
    if column in dummy_vars:
        method_vector=['None','add_1','add_2'] #哑变量灵敏度分析
        value=[0,0,1]
    else:
        method_vector=['None','change_to_space','cup_30%_percent','cup_20%_percent','cup_10%_percent','add_10%_percent','add_20%_percent','add_30%_percent'] # 数值型变量灵敏度分析
        value=[0.1,0.1,0.1,0.1,0.1,0.1,0.1,0.1]

    for id,method in enumerate(method_vector):
        count_results[method],len_counts[method] = sensitive_analysis(new, column, method, value[id])

    count_result = pd.DataFrame(count_results, columns=method_vector, index=new.index)

    error_count = {}
    segment_0 = segment_vec(count_result['None'].values/100, min_scores) #计算操作前的反欺诈分数段对应的客户数分布情况
    for i in count_result:
        max_error = (count_result[i] - count_result['None']).abs().max()  #计算最大绝对值误差
        mean_error = (count_result[i] - count_result['None']).sum()/len_counts[i] #计算平均误差
        abs_mean_error = (count_result[i] - count_result['None']).abs().sum()/len_counts[i] #计算平均绝对误差
        diff_result=count_result[i] - count_result['None']
        lt_number = (diff_result>0).sum()
        st_number = (diff_result<0).sum()
        eq_number = (diff_result==0).sum()
        abs_lt_10 = (diff_result >= 10).sum()

        segment_i = segment_vec(count_result[i].values/100, min_scores)

        First_segment_LEN = (np.abs(segment_i - segment_0) == 1).sum()
        Second_segment_LEN = (np.abs(segment_i - segment_0) == 2).sum()
        Third_segment_LEN = (np.abs(segment_i - segment_0) == 3).sum()
        st_third_segment_LEN = (np.abs(segment_i - segment_0) > 3).sum()

        error_count[i] = [max_error, mean_error, abs_mean_error, lt_number, st_number, eq_number,
                                                abs_lt_10, First_segment_LEN,Second_segment_LEN, Third_segment_LEN, st_third_segment_LEN]

    error_count_DataFrame = pd.DataFrame(error_count,index=['max_error', 'mean_error', 'abs_mean_error', 'lt_number', 'st_number',
                            'eq_number', 'abs_lt_10', 'First_segment_LEN', 'Second_segment_LEN', 'Third_segment_LEN', 'st_third_segment_LEN'],columns=count_result.columns)
    error_count_DataFrame = error_count_DataFrame.T

    file_address = './gbdt_sensitive_analysis/' + column + '.xlsx'
    if len(column) >= 31:
        error_count_DataFrame.to_excel(file_address, sheet_name=column[:31])
    else:
        error_count_DataFrame.to_excel(file_address, sheet_name=column)

    return error_count


## 计算所有变量的单变量灵敏度分析
def  all_variable_count(new,all_column,min_scores):

     all_count_result={}
     for cn in all_column:
         error_count=gbdt_count_analysis(new,cn,min_scores)
         all_count_result[cn]=error_count

     return all_count_result


all_count_result=all_variable_count(x,columns,min_scores)











