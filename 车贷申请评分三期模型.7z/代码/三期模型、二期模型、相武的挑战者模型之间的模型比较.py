import pandas as pd
import os
import numpy as np
from sklearn.metrics import roc_curve,roc_auc_score

## 修改路径到数据存储的文件夹
os.chdir('E:/liaoliming/重要文档/车贷数据/车贷反欺诈（廖利明）/fraud_v3/data')

##  数据读取、融合
xw_score=pd.read_table('data_apply.txt',sep=',',dtype={'apply_id': str})
my_score=pd.read_table('llm_data.txt',sep='\t',dtype={'apply_id': str,'app_applycode': str})
chen_scores2=pd.read_excel('chen_scores2.xlsx',converters={'app_applycode':str})
fin_data=pd.read_excel('fin_data.xlsx',converters={'app_applycode':str})

print(xw_score.shape[0],xw_score.columns)
print(my_score.shape[0],my_score.columns)
print(chen_scores2.shape[0],chen_scores2.columns)

my_score=my_score.drop('app_applydate',axis=1)
combine_data0=pd.merge(chen_scores2,my_score,on='app_applycode',how='inner')
print(combine_data0.shape[0],combine_data0.columns)
combine_data=pd.merge(combine_data0,xw_score,on='apply_id',how='inner')
print(combine_data.shape[0],combine_data.columns)

## 选取近半年的数据，把相武的模型和我的模型、二期模型分别做交叉分析：按照现有二期模型四种审批结果同样的比例，对分数进行划分

test_data=combine_data[combine_data.app_applydate>='2018-01-01 00:00:00']
print(test_data.shape[0],test_data.columns)

test_mdata=pd.merge(test_data,fin_data,on='app_applycode',how='left')
print(test_mdata.shape[0],test_mdata.columns)
test_mdata.ix[test_mdata.whether_loan.isnull(),'whether_loan']=0
print(test_mdata.whether_loan.sum())

xw_cuts=[0,5.250,5.810,6.260,6.710,7.200,7.690,8.260,8.870,9.530,10.260,11.110,12.120,13.250,14.650,16.340,18.470,21.330,25.500,32.240,100]
my_cuts=[0.0,5.994,6.310,6.600,6.910,7.271,7.630,7.999,8.428,8.976,9.629,10.347,11.179,12.144,13.275,14.67,16.309,18.619,21.895,27.482,100]

test_mdata['score']=test_mdata['score']*100
test_mdata['score_segment']=pd.cut(test_mdata['score'],xw_cuts,right=False)
print(test_mdata['score_segment'].value_counts().sort_index(ascending=False)/test_mdata.shape[0])
xw_modcuts=[0,13.250,21.330,32.240,100]
print(pd.cut(test_mdata['score'],xw_modcuts,right=False).value_counts().sort_index(ascending=False)/test_mdata.shape[0])
test_mdata['score_modsegment']=pd.cut(test_mdata['score'],xw_modcuts,right=False)

test_mdata['scores2_segment']=pd.cut(test_mdata['scores2'],my_cuts,right=False)
print(test_mdata['scores2_segment'].value_counts().sort_index(ascending=False)/test_mdata.shape[0])
my_modcuts=[0,12.144,18.619,27.482,100]
print(pd.cut(test_mdata['scores2'],my_modcuts,right=False).value_counts().sort_index(ascending=False)/test_mdata.shape[0])
test_mdata['scores2_modsegment']=pd.cut(test_mdata['scores2'],my_modcuts,right=False)

chen_cuts=[0,15.927,21.782,28.348,100]
test_mdata['chen_scores2_modsegment']=pd.cut(test_mdata['chen_scores2'],chen_cuts,right=False)
print(test_mdata['chen_scores2_modsegment'].value_counts().sort_index(ascending=False)/test_mdata.shape[0])


my_cross_chen=pd.crosstab(test_mdata['chen_scores2_modsegment'],test_mdata['scores2_modsegment'],margins=True)
print(my_cross_chen.div(my_cross_chen['All'],axis=0))
my_cross_chen.div(my_cross_chen['All'],axis=0).to_excel('my_cross_chen.xlsx')
my_cross_chen.div(test_mdata.shape[0],axis=0).to_excel('my_cross_chen_percents.xlsx')

xw_cross_chen=pd.crosstab(test_mdata['chen_scores2_modsegment'],test_mdata['score_modsegment'],margins=True)
print(xw_cross_chen.div(xw_cross_chen['All'],axis=0))
xw_cross_chen.div(xw_cross_chen['All'],axis=0).to_excel('xw_cross_chen.xlsx')
xw_cross_chen.div(test_mdata.shape[0],axis=0).to_excel('xw_cross_chen_percents.xlsx')

xw_cross_my=pd.crosstab(test_mdata['scores2_modsegment'],test_mdata['score_modsegment'],margins=True)
print(xw_cross_my.div(xw_cross_my['All'],axis=0))
xw_cross_my.div(xw_cross_my['All'],axis=0).to_excel('xw_cross_my.xlsx')
xw_cross_my.div(test_mdata.shape[0],axis=0).to_excel('xw_cross_my_percents.xlsx')