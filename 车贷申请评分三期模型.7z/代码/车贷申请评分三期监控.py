import os
import pandas as pd
import numpy as np
import csv
import warnings
from sklearn.externals import joblib
import datetime
warnings.filterwarnings("ignore")


## 修改路径到数据存储的文件夹
os.chdir('E:/liaoliming/重要文档/车贷数据/车贷反欺诈三期（廖利明）_优化/fraud_v3/data')

##加载模型
clf=joblib.load('gbdt3_v4.pkl')

'''
##导入并合并车贷决策引擎入参表
'''
mdata0 = pd.read_table('data_20180702.txt', delimiter='\u0001', dtype={'app_applycode': str}) #读取决策引擎入参数据，从tbd中提取
mdata0=mdata0.replace('\\N',np.nan)
mdata0=mdata0[mdata0.app_applycode.notnull()]

mdata1 = pd.read_table('data_20181203.txt', delimiter='\u0001', dtype={'app_applycode': str}) #读取决策引擎入参数据，从tbd中提取
mdata1=mdata1.replace('\\N',np.nan)
mdata1=mdata1[mdata1.app_applycode.notnull()]
mdata1=mdata1[(mdata1.app_applydate>='2018-07-01 00:00:00')].copy()

mdata0=pd.concat([mdata0,mdata1])
del mdata1
mdata0 = mdata0.sort_values(['app_applycode', 'last_update_date']).drop_duplicates('app_applycode', keep='last')
print(mdata0.shape[0])


'''
## 导入车贷申请表
'''
apply_contract_report = pd.read_table('applyid_applycode_htbh_20181203.txt',encoding='gbk',dtype={'applycode': str})
apply_contract_report=apply_contract_report.replace('\\N',np.nan)
apply_contract_report = apply_contract_report.ix[(apply_contract_report.applycode.isnull() == False) & (
    apply_contract_report.contractno.isnull() == False),:].drop_duplicates()



'''
线下计算反欺诈分
'''

## 所需的变量列表
model_para1=['jxl_id_comb_othertel_num',
 'jxl_tel_loan_call_sumnum',
 'vehicle_illegal_num',
 'jxl_tel_length',
 'jxl_eachphone_num',
 'jxl_call_num_aver_6months',
 'jxl_nocturnal_ratio',
 'jxl_black_dir_cont_num',
 'yx_underly_record_num',
 'yx_otherorgan_times',
 'apt_currentaddrresideyears',
 'vehicle_evtrpt_mileage',
 'apt_ec_historyloantimes',
 'apt_ec_overduedaystotallastyear',
 'apt_age',
 'vehicle_evtrpt_b2bprice',
 'vehicle_evtrpt_c2bprice',
 'vehicle_evtrpt_evalprice2',
'vehicle_evtrpt_evalprice3',
 'apt_ec_lastloansettleddate',
 'vehicle_minput_lastreleasedate',
 'vehicle_minput_drivinglicensevaliditydate',
 'vehicle_minput_obtaindate',
 'apt_facetrial_creditcardfalg',
 'apt_gender',
 'apt_telecom_phoneattribution',
 'vehicle_minput_lastmortgagerinfo',
 'apt_facetrial_housetype',
 'app_applydate']

columns = ['jxl_id_comb_othertel_num',
 'jxl_tel_loan_call_sumnum',
 'vehicle_illegal_num',
 'jxl_tel_length',
 'jxl_eachphone_num',
 'jxl_call_num_aver_6months',
 'jxl_nocturnal_ratio',
 'jxl_black_dir_cont_num',
 'yx_underly_record_num',
 'yx_otherorgan_times',
 'apt_currentaddrresideyears',
 'vehicle_evtrpt_mileage',
 'apt_ec_historyloantimes',
 'apt_ec_overduedaystotallastyear',
 'apt_age',
 'vehicle_evtrpt_2bprice_gap',
 'vehicle_evtrpt_evalprice_trend',
 'apt_ec_lastloansettleddate',
 'vehicle_minput_lastreleasedate',
 'vehicle_minput_drivinglicensevaliditydate',
 'vehicle_minput_obtaindate',
 'apt_facetrial_creditcardfalg_2',
 'apt_gender_0',
 'apt_telecom_phoneattribution_2n3',
 'vehicle_minput_lastmortgagerinfo_1n2',
 'apt_facetrial_housetype_1']

dates_columns=['vehicle_minput_obtaindate','vehicle_minput_lastreleasedate','apt_ec_lastloansettleddate','vehicle_minput_drivinglicensevaliditydate']
model_para=['app_applycode']+model_para1

## 提取制定日期或贷款期限内的押证客户的决策引擎入参数据
start_date='2017-05-16 00:00:00'
end_date='2018-11-30 23:59:59'

m11_data = mdata0[(mdata0.app_applydate>=start_date)&(mdata0.app_applydate<=end_date) ]
print(m11_data.loan_product.unique())
m11_data=m11_data[(m11_data['loan_product'].isin(['P016', 'P013', 'P001', 'P008', 'P017','P018']))]
m11_data=m11_data[m11_data.loan_mode.isin([1,'1','押证'])]

## 增加两个变量applyday、applymonth
m11_data['applyday'] = m11_data.app_applydate.str.slice(0, 10)  # 生成申请日期（以月为单位）
m11_data['applymonth'] = m11_data.app_applydate.str.slice(0, 7)  # 生成申请日期（以天为单位）

##　异常值处理
m11_data.ix[m11_data.vehicle_minput_obtaindate>='2030-10-01','vehicle_minput_obtaindate']=np.nan  #将异常的车辆获得时间设为缺失值np.nan

## 提取所用到的模型入参数据
model_data=m11_data[model_para1].copy()

for col in dates_columns:  #去除异常的时间
       try:
           model_data.ix[model_data[col]>='2030-01-01',col]=np.nan
       except:
           pass

##  处理日期型变量
def date_cal(x, app_applydate):
    days_dt = pd.to_datetime(app_applydate) - pd.to_datetime(x)
    return days_dt.dt.days

for col in dates_columns:
    if  col!='vehicle_minput_drivinglicensevaliditydate':
      model_data[col] = date_cal(model_data[col], model_data['app_applydate'])
    else:
        model_data[col] = date_cal( model_data['app_applydate'],model_data[col])

model_data=model_data.drop('app_applydate',axis=1) #去除申请日期这个变量

## 将变量的默认值设为缺失值np.nan,并将部分数值的字符型变量转成数值型变量
de_dict_var = pd.read_excel('DE_Var_Select_0.xlsx')  # 处理默认值为np.nan
for i, _ in de_dict_var.iterrows():
    name = de_dict_var.loc[i, 'var_name']
    default = de_dict_var.loc[i, 'default']
    if default != '""' and name in set(model_data.columns):
        try:
            model_data[name] = model_data[name].astype('float64')
            if (model_data[name] == float(default)).sum() > 0:
                model_data.loc[model_data[name] == float(default), name] = np.nan
        except:
            pass

    elif default == '""' and name in set(model_data.columns):
        try:
            model_data[name] = model_data[name].astype('float64')
            if (model_data[name] == float(-99)).sum() > 0:
                model_data.loc[model_data[name] == float(-99), name] = np.nan
            if (model_data[name] == '-99').sum() > 0:
                model_data.loc[model_data[name] == '-99', name] = np.nan
        except:
            pass
## 变量的缺失率统计
null_data = model_data.isnull().astype('float64')
null_percents_count = null_data.groupby(m11_data['applymonth']).agg(['mean']).reset_index().rename(
columns={'mean': '缺失率', 'applymonth': '申请日期（以天为单位）'})
null_percents_count.to_excel('null_percents_count.xlsx')

##缺失率异常样本导出
abnormal_data=m11_data.ix[model_data.td_dishonest_list_check.isnull(),['apply_code','apt_idnumber','apt_mobile','yx_otherorgan_times',	'yx_underly_record_num','app_applydate']]

#异常数据导出
abnorm_data_applycode=mdata0.ix[(mdata0.app_applydate>='2018-04-12 00:00:00') & (mdata0.vehicle_evtrpt_evalprice3.isnull()),['apply_code','app_applydate','vehicle_evtrpt_evalprice3','vehicle_evtrpt_evalprice2']]
abnorm_data_applycode.to_excel('abnorm_data_applycode.xlsx',index=False)

## 变量衍生逻辑
model_data['vehicle_evtrpt_evalprice_trend'] = model_data['vehicle_evtrpt_evalprice3'] / model_data['vehicle_evtrpt_evalprice2']
model_data.ix[model_data['vehicle_evtrpt_evalprice_trend']==np.inf,'vehicle_evtrpt_evalprice_trend']=np.nan
model_data['vehicle_evtrpt_2bprice_gap'] = abs(model_data['vehicle_evtrpt_b2bprice'] - model_data['vehicle_evtrpt_c2bprice']) / model_data['vehicle_evtrpt_b2bprice']
model_data.ix[model_data['vehicle_evtrpt_2bprice_gap']==np.inf,'vehicle_evtrpt_2bprice_gap']=np.nan
model_data['apt_facetrial_creditcardfalg_2'] = model_data.loc[:,'apt_facetrial_creditcardfalg'].isin([2]).astype('float64')
model_data['apt_telecom_phoneattribution_2n3'] =  model_data.loc[:,'apt_telecom_phoneattribution'].isin([2,3]).astype('float64')
model_data['apt_gender_0'] = model_data.loc[:,'apt_gender'].isin(['女']).astype('float64')
model_data['vehicle_minput_lastmortgagerinfo_1n2'] = model_data.loc[:,'vehicle_minput_lastmortgagerinfo'].isin([1,2]).astype('float64')
model_data['apt_facetrial_housetype_1']=model_data.loc[:,'apt_facetrial_housetype'].isin([1]).astype('float64')

## 提取最终模型入参数据
final_data=model_data[columns].copy()

## 数值型变量的均值分析
vars_mean_count=final_data.groupby(m11_data['applymonth']).mean().reset_index().rename(columns={'mean':'均值','applymonth':'申请日期（以天为单位）'})
vars_mean_count.to_excel('vars_mean_count.xlsx')
vars_std_count=final_data.groupby(m11_data['applymonth']).std().reset_index().rename(columns={'std':'标准差','applymonth':'月份'})
(vars_std_count.set_index('月份')/vars_mean_count.set_index('月份')).reset_index().T.to_excel('vars_stddivmean_count.xlsx')

## 哑变量的各个不同取值对应的客户数分布情况
dummy_vars=['apt_facetrial_creditcardfalg','vehicle_minput_lastmortgagerinfo','apt_facetrial_housetype','apt_telecom_phoneattribution','apt_gender']
dummy_data=model_data[dummy_vars].copy()
dummy_data['applymonth']=m11_data['applymonth'].copy()
for cn in dummy_data:
    if dummy_data[cn].isnull().sum()>0:  #哑变量缺失设为默认值-998
        dummy_data.ix[dummy_data[cn].isnull(),cn]=-998
dummy_mean_count=pd.crosstab(dummy_data['applymonth'],dummy_data['apt_gender'],margins=True)
dummy_mean_count=dummy_mean_count.div(dummy_mean_count['All'],axis=0).drop('All',axis=1)
print(dummy_mean_count)

## 将缺失值np.nan设为-998
for cn in final_data:
    if final_data[cn].isnull().sum()>0:
        final_data.ix[final_data[cn].isnull(),cn]=-998

## 计算反欺诈分
p = clf.predict_proba(final_data)[:, 1]
m11_data['scores3']=p*100

'''
## 统计反欺诈划分的客户数占比，可调整日期范围、押证类型、网点地区等变量
'''
def  system_steady_monitor(mdata0,start_date,end_date,city=None):

    mdata1 = mdata0.ix[(mdata0.app_applydate >= start_date) & (mdata0.app_applydate <= end_date) , :]
    mdata1 = mdata1.sort_values(['app_applycode', 'last_update_date']).drop_duplicates('app_applycode', keep='last')
    mdata1['applymonth']=mdata1.app_applydate.str.slice(0,7)
    mdata1['applyday']=mdata1.app_applydate.str.slice(0,10)

    if city!=None:
        mdata1=mdata1.ix[mdata1['app_sitecity']==city,:].copy()

    mdata1=mdata1.replace('\\N',np.nan)
    mdata1=mdata1.ix[mdata1.scores3.notnull(),:]
    mdata1.scores3=mdata1.scores3.astype('float64')
    cuts = [0.0,6.595,6.994,7.354,7.692,8.036,8.384,8.736,9.117,9.563,10.051,10.629,11.313,12.107,13.058,14.240,15.728,17.644,20.455,25.720,100]

    mdata1['newgrp']=pd.cut(mdata1.scores3,cuts,right=False)

    score_dist = pd.crosstab(mdata1['newgrp'], mdata1['applymonth'], margins=True)
    score_dist=score_dist.div(score_dist.ix['All', :], axis=1).drop('All', axis=1).reset_index()

    applynumber_byday_count=pd.crosstab(mdata1['newgrp'], mdata1['applyday'], margins=True)
    applynumber_byday_count.reset_index().to_excel('applynumber_byday_count.xlsx')

    return  score_dist

start_date1 = '2018-11-01 00:00:00'
end_date1 = '2018-11-30 23:59:59'
system_steady_count=system_steady_monitor(m11_data,start_date1,end_date1)
print(system_steady_count)

'''
## 反欺诈分与放款情况统计，可调整日期范围、押证类型、网点地区等变量
'''
# ## 用TBD上的底层还款表计算曾经最大逾期天数（表现期截止到2018-03-31）
# paymentdata0 = pd.read_table('tb_lf_returndetail_20181205.txt', delimiter='\u0001', quoting=csv.QUOTE_NONE,encoding='utf-8')
# paymentdata0 = paymentdata0.replace('\\N', np.nan)
# paymentdata0 = paymentdata0[paymentdata0.returnid.notnull()]
# paymentdata0.returnid = paymentdata0.returnid.astype('int64')
# paymentdata0=paymentdata0[['returnid','phases','paydate','shouldpaydate','shouldcapital', 'shouldgpsf', 'shouldint', 'shouldmanage','update_time']].copy()
#
# returndata0 = pd.read_table('tb_lf_return_20181205.txt', delimiter='\u0001', quoting=csv.QUOTE_NONE, encoding='utf-8')
# returndata0 = returndata0.replace('\\N', np.nan)
# returndata0 = returndata0[returndata0.contractno.notnull()]
# returndata0=returndata0[['id','contractno','loandate','payphases','totalphases']].copy()
#
# paymentdata = pd.merge(paymentdata0, returndata0, left_on='returnid', right_on='id', how='inner')
# del paymentdata0, returndata0
#
# paymentdata=paymentdata.ix[paymentdata.shouldpaydate < '2018-12-05 00:00:00',['contractno','paydate','shouldpaydate','shouldcapital', 'shouldgpsf', 'shouldint', 'shouldmanage','update_time','totalphases','payphases','phases']]
# paymentdata.loc[(paymentdata.paydate >= '2018-12-05 00:00:00'), 'paydate'] = '2018-12-04 23:59:59'  ## 将表现窗口设为截止到2018-03-31
#
# paymentdata['overdue_days'] = (pd.to_datetime(paymentdata.paydate) - pd.to_datetime(paymentdata.shouldpaydate)).dt.days
# paymentdata.loc[(paymentdata[['shouldcapital', 'shouldgpsf', 'shouldint', 'shouldmanage']] == 0).all(axis=1), 'overdue_days'] = 0  ##计算历史最大逾期天数
# paymentdata.loc[paymentdata['overdue_days'] < 0, 'overdue_days'] = 0
# paymentdata_maxdue = paymentdata.groupby(['contractno']).overdue_days.max().reset_index().rename(columns={'overdue_days': 'maxoverduedays'})
#
# paymentdata[['totalphases', 'payphases', 'phases']] = paymentdata[['totalphases', 'payphases', 'phases']].astype('int64')  # 将一些字段转成整型数据
#
# paymentdata_totalphases = paymentdata.groupby(['contractno']).totalphases.max().reset_index()  # 计算贷款总期限,不包括展期
# paymentdata_realtotalphases = paymentdata[paymentdata.update_time< '2018-12-05 00:00:00'].groupby(['contractno']).payphases.max().reset_index().rename(columns={'payphases': 'max_payphases'})  # 包括是否展期
# paymentdata_totalphases = pd.merge(paymentdata_totalphases, paymentdata_realtotalphases, on='contractno', how='inner')
# paymentdata_totalphases['realtotalphases'] = paymentdata_totalphases[['totalphases', 'max_payphases']].max(axis=1)  # 在实际贷款期限与是否展期合并获得总贷款期限
#
# paymentdata_returnphases = paymentdata.groupby(['contractno']).payphases.max().reset_index().rename(columns={'payphases': 'returnphases'})  # 计算已还期数
# paymentdata_phases_counts = pd.merge(paymentdata_returnphases, paymentdata_totalphases, on='contractno',how='inner')  # 合并贷款期限与已还期数
# paymentdata_phases_counts = pd.merge(paymentdata_phases_counts, paymentdata_maxdue, on='contractno',how='inner')  # 合并最大逾期与贷款期限
# del paymentdata,paymentdata_totalphases,paymentdata_returnphases,paymentdata_maxdue


paymentdata_phases_counts=pd.read_csv('paymentdata_phases_counts_20181206.csv',encoding='gbk')
findata0 = pd.read_table('fnsche_over20181203.txt',encoding='gbk',dtype={'contractno': str})#导入进度逾期表

def final_scores_monitor(mdata0,apply_contract_report,paymentdata_phases_counts,findata0,start_date,end_date,city=None):

    mdata1 = mdata0.ix[(mdata0.app_applydate >= start_date) & (mdata0.app_applydate <= end_date) ,:]
    if city!=None:
        mdata1=mdata1.ix[mdata1.app_sitecity==city,:]

    mdata1 = mdata1.sort_values(['app_applycode', 'last_update_date']).drop_duplicates('app_applycode', keep='last')
    mdata1['applymonth']=mdata1.app_applydate.str.slice(0,7)
    mdata1 = pd.merge(mdata1, apply_contract_report, left_on='app_applycode', right_on='applycode', how='left')

    findata=findata0.ix[findata0['loandate'].notnull(),['loandate','contractno','currentduedays','returnstatus']].copy()
    findata['loandate'] = findata['loandate'].map(lambda x: datetime.datetime.strptime(str(x),"%d%b%Y")).copy()  #pd.to_datetime(findata0['loandate']).astype('str')
    findata = findata[(findata['loandate']>= start_date)].copy() #.rename(columns={'ContractNo': 'contractno'})
    findata = findata.sort_values(['contractno', 'loandate']).drop_duplicates('contractno', keep='last')
    findata = pd.merge(findata, paymentdata_phases_counts, on='contractno', how='left')
    fin_data=pd.merge(mdata1, findata, on='contractno', how='inner')

    del findata

    return  fin_data

start_date1 = '2017-05-16 00:00:00'
end_date1 = '2018-03-24 23:59:59'
fin_data=final_scores_monitor(m11_data,apply_contract_report,paymentdata_phases_counts,findata0,start_date1,end_date1)

'''
## 计算好坏客户区分能力,可调整日期范围、押证类型、网点地区等变量
'''

def comput_judge_bad_ability(mdata0,apply_contract_report,paymentdata_phases_counts,findata0,start_date,end_date):
    fin_data = final_scores_monitor(mdata0, apply_contract_report,paymentdata_phases_counts,findata0, start_date,end_date)

    my_data = fin_data.copy()
    del fin_data
    my_data['overdue_flag'] = (my_data.maxoverduedays >= 16)
    my_data['bad'] = (my_data.overdue_flag == True)  # 占比约为4.6%
    my_data['chargeoff_flag'] = (my_data.maxoverduedays == 0) & (my_data.returnstatus.isin(['已结清']))  # 结清里面大概有75%没有逾期
    my_data['r6_good_flag'] = (my_data.returnphases >= 6) & (my_data.maxoverduedays == 0)
    my_data['good'] = my_data.chargeoff_flag | my_data.r6_good_flag
    my_data['y'] = 2
    my_data.loc[(my_data.bad == True) & (my_data.good == False), 'y'] = 1
    my_data.loc[(my_data.bad == False) & (my_data.good == True), 'y'] = 0

    my_data['currentdue4+']=(my_data.currentduedays >= 4).astype('float64')
    my_data['currentdue16+']=(my_data.currentduedays >= 16).astype('float64')
    my_data['currentdue30+'] = (my_data.currentduedays >= 30).astype('float64')

    my_data.scores2=my_data.scores3.astype('float64')
    cuts = [0.0,6.595,6.994,7.354,7.692,8.036,8.384,8.736,9.117,9.563,10.051,10.629,11.313,12.107,13.058,14.240,15.728,17.644,20.455,25.720,100]
    cuts_check=[0,12.107,17.644,25.720,100]
    my_data['newgrp']=pd.cut(my_data.scores3,cuts,right=False)
    my_data['newgrp_check'] = pd.cut(my_data.scores3, cuts_check, right=False)

    score_dist = pd.crosstab(my_data['newgrp'], my_data['y'], margins=True).reset_index()
    print(score_dist)
    current_score_dist = my_data.groupby(['newgrp'])[['currentdue4+','currentdue16+','currentdue30+']].mean().reset_index().sort_values('newgrp',ascending=False)
    print(current_score_dist)
    current_sum=pd.DataFrame(my_data[['currentdue4+','currentdue16+','currentdue30+']].mean()).T
    print(current_sum)

    score_dist_check=pd.crosstab(my_data['newgrp_check'], my_data['y'], margins=True).sort_index(ascending=False).reset_index()
    print(score_dist_check)
    current_score_dist = my_data.groupby(['newgrp_check'])[['currentdue4+','currentdue16+','currentdue30+']].mean().reset_index().sort_values('newgrp_check',ascending=False)
    print(current_score_dist)
    current_sum=pd.DataFrame(my_data[['currentdue4+','currentdue16+','currentdue30+']].mean()).T
    print(current_sum)

    test_data=my_data[['scores3','y','app_applycode']].copy()

    del my_data

    return  test_data

start_date1 = '2017-05-16 00:00:00'
end_date1 = '2018-05-17 23:59:59'
test_data=comput_judge_bad_ability(m11_data,apply_contract_report,paymentdata_phases_counts,findata0,start_date1,end_date1)


'''
# 分结清再贷客户、新增贷款客户来统计ks值
'''

findata0 = pd.read_table('fnsche_over20181203.txt', encoding='gbk', dtype={'contractno': str})  # 导入进度逾期表
findata0 = findata0.ix[findata0['loandate'].notnull(), ['loandate','contractno','totalduedays','totalphases','returnstatus','currentduedays','returnphases', 'docno_md5','carno_md5']].copy()
findata0['loandate'] = findata0['loandate'].map(lambda x: datetime.datetime.strptime(str(x), "%d%b%Y")).copy()  # pd.to_datetime(findata0['loandate']).astype('str')
new_loan_data= findata0.sort_values(['docno_md5','loandate']).drop_duplicates('carno_md5', keep='first')[['contractno','loandate','carno_md5']]
new_loan_data['new_loan']=1
findata0=pd.merge(findata0,new_loan_data,on=['contractno','loandate','carno_md5'],how='left')
findata0.ix[findata0['new_loan'].isnull(),'new_loan']=0


## 获取新增客户标识以及数据
def segment_scores_monitor(mdata0,apply_contract_report,paymentdata_phases_counts,findata0,start_date,end_date,city=None):

    mdata1 = mdata0.ix[(mdata0.app_applydate >= start_date) & (mdata0.app_applydate <= end_date) ,:]
    if city!=None:
        mdata1=mdata1.ix[mdata1.app_sitecity==city,:]

    mdata1 = mdata1.sort_values(['app_applycode', 'last_update_date']).drop_duplicates('app_applycode', keep='last')
    mdata1['applymonth']=mdata1.app_applydate.str.slice(0,7)
    mdata1 = pd.merge(mdata1, apply_contract_report, left_on='app_applycode', right_on='applycode', how='left')

    findata=findata0.ix[findata0['loandate'].notnull(),['loandate','contractno','currentduedays','returnstatus','new_loan']].copy()
    findata = findata[(findata['loandate']>= start_date)].copy() #.rename(columns={'ContractNo': 'contractno'})
    findata = findata.sort_values(['contractno', 'loandate']).drop_duplicates('contractno', keep='last')
    findata = pd.merge(findata, paymentdata_phases_counts, on='contractno', how='left')
    fin_data=pd.merge(mdata1, findata, on='contractno', how='inner')

    del findata

    return  fin_data

## 计算模型的区分能力
def comput_judge_segments_bad_ability(mdata0,apply_contract_report,paymentdata_phases_counts,findata0,start_date,end_date,new_consumer):
    fin_data = segment_scores_monitor(mdata0, apply_contract_report,paymentdata_phases_counts,findata0, start_date,end_date)
    fin_data=fin_data[fin_data.new_loan==new_consumer].copy()

    my_data = fin_data.copy()
    del fin_data
    my_data['overdue_flag'] = (my_data.maxoverduedays >= 16)
    my_data['bad'] = (my_data.overdue_flag == True)  # 占比约为4.6%
    my_data['chargeoff_flag'] = (my_data.maxoverduedays == 0) & (my_data.returnstatus.isin(['已结清']))  # 结清里面大概有75%没有逾期
    my_data['r6_good_flag'] = (my_data.returnphases >= 6) & (my_data.maxoverduedays == 0)
    my_data['good'] = my_data.chargeoff_flag | my_data.r6_good_flag
    my_data['y'] = 2
    my_data.loc[(my_data.bad == True) & (my_data.good == False), 'y'] = 1
    my_data.loc[(my_data.bad == False) & (my_data.good == True), 'y'] = 0

    my_data['currentdue4+']=(my_data.currentduedays >= 4).astype('float64')
    my_data['currentdue16+']=(my_data.currentduedays >= 16).astype('float64')
    my_data['currentdue30+'] = (my_data.currentduedays >= 30).astype('float64')

    my_data.scores2=my_data.scores3.astype('float64')
    cuts = [0.0,6.595,6.994,7.354,7.692,8.036,8.384,8.736,9.117,9.563,10.051,10.629,11.313,12.107,13.058,14.240,15.728,17.644,20.455,25.720,100]
    cuts_check=[0,12.107,17.644,25.720,100]
    my_data['newgrp']=pd.cut(my_data.scores3,cuts,right=False)
    my_data['newgrp_check'] = pd.cut(my_data.scores3, cuts_check, right=False)

    score_dist = pd.crosstab(my_data['newgrp'], my_data['y'], margins=True).reset_index()
    print(score_dist)
    current_score_dist = my_data.groupby(['newgrp'])[['currentdue4+','currentdue16+','currentdue30+']].mean().reset_index().sort_values('newgrp',ascending=False)
    print(current_score_dist)
    current_sum=pd.DataFrame(my_data[['currentdue4+','currentdue16+','currentdue30+']].mean()).T
    print(current_sum)

    score_dist_check=pd.crosstab(my_data['newgrp_check'], my_data['y'], margins=True)
    print(score_dist_check)
    current_score_dist = my_data.groupby(['newgrp_check'])[['currentdue4+','currentdue16+','currentdue30+']].mean().reset_index().sort_values('newgrp_check',ascending=False)
    print(current_score_dist)
    current_sum=pd.DataFrame(my_data[['currentdue4+','currentdue16+','currentdue30+']].mean()).T
    print(current_sum)

    test_data=my_data[['scores3','y','app_applycode']].copy()

    del my_data

    return  test_data

start_date1 = '2017-09-16 00:00:00'
end_date1 = '2018-05-17 23:59:59'
test_data=comput_judge_segments_bad_ability(m11_data,apply_contract_report,paymentdata_phases_counts,findata0,start_date1,end_date1,0)






